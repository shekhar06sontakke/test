<?php

namespace app\controllers;

use Yii;
use app\model\CategoryType;
use app\models\Category;

class CategoryController extends \yii\web\Controller {
     public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','add-category'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }

    public function actionIndex() {
        return $this->render('index');
    }

    public function actionAddcategory() {
        $model = new Category();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            \Yii::$app->getSession()->setFlash('success', 'Category added successfully!');
        }
        $modelct = new \app\models\CategoryType();
        if ($modelct->load(Yii::$app->request->post()) && $modelct->save()) {
            \Yii::$app->getSession()->setFlash('success', 'Category type added successfully!');
        }
        return $this->render('addcategory', ['model' => $model, 'modelct' => $modelct]);
    }


}
