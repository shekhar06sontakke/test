<?php

namespace app\controllers;

use Yii;
use app\models\Admgmt;
use app\models\AdmgmtSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * AdmgmtController implements the CRUD actions for Admgmt model.
 */
class AdmgmtController extends Controller {

    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Admgmt models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new AdmgmtSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Admgmt model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Admgmt model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new Admgmt();
//        \app\components\Helper::pp($_FILES);
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($f = $this->upload($model)) {
                $f = (object) $f;
                $model->admg_path = $f->path;
                $model->admg_image = $f->name;
                if ($model->save()) {
                    return $this->redirect(['view', 'id' => $model->admg_id]);
                }
            }
        } else {
//            \app\components\Helper::pp($model->errors);
            return $this->render('create', [
                        'model' => $model,
            ]);
        }
    }

    function upload($model) {
        $image = UploadedFile::getInstance($model, 'imageFile');
        if (!$image)
            return NULL;

//        \app\components\Helper::pv($image);
//        die();
        $img_path = 'admgmt/' . date('Y') . '/' . date('m');
        $img_name = (strtolower(str_replace(' ', '-', $image->baseName)) . time() . '.' . $image->extension);

        if (!is_dir(Yii::$app->params['uploadDir'] . '/' . $img_path)) {
            mkdir(Yii::$app->params['uploadDir'] . '/' . $img_path, 0777, true);
        }

        if ($image->saveAs(Yii::$app->params['uploadDir'] . '/' . $img_path . '/' . $img_name)) {
            return [
                'path' => $img_path,
                'name' => $img_name,
            ];
        }
        return null;
    }

    /**
     * Updates an existing Admgmt model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $valid = TRUE;
            if ($f = $this->upload($model)) {
                $f = (object) $f;
                $model->admg_path = $f->path;
                $model->admg_image = $f->name;
                $valid = $valid && $model->save();
            } else {
                $valid = $valid && $model->save();
            }
            if ($valid)
                return $this->redirect(['view', 'id' => $model->admg_id]);
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Admgmt model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Admgmt model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Admgmt the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Admgmt::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionDo() {
        if (Yii::$app->request->isGet) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $get = Yii::$app->request->get();
            $valid = true;
            $response = [];
            $keys = $get['keys'];
            switch ($get['task']) {
                case 'activate_ad': {
                        $models = Admgmt::find()->where(['admg_id' => $keys])->all();
                        foreach ($models as $model) {
                            $model->admg_status = Admgmt::STATUS_ON;
                            $model->save();
                        }

                        break;
                    }
                case 'deactivate_ad': {
                        $models = Admgmt::find()->where(['admg_id' => $keys])->all();
                        foreach ($models as $model) {
                            $model->admg_status = Admgmt::STATUS_OFF;
                            $model->save();
                        }

                        break;
                    }

                default:
                    break;
            }
            if ($valid) {
                $response['status'] = "success";
                return $response;
            }

//            \app\components\Helper::pp($get);
        }
    }

}
