<?php

namespace app\controllers;

use app\models\Buyer;
use Yii;
use app\components\Helper;

class BuyerController extends \yii\web\Controller {
    public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','profile-update'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }
    

    /**
     * Lists all Buyer models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new \app\models\BuyerSearch();
        
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
//        Helper::pp($searchModel);
//        Helper::pp(Yii::$app->request->queryParams);
//        Helper::pp($dataProvider);
        

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    public function actionProfileUpdate() {
        $id = Yii::$app->user->id;

        $model = Buyer::find()->where(['id' => $id])->one();
        if (!$model) {
            $model = new Buyer();
            $model->id = $id;
        }

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            \Yii::$app->getSession()->setFlash('success', 'Your Text Here..');
        }
        //Helper::pp($model->errors);

        return $this->render('profile_update', ['model' => $model]);
    }

}
