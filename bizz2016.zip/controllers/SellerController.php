<?php

namespace app\controllers;

use app\models\Seller;
use Yii;
use app\components\Helper;

class SellerController extends \yii\web\Controller {
      public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','profile-update','category-list','listing','ajax-search','task'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }

      /**
     * Lists all Seller models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new \app\models\SellerSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
//        Helper::pp($searchModel);
//        Helper::pp(Yii::$app->request->queryParams);
//        Helper::pp($dataProvider);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionProfileUpdate() {

        $id = Yii::$app->user->id;
        $model = Seller::find()->where(['id' => $id])->one();
//        Helper::pv($id);
//        Helper::pv($model);

        if (!$model) {
            $model = new Seller();
            $model->id = $id;
        }


        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            \Yii::$app->getSession()->setFlash('success', 'Data Save Successfully ');
        }
        //Helper::pp($model->errors);
        return $this->render('profile_update', ['model' => $model]);
    }

    public function actionCategoryList() {
        $model = \app\models\CategoryType::find()->all();
        return $this->render('category-list', ['model' => $model]);
    }

    public function actionListing($cat) {
        $category = \app\models\Category::find()->where(['cat_slug' => $cat])->one();
        $model = \app\models\SellerCategoryAssignment::find()->where(['cat_id' => $category->cat_id])->all();


        $dataProvider = new \yii\data\ActiveDataProvider([
            'query' => \app\models\SellerCategoryAssignment::find()->where(['cat_id' => $category->cat_id])->orderBy('sl_id DESC'),
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);

        $this->view->title = 'Posts List';
        return $this->render('listing', ['listDataProvider' => $dataProvider]);

//        Helper::pp($model);
//        die();
//        return $this->render('listing',['model'=>$model]);
    }

    public function actionAjaxSearch($q = '', $aucid = '') {

        if (Yii::$app->request->isAjax) {
//
//            Helper::pp($aucid);
//            die();
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;


            return [
                'items' => $this->prepareSearchData($aucid),
                'incomplete_results' => false,
                'total_count' => 3,
            ];

//            Helper::pp($q);
        }
    }

    public function prepareSearchData($aucid) {
        $auction = \app\models\Auction::findOne($aucid);
//         Helper::pp($auction->cat_id);

        $models = \app\models\SellerCategoryAssignment::find()->where(['cat_id' => $auction->cat_id])->all();

//        $models = Seller::find()->where([''])->all();
        $items = [];
//         Helper::pp($models);
//         die();
        foreach ($models as $model) {
            $logo = $model->seller->logo ? ('/' . $model->seller->logo->ph_path . '/' . $model->seller->logo->ph_name) : '/images/company.jpg';
            $items[] = [
                'logo' => $logo,
                'id' => $model->seller->sl_id,
                'companyName' => $model->seller->sl_company_name,
                'companyStartYear' => $model->seller->sl_company_start_year,
                'companyDesc' => $model->seller->sl_company_description,
            ];
        }

        return $items;
    }

    public function actionTask() {
        if (Yii::$app->request->isAjax && ($get = Yii::$app->request->get())) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $valid = TRUE;
            $res = [];
            switch ($get['task']) {
                case 'add-category':
                    $model = new \app\models\SellerCategoryAssignment();
                    $model->sl_id = Yii::$app->params['me']->seller->sl_id;
                    $model->cat_id = $get['catid'];
                    $valid = $valid && $model->save();

                    break;
                case 'remove-category':
                    $sl_id = Yii::$app->params['me']->seller->sl_id;
                    $model = \app\models\SellerCategoryAssignment::find()->where(['cat_id' => (int) $get['catid'], 'sl_id' => $sl_id])->one();
//                    Helper::pp($model);
//                    die();
                    $valid = $valid && $model->delete();
                    break;

                case 'add-rating':
                    $by_id = Yii::$app->params['me']->buyer->by_id;
                    $sl_id = (int) $get['slid'];
                    $model = \app\models\Rating::find()->where(['by_id' => $by_id, 'sl_id' => $sl_id])->one();
                    if (!isset($model->sl_id)) {
                        $model = new \app\models\Rating();
                        $model->by_id = $by_id;
                        $model->sl_id = $sl_id;
                    }
                    $model->rat_value = (floatval($get['rating']));
                    $valid = $valid && $model->save();
                    $res['data']['rating'] = $model->seller->getRating();
//                    Helper::pp($model);
                    break;

                case 'reset-rating':
                    $by_id = Yii::$app->params['me']->buyer->by_id;
                    $sl_id = (int) $get['slid'];
                    $model = \app\models\Rating::find()->where(['by_id' => $by_id, 'sl_id' => $sl_id])->one();
//                    Helper::pp($model);
//                    die();
                    $valid = $valid && $model->delete();
                    $res['data']['rating'] = $model->seller->getRating();
                    break;

                case 'switch': {
                       
                    }

                default:
                    break;
            }

            if ($valid) {
                $res['status'] = 'success';
                $res['msg'] = 'Done';
                return $res;
            }

//            Helper::pp($get);
        }
    }

   

}
