<?php

namespace app\controllers;

use app\models\Buyer;
use Yii;

class AjaxController extends \yii\web\Controller {
    
      public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['index','task'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }

    public function actionIndex() {
        
    }

    public function actionTask($task) {

        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $get = Yii::$app->request->get();
            $response = [];
            $valid = TRUE;
            switch ($task) {
                case 'fetch_sellerplans': {
                        $models = \app\models\Plan::find()->all();
                        $res = $this->prepare_plan_table($models);
                        $response['data']['htmldata'] = $res;
//                        \app\components\Helper::pp($res);
                        break;
                    }

                case 'assign_plan': {
//                        \app\components\Helper::pp($get);
                        $seller = \app\models\Seller::findOne((int) $get['sellerid']);
                        $model = new \app\models\PlanAssignForm();
                        $model->userid = $seller->id;
                        $model->plan = (int) $get['plan'];
                        $model->duration = (int) $get['duration'];
                        $model->method = \app\models\UpgradeHistory::PAYMENT_METHOD_BY_ADMIN;
                        $valid = $valid && $model->assign();

//                        \app\components\Helper::pp($model);
//                        \app\components\Helper::pp($r);

                        break;
                    }

                case 'get_slug_caty': {
                        
                    }
                case 'get_slug_cat': {
                        $title = $get['title'];
                        $res = $this->prepareSlugForCategory($title);
                        $response['data']['title'] = $res;
                    }


                default:
                    break;
            }

            if ($valid) {
                $response['status'] = 'success';
            } else {
                $response['status'] = 'failed';
            }
            return $response;
        }
    }

    function prepare_plan_table($models) {
        ob_start();
        ?>
        <table class="table-plan-list">
            <tbody>
                <?php
                $ps = mt_rand(100, 900);
                foreach ($models as $model) {
                    ?>
                    <tr data-pid="<?= $model->pln_id ?>">
                        <td><?= \yii\helpers\Html::input('radio', 'selection', $model->pln_id, ['class' => 'pselection', 'id' => 'ps' . ++$ps]) ?></td>
                        <td><?= $model->pln_name ?></td>
                        <td><?=
                            \yii\helpers\Html::dropDownList('duration', NULL, \yii\helpers\ArrayHelper::map($model->plandurations, 'pld_duration', function($model) {
                                        return \app\components\OptionList::get_plan_durations($model->pld_duration) . ' (' . $model->pld_currency . ' ' . $model->pld_price . ')';
                                    }), ['prompt' => 'Duration', 'class' => 'pduration'])
                            ?>
                        </td>
                    </tr>
                    <?php
                }
                ?>

            </tbody>
        </table>
        <hr>


        <?php
        return ob_get_clean();
    }

    function prepareSlugForCategory($title) {
        $title = strtolower(\app\components\Helper::clean_string($title)) ;
        if ($this->isSubCategoryExist($title)) {
            $title = ($title . mt_rand(11, 999));
            return $title;
        } else {
            return $title;
        }
    }

    function isSubCategoryExist($title) {
        $find = \app\models\Category::find()->where(['cat_slug' => $title])->count();
//        \app\components\Helper::pv($find);
        return $find > 0 ? TRUE : FALSE;
    }

}
