<?php

namespace app\controllers;

use app\models\Buyer;
use app\models\Auction;
use app\models\AuctionData;
use Yii;
use yii\web\UploadedFile;
use app\models\UploadForm;
use app\models\User;

//use PHPExcel;
//use moonland\phpexcel\Excel;

class AuctionController extends \yii\web\Controller {
    
      public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout','index','update','create','grid','docs','terms','invitation',
                            'doc-upload','doc-show','grid-save','grid-load','test','send-invitation','auction-list'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actionIndex($cat, $slug, $token = NULL) {

//        \app\components\Helper::pp(Yii::$app->request->url);
//        \app\components\Helper::pp(Yii::$app->session->get('returnurl'));
//                Yii::$app->session->set('returnurl', $url);


        $cat = \app\models\Category::find()->where(['cat_slug' => $cat])->one();
        $model = Auction::find()->where(['auc_slug' => $slug, 'cat_id' => $cat->cat_id])->andWhere('auc_status != :status', [':status' => Auction::STATUS_DRAFT])->one();

        if (Yii::$app->user->isGuest) {
            \app\components\Helper::setReturnUrl(Yii::$app->request->url);
//            if ($token)

            return $this->render('index', ['model' => $model]);
        } elseif (Yii::$app->user->identity->account_type == User::USER_TYPE_SELLER) {
            return $this->render('index', ['model' => $model]);
        } elseif (Yii::$app->user->identity->account_type == User::USER_TYPE_BUYER) {
            if (Yii::$app->params['me']->buyer->by_id == $model->by_id) {
                return $this->render('index', ['model' => $model]);
            } else {
//                new \yii\web\HttpException(404, 'Not found');
                return $this->redirect(['/myacc/dashboard']);
            }
        }
//        \app\components\Helper::pp($cat);
//        \app\components\Helper::pp($model);
//        $model = Auction::findOne(7);
//        \app\components\Helper::pp($model);
    }

    public function actionUpdate($cat, $slug, $round) {
        $cat = \app\models\Category::find()->where(['cat_slug' => $cat])->one();
        $model = Auction::find()->where(['auc_slug' => $slug, 'cat_id' => $cat->cat_id])->one();
        $auctiondata = $model->getAuctiondata($round);
        if (!isset($auctiondata->auc_round))
            throw new \yii\web\NotFoundHttpException('The requested page does not exist.');

        $auctiondata->scenario = AuctionData::SCENARIO_UPDATE_DURATION;
        $auctiondata->setScenario(AuctionData::SCENARIO_UPDATE_DURATION);

        $buyer = Yii::$app->params['me']->buyer;

        $is_author = NULL;
        if (isset($buyer->by_id) && ($model->by_id == $buyer->by_id ))
            $is_author = TRUE;


        /*
         * Ajax save 
         */
        if ($is_author && Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $auctiondata->load(Yii::$app->request->post());
//            $auctionData->setScenario($auctionData->scenario);
            if (($auctiondata->edit_lock == \app\models\AuctionData::EDIT_LOCK_OFF ) && $auctiondata->save()) {
                return [
                    'status' => 'success',
                    'msg' => 'Saved.',
                ];
            } else {
//                return [
//                    'status' => 'failed',
//                    'msg' => 'Unable to save',
//                ];
            }

            \app\components\Helper::pp($auctiondata);
            die();
        }


//        \app\components\Helper::pp($cat);
//        \app\components\Helper::pp($model);
//        $model = Auction::findOne(7);
//        \app\components\Helper::pp($model);

        return $this->render('update', ['model' => $model, 'auctiondata' => $auctiondata, 'round' => $round]);
    }

    public function actionCreate() {
        $buyer = Buyer::find()->where(['id' => Yii::$app->user->id])->one();
        if (!isset($buyer->by_id))
            throw new \yii\web\HttpException(404, 'not found');

        $model = new Auction();

        if ($model->load(Yii::$app->request->post())) {
            $valid = true;
            $model->by_id = $buyer->by_id;
            $valid = $valid && $model->save();
            //creating auctionData model
            $auctiondata = new \app\models\AuctionData();
            $auctiondata->auc_id = $model->auc_id;
            $auctiondata->auc_round = $model->auc_round;
            $valid = $valid && $auctiondata->save();

            if ($valid) {
                $this->redirect(['auction/update', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $model->auc_round]);
            }
        }

//        \app\components\Helper::pp($model->errors);

        return $this->render('create', ['model' => $model]);
    }

    public function actionGrid($id) {
        $model = Auction::find()->where(['auc_uniqueid' => $id])->one();


        return $this->render('grid', ['model' => $model]);
    }

    public function actionDocs($id) {
        $model = Auction::find()->where(['auc_uniqueid' => $id])->one();

        return $this->render('docs', ['model' => $model]);
    }

    public function actionTerms($id) {
        $model = Auction::findOne($id);
        $model->setScenario(Auction::SCENARIO_UPDATE_TERMS);

//        \app\components\Helper::pp($model);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return [
                'status' => 'success',
                'msg' => 'Done',
            ];
        }
    }

    public function actionInvitation($id) {
        $model = Auction::find()->where(['auc_uniqueid' => $id])->one();

//        \app\components\Helper::pv($id);
//        \app\components\Helper::pv($model);

        return $this->render('invitation', ['model' => $model]);
    }

    public function actionDocUpload() {
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $upload = new UploadForm();
            $post = Yii::$app->request->post();

            $params = json_decode($post['params']);
            $upload->imageFile = UploadedFile::getInstanceByName('file');
            if ($file = $upload->upload()) {
                $auction = Auction::findOne((int) $params->aucID);
                $auctiondata = $auction->getAuctiondata((int) $params->round);
                if ($auctiondata->edit_lock == AuctionData::EDIT_LOCK_OFF) {
                    $model = new \app\models\AuctionFile();
                    $model->auc_id = $params->aucID;
                    $model->auc_round = $params->round;
                    $model->aucf_name = $file['name'];
                    $model->aucf_path = $file['path'];
                    if ($model->save()) {
                        $file['fileID'] = $model->aucf_id;
                        return [
                            'status' => 'success',
                            'file' => $file,
                        ];
                    }
                } else {
                    return [
                        'status' => 'failed',
                        'msg' => 'Sorry unable to save.',
                    ];
                }
            }

            \app\components\Helper::pp($upload);
        }
    }

    public function actionDocAction() {
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

            $post = Yii::$app->request->post();
            if (isset($post['action']) && $post['action'] == 'rm') {
                $model = \app\models\AuctionFile::findOne((int) $post['fileID']);
                if ($model->delete()) {
                    return [
                        'status' => 'success',
                        'msg' => 'deleted',
                    ];
                }
            }
//            \app\components\Helper::pp($model);
        }
    }

    public function actionGridSave() {
        if (Yii::$app->request->isPost) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $post = Yii::$app->request->post();
            if (isset($post['gdata']['aucID']) && $post['gdata']['aucID']) {
                $auction = Auction::findOne((int) $post['gdata']['aucID']);
                $round = (int) $post['gdata']['round'];
                $griddata = $this->getGridDataModel($auction->auc_id, $round);
                $auctionData = $auction->getAuctiondata($round);
                if ($auctionData->edit_lock == \app\models\AuctionData::EDIT_LOCK_OFF) {
                    $griddata->gdd_meta = json_encode($post['gdata']['GDD']);
                    $griddata->gdd_rate = json_encode($post['gdata']['GD']);
                    if ($griddata->save()) {
                        return [
                            'status' => 'success',
                            'msg' => 'Saved',
                        ];
                    } else {
                        return [
                            'status' => 'failed',
                            'msg' => 'Error Occured.',
                        ];
                    }
                } else {
                    return [
                        'status' => 'failed',
                        'msg' => 'Sorry! Unable to edit.',
                    ];
                }
            }
        }
    }

    public function actionGridLoad() {
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            if (isset($post['loadData']) && $post['loadData']['aucID']) {
                Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                $auction = Auction::find()->where(['auc_id' => (int) $post['loadData']['aucID']])->one();
                $round = (int) $post['loadData']['round'];
                $gdd = \app\models\GridData::find()->where(['auc_id' => (int) $post['loadData']['aucID'], 'auc_round' => $round])->one();
                if (isset($gdd['gdd_meta'])) {
                    return [
                        'status' => 'success',
                        'data' => [
                            'GDD' => json_decode($gdd['gdd_meta']),
                            'GD' => json_decode($gdd['gdd_rate']),
                        ]
                    ];
                } else {
                    return [
                        'status' => 'failed',
                        'msg' => 'no data found',
                    ];
                }

//                \app\components\Helper::pp($gdd);
            }
//            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
//            $post = Yii::$app->request->post();
        }
    }

    public function actionTest() {
        $this->prepare_round_data_from_previous(10);
    }

    /*
     * return GridData model instance for auction 
     * if not exist create new and return GridData object
     * @return object
     */

    public function getGridDataModel($aucID, $round) {
        $griddata = \app\models\GridData::find()->where(['auc_id' => $aucID, 'auc_round' => $round])->one();

        if (!$griddata) {
            $griddata = new \app\models\GridData();
            $griddata->auc_id = $aucID;
            $griddata->auc_round = $round;
        }
        return $griddata;
    }

    public function getAuctionDataModel($aucID, $round) {
        $griddata = \app\models\AuctionData::find()->where(['auc_id' => $aucID, 'auc_round' => $round])->one();

        if (!$griddata) {
            $griddata = new \app\models\AuctionData();
            $griddata->auc_id = $aucID;
            $griddata->auc_round = $round;
            $griddata->edit_lock = \app\models\AuctionData::EDIT_LOCK_OFF;
        }
        return $griddata;
    }

    public function actionTask() {
        if (Yii::$app->request->isAjax && ($get = Yii::$app->request->get()) && isset($get['task'])) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
//            $get = Yii::$app->request->get();
            $valid = true;
            $response = [];
            switch ($get['task']) {
                case 'add-invitee':
                    //add invitee
                    $this->addInvitation((int) $get['aucid'], (int) $get['round'], (int) $get['selid']);
                    break;
                case 'remove-invitee':
                    //remove invitee
                    $this->removeInvitation((int) $get['aucid'], (int) $get['round'], (int) $get['selid']);

                    break;
                case 'add-email':
                    //add email
                    $this->addEmail((int) $get['aucid'], (int) $get['round'], $get['email']);
                    break;
                case 'remove-email':
                    //remove email
                    $this->removeEmail((int) $get['aucid'], (int) $get['round'], $get['email']);
                    break;
                case 'new-auction-slug':
                    //prepare slug
                    return[
                        'status' => 'success',
                        'title' => $this->prepareSlug($get['title']),
                    ];

                    break;
                case 'fetch-bid-data': {
                        //prepare slug
                        $auc_id = (int) $get['aucID'];
                        $auction = Auction::findOne($auc_id);
                        $data = [];

                        $gdd = \app\models\GridData::find()->where(['auc_id' => $auc_id])->one();
                        $arr_result = [];
                        $arr_gdb = [];
                        $arr_gdd_meta = json_decode($gdd['gdd_meta']);
                        $arr_gdd_rate = json_decode($gdd['gdd_rate']);
                        $len = count($arr_gdd_meta);
                        for ($index = 0; $index < $len; $index++) {
                            $arr_result[] = array_merge($arr_gdd_meta[$index], $arr_gdd_rate[$index]);
                            $arr_gdb[] = [''];
                        }
                        switch (Yii::$app->user->identity->account_type) {
                            case User::USER_TYPE_BUYER: {
                                    if (Yii::$app->params['me']->buyer->by_id == $auction->by_id) {
                                        $data['gdr'] = $this->prepareAuctionReport($auction);
                                    }

                                    break;
                                }
                            case User::USER_TYPE_SELLER: {
                                    $seller = Yii::$app->params['me']->seller;
                                    $bid = \app\models\Bid::find()->where(['sl_id' => $seller->sl_id, 'auc_id' => $auc_id, 'auc_round' => $auction->auc_round])->one();
                                    $data['gdb'] = isset($bid->bid_data) ? json_decode($bid->bid_data) : $arr_gdb;
//                                    \app\components\Helper::pp($data);
                                    break;
                                }

                            default:
                                break;
                        }

                        $data['gdd'] = $arr_result;
                        return[
                            'status' => 'success',
                            'data' => $data
                        ];
                        break;
                    }
                case 'fetch-auction-report': {


                        break;
                    }
                case 'switch-round': {
                        $auc_id = (int) $get['aucID'];
                        $by_id = Yii::$app->params['me']->buyer->by_id;
                        $model = \app\models\Auction::findOne($auc_id);

                        if ($model->by_id == $by_id)
                            if ($this->prepare_round_data_from_previous($model)) {
                                $auctiondata = AuctionData::find()->where(['auc_id' => $auc_id, 'auc_round' => ($model->auc_round + 1)])->one();
                                if (!isset($auctiondata->auc_id)) {
                                    $auctiondata = new AuctionData();
                                    $auctiondata->auc_id = $model->auc_id;
                                    $auctiondata->auc_round = ($model->auc_round + 1);
                                    $auctiondata->edit_lock = AuctionData::EDIT_LOCK_OFF;
                                    $valid = $valid && $auctiondata->save();
                                }

                                if ($valid) {
                                    $response['data']['round'] = $auctiondata->auc_round;
                                    $response['data']['url'] = \yii\helpers\Url::to(['auction/update', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $auctiondata->auc_round]);
                                }
                            } else
                                $valid = FALSE;
                        break;
                    }
                case 'publish-round': {
                        $auc_id = (int) $get['aucID'];
                        $by_id = Yii::$app->params['me']->buyer->by_id;
                        $round = (int) $get['round'];
                        $model = \app\models\Auction::findOne($auc_id);
                        if ($model->by_id == $by_id) {
                            $valid = $valid && $this->publishAuctionByRound($model, $round);
                        } else
                            $valid = FALSE;

                        break;
                    }


                default:
                    break;
            }
            if ($valid) {
                $response['status'] = 'success';
                $response['msg'] = 'done';
                return $response;
            } else {
                $response['status'] = 'failed';
                $response['msg'] = 'Error occured.';
                return $response;
            }

//            \app\components\Helper::pp($get);
        }
    }

    /*
     * Send invitation to all sellers registered/unregistered
     * @param post data with auction_id    
     * @return json response
     */

    public function actionSendInvitation() {
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $post = Yii::$app->request->post();
//            die();
            $aucID = $post['aucid'];
            $model = \app\models\Auction::findOne($aucID);
            $auctiondata = $model->auctiondata;
            $recipient = [];
            foreach ($model->invitations as $invt) {
                if ($invt->invt_email_sent != \app\models\Invitation::STATUS_EMAIL_SUCCESS) {
                    $recipient[] = $invt->seller->profile->email;
                    $invt->invt_email_sent = \app\models\Invitation::STATUS_EMAIL_SUCCESS;
                    $invt->save();
                }
            }
            if ($model->auc_type == Auction::AUCTION_TYPE_OPEN) {
                $invitation_link = Yii::$app->params['siteUrl'] . '/auction/index/?cat=' . $model->category->cat_slug . '&slug=' . $model->auc_slug;
            } elseif ($model->auc_type == Auction::AUCTION_TYPE_PRIVATE) {
                if ($auctiondata->aucd_token == '') {
                    $key = Yii::$app->getSecurity()->generateRandomString();
                    $auctiondata->aucd_token = $key;
                    $auctiondata->save();
                } else {
                    $key = $auctiondata->aucd_token;
                }
                $invitation_link = Yii::$app->params['siteUrl'] . '/auction/index/?cat=' . $model->category->cat_slug . '&slug=' . $model->auc_slug . '&token=' . $key;
            }

//            \app\components\Helper::pp($auctiondata);
//            die();
            //send 
            $res = NULL;
            if (!empty($recipient)) {
                $res = Yii::$app->mailer->compose(
                                '@app/mail/auction/invitation'
                                , ['model' => $model, 'invitation_link' => $invitation_link]
                        )
                        ->setFrom('mail@bizjunction.local')
                        ->setTo($recipient)
                        ->setSubject('You got new invitation. ')
//                    ->setTextBody('Plain text content')
//                ->setHtmlBody($out)
                        ->send();
            }


            if ($res) {
                return [
                    'status' => 'success',
                    'msg' => 'Your invitations are successfully sent.',
                ];
            } else {
                return [
                    'status' => 'failed',
                    'msg' => 'Your invitations are already sent.',
                ];
            }
        }
    }

    /*
     * @param 
     * @return  
     */

    function addInvitation($auctionID, $round, $sellerID) {
        $auction = Auction::findOne($auctionID);
        $invite = \app\models\Invitation::find()->where(['auc_id' => $auctionID, 'invt_round' => $round, 'sl_id' => $sellerID])->one();
        if (isset($invite->auc_id)) {
            return TRUE;
        } else {
            $invite = new \app\models\Invitation();
            $invite->auc_id = $auctionID;
            $invite->invt_round = $round;
            $invite->sl_id = $sellerID;
            return $invite->save();
        }
    }

    /*
     * @param 
     * @return  
     */

    function removeInvitation($auctionID, $round, $sellerID) {
        $auction = Auction::findOne($auctionID);
        $invite = \app\models\Invitation::find()->where(['auc_id' => $auctionID, 'invt_round' => $round, 'sl_id' => $sellerID])->one();
        if (isset($invite->auc_id)) {
            return $invite->delete();
        }
        return TRUE;
    }

    /*
     * @param 
     * @return  
     */

    function addEmail($auctionID, $round, $email) {
        $model = $this->prepareInvitationEmailList($auctionID, $round);
        if ($model) {
            $arr = $model->invte_email_list;
            if (empty($arr)) {
                $arr = $email;
            } else {
                $t = explode(',', $arr);
                $t[] = $email;

                $arr = implode(',', array_unique($t));
            }
            $model->invte_email_list = $arr;
            return $model->save();
        }
    }

    /*
     * @param 
     * @return  
     */

    function removeEmail($auctionID, $round, $email) {
        $model = $this->prepareInvitationEmailList($auctionID, $round);
        if ($model) {
            $arr = $model->invte_email_list;
            if (empty($arr)) {
                return true;
            } else {
                $t = explode(',', $arr);
                if (in_array($email, $t)) {
                    unset($t[array_search($email, $t)]);
                }
                $arr = implode(',', array_unique($t));
            }
            $model->invte_email_list = $arr;
            return $model->save();
        }
    }

    /*
     * @param 
     * @return  
     */

    function prepareInvitationEmailList($auctionID, $round) {
        $auction = Auction::findOne($auctionID);
        $invite_email = \app\models\InvitationEmail::find()->where(['auc_id' => $auctionID, 'invte_round' => $round])->one();
        if (isset($invite_email->auc_id)) {
            return $invite_email;
        } else {
            $invite_email = new \app\models\InvitationEmail();
            $invite_email->auc_id = $auctionID;
            $invite_email->invte_round = $round;
            if ($invite_email->save())
                return $invite_email;
        }
    }

    /*
     * @param 
     * @return  
     */

    function prepareSlug($title) {
        $title = \app\components\Helper::clean_string($title);
//        $find = Auction::find()->where(['auc_title' => $title])->count();
//        \app\components\Helper::pv($this->isTitleExist($title));
//        die();
        if ($this->isTitleExist($title)) {
            $title = ($title . mt_rand(11, 999));
            return $title;
        } else {
            return $title;
        }
    }

    function isTitleExist($title) {
        $find = Auction::find()->where(['auc_slug' => $title])->count();
//        \app\components\Helper::pv($find);
        return $find > 0 ? TRUE : FALSE;
    }
    

    function actionCategoryList() {

        $model = \app\models\CategoryType::find()->all();
        return $this->render('category-list', ['model' => $model]);

        return $this->render('category-list');
    }

    /*
     * @param 
     * @return  
     */

    function actionSaveBid() {
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $post = Yii::$app->request->post();
            $seller = Yii::$app->params['me']->seller;
            $auc_id = (int) $post['aucID'];
            $auction = Auction::findOne($auc_id);
            $model = \app\models\Bid::find()->where(['auc_id' => $auc_id, 'auc_round' => $auction->auc_round, 'sl_id' => $seller->sl_id])->one();
            if (!$model) {
                $model = new \app\models\Bid();
                $model->auc_id = $auc_id;
                $model->auc_round = $auction->auc_round;
                $model->sl_id = $seller->sl_id;
                $model->bid_data = json_encode($post['data']['gdb']);
                if ($model->save()) {
                    return [
                        'status' => 'success',
                        'msg' => 'Your Bid Placed Successfully.'
                    ];
                }
            }

            \app\components\Helper::pp($post);
        }
    }

    public function actionListing($cat) {
        $category = \app\models\Category::find()->where(['cat_slug' => $cat])->one();

//        $model = \app\models\Auction::find()->where(['cat_id' => $category->cat_id])->all();


        $dataProvider = new \yii\data\ActiveDataProvider([
            'query' => \app\models\Auction::find()->where(['cat_id' => $category->cat_id, 'auc_type' => Auction::AUCTION_TYPE_OPEN])->orderBy('auc_id DESC'),
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);

//        $this->view->title = 'Posts List';
        return $this->render('listing', ['listDataProvider' => $dataProvider]);

//        Helper::pp($model);
//        die();
//        return $this->render('listing',['model'=>$model]);
    }

    function prepareAuctionReport($model) {
        $gdd = \app\models\GridData::find()->where(['auc_id' => $model->auc_id])->one();
        $bids = \app\models\Bid::find()->where(['auc_id' => $model->auc_id, 'auc_round' => $model->auc_round])->all();

        $output = [];
        $gdd_data = json_decode($gdd->gdd_rate);
        $header = ['Qty.', 'Target Rate'];
        $best = [];

        $output = $gdd_data;
        if ($bids) {
            foreach ($bids as $bid) {
                $header[] = $bid->seller->profile->username;
                $output = $this->_merage_array($output, json_decode($bid->bid_data));
            }

            $f = $output;
            $len = count($output);
            for ($index = 0; $index < $len; $index++) {
                if ($f[$index][0] == '')
                    continue;

                unset($f[$index][0], $f[$index][1]);
//            \app\components\Helper::pp($f[$index]);

                $best[$index] = $this->best_bid($f[$index]);

//                \app\components\Helper::pp($f[$index]);
            }
//            \app\components\Helper::pp($best);
//            die();
        }


        return [
            'gdr' => $output,
            'header' => $header,
            'best' => $best,
        ];
    }

    function _merage_array($array1, $array2) {
        $len = count($array1);
        $len1 = count($array2[0]);
        for ($index = 0; $index < $len; $index++) {
            for ($i = 0; $i < $len1; $i++) {
                $array1[$index][] = $array2[$index][$i];
            }
        }
        return $array1;
    }

    function _best_bid_in_row($output) {
        $len = count($array1);
        foreach ($output as $out) {
            
        }

        return $array1;
    }

    function best_bid($array) {
//        \app\components\Helper::pp($array);
//        die();

        if (count($array) <= 1)
            return NULL;


        $res = [];
        $res['first'] = array_keys($array, min($array));

        foreach ($res['first'] as $m) {
            unset($array[$m]);
        }

        $res['second'] = array_keys($array, min($array));

        return $res;
    }

    function actionExport($id = 5) {

        $model = Auction::findOne($id);

//        return;
        // export data with multiple worksheet.
        $objPHPExcel = new \PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator($model->buyer->profile->username)
                ->setLastModifiedBy($model->buyer->profile->username)
                ->setTitle($model->auc_title)
//                ->setSubject("Dear seller you are invited to bid.")
//                ->setDescription("Generazione report inverter")
                ->setKeywords($model->category->cat_slug)
                ->setCategory($model->category->cat_name);

//        $gdd = ( $model->griddata->gdd_meta );
        $gdd = $this->_merage_array(json_decode($model->griddata->gdd_meta), json_decode($model->griddata->gdd_rate));

//        \app\components\Helper::pp(json_decode($model->griddata->gdd_meta));
//        \app\components\Helper::pp(json_decode($model->griddata->gdd_rate));
//        \app\components\Helper::pp($gdd);
//        die();
// Add some data
        $len = count($gdd);
        $len1 = count($gdd[0]);

//        $colAlpha = \PHPExcel_Cell::stringFromColumnIndex(( 0 ));
//        \app\components\Helper::pp($colAlpha);
//        
//        return;
        for ($a = 0; $a < $len; $a++) {
//            \app\components\Helper::pp($colAlpha);

            for ($b = 0; $b < $len1; $b++) {
                $colAlpha = \PHPExcel_Cell::stringFromColumnIndex(( $b));
                $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue($colAlpha . ($a + 1), $gdd[$a][$b]);
            }

//                    ->setCellValue('B2', 'world!')
//                    ->setCellValue('C1', 'Hello')
//                    ->setCellValue('D2', 'world!');
        }


        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'outline' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );
        $objPHPExcel->getActiveSheet()->getStyle('A1:O14')->applyFromArray($styleThinBlackBorderOutline);
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'outline' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_DASHED,
                    'color' => array('argb' => '00CCCC'),
                ),
            ),
        );
        $objPHPExcel->getActiveSheet()->getStyle('N1:O14')->applyFromArray($styleThinBlackBorderOutline);

//        die();
// Miscellaneous glyphs, UTF-8
//        $objPHPExcel->setActiveSheetIndex(0)
//                ->setCellValue('A4', 'Miscellaneous glyphs')
//                ->setCellValue('A5', 'éàèùâêîôûëïüÿäöüç');
// Rename worksheet
        $objPHPExcel->getActiveSheet()->setTitle('Auction');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $objPHPExcel->setActiveSheetIndex(0);

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $dest = Yii::$app->params['uploadDir'] . '/abcd' . mt_rand(100, 999) . '.xls';
        $objWriter->save($dest);
        exit;
    }

    public function actionHistory() {
//        $category = \app\models\Category::find()->where(['cat_slug' => $cat])->one();
//        $model = \app\models\Auction::find()->where(['cat_id' => $category->cat_id])->all();


        $byid = Yii::$app->params['me']->buyer->by_id;
        if ($byid) {
            $dataProvider = new \yii\data\ActiveDataProvider([
                'query' => \app\models\Auction::find()->where(['by_id' => $byid])->orderBy('auc_id DESC'),
                'pagination' => [
                    'pageSize' => 10,
                ],
            ]);

            return $this->render('history', ['listDataProvider' => $dataProvider]);
        }


//        $this->view->title = 'Posts List';
//        Helper::pp($model);
//        die();
//        return $this->render('listing',['model'=>$model]);
    }

    function prepare_round_data_from_previous($model) {
        $nextRound = $model->auc_round + 1;
        if ($nextRound > $model->auc_rounds)
            return NULL;

        if ($this->setGrid($model, $nextRound) && $this->setInvitation($model, $nextRound) && $this->setFile($model, $nextRound)) {
            return TRUE;
        }
        return FALSE;
    }

    /*
     * Fetching griddata data from previous round.
     * @param $model => auction model, $round = target round no
     * @returns true if successful false otherwise
     */

    function setGrid($model, $round) {
        $griddata_old = \app\models\GridData::find()->where(['auc_id' => $model->auc_id, 'auc_round' => $model->auc_round])->one();

        //check whether grid data is already exist
        $griddata_new = \app\models\GridData::find()->where(['auc_id' => $model->auc_id, 'auc_round' => $round])->one();
        if (isset($griddata_new->auc_id))
            return FALSE;

//        \app\components\Helper::pp($griddata_old);
//        
//        return '';
        $griddata_new = new \app\models\GridData();
        $griddata_new->auc_id = $model->auc_id;
        $griddata_new->auc_round = $round;
        $griddata_new->gdd_meta = $griddata_old->gdd_meta;
        $griddata_new->gdd_rate = $griddata_old->gdd_rate;
        return $griddata_new->save();
    }

    /*
     * Sending invitations to old sellers. 
     * @param $model => auction model, $round = target round no
     * @returns true if successful false otherwise
     */

    function setInvitation($model, $round) {
        $invitation_old = \app\models\Invitation::find()->where(['auc_id' => $model->auc_id, 'invt_round' => $model->auc_round])->all();

        //sending invitation to existing sellers
        foreach ($invitation_old as $old) {
            $new_invitation_cnt = \app\models\Invitation::find()->where(['auc_id' => $model->auc_id, 'invt_round' => $round])->count();

            if ($new_invitation_cnt == 0) {
                $new_invitation = new \app\models\Invitation();
                $new_invitation->sl_id = $old->sl_id;
                $new_invitation->auc_id = $old->auc_id;
                $new_invitation->invt_round = $round;
                $new_invitation->invt_email_sent = \app\models\Invitation::STATUS_EMAIL_PENDING;
                $new_invitation->save();
            }
        }

        //sending invitation to offline (not already registered ) sellers 
        $invitation_email_old = \app\models\InvitationEmail::find()->where(['auc_id' => $model->auc_id, 'invte_round' => $model->auc_round])->one();

        if (!isset($invitation_email_old->auc_id))
            return TRUE;

        $invitation_email_new = \app\models\InvitationEmail::find()->where(['auc_id' => $model->auc_id, 'invte_round' => $round])->one();
        if (!isset($invitation_email_new->auc_id)) {
            $invitation_email_new = new \app\models\InvitationEmail();
            $invitation_email_new->auc_id = $invitation_email_old->auc_id;
            $invitation_email_new->invte_email_list = $invitation_email_old->invte_email_list;
            $invitation_email_new->invte_round = $round;
            $invitation_email_new->save();
        }


        return TRUE;
    }

    /*
     * Copying auction files from older to new round. 
     * @param $model => auction model, $round = target round no
     * @returns true if successful false otherwise
     */

    function setFile($model, $round) {
        $auction_file_old = \app\models\AuctionFile::find()->where(['auc_id' => $model->auc_id, 'auc_round' => $model->auc_round])->all();

        foreach ($auction_file_old as $old) {
            $auction_file_new = \app\models\AuctionFile::find()->where(['auc_id' => $model->auc_id, 'auc_round' => $round])->count();
            if ($auction_file_new == 0) {
                $auction_file_new = new \app\models\AuctionFile();
                $auction_file_new->auc_id = $old->auc_id;
                $auction_file_new->auc_round = $round;
                $auction_file_new->aucf_name = $old->aucf_name;
                $auction_file_new->aucf_path = $old->aucf_path;
                $auction_file_new->save();
            }
        }

        return TRUE;
    }

    function actionValidationAuctionData() {

        $post = Yii::$app->request->post();
        \app\components\Helper::pp($post);
        die();

        $model = new \app\models\AuctionData();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    }

    public function publishAuctionByRound($model, $round) {
        switch ($round) {
            case 1: {
                    $model->auc_round = $round;
                    $model->auc_status = Auction::STATUS_ACTIVE;
                    return $model->save();
                }
            case 2: {
                    $valid = TRUE;
                    if ($model->auc_type == Auction::AUCTION_TYPE_PRIVATE) {
                        $model->auc_round = $round;
                        $model->auc_status = Auction::STATUS_ACTIVE;
                        $valid = $valid && $model->save();
                        if ($valid) {
                            $old_auctiondata = AuctionData::find()->where(['auc_id' => $model->auc_id, 'auc_round' => 1])->one();
                            $old_auctiondata->edit_lock = AuctionData::EDIT_LOCK_ON;
                            $valid = $valid && $old_auctiondata->save();
                        }
                    }
                    return $valid;
                }
            case 3: {
                    $valid = TRUE;
                    if ($model->auc_type == Auction::AUCTION_TYPE_PRIVATE) {
                        $model->auc_round = $round;
                        $model->auc_status = Auction::STATUS_ACTIVE;
                        $valid = $valid && $model->save();
                        if ($valid) {
                            $old_auctiondata = AuctionData::find()->where(['auc_id' => $model->auc_id, 'auc_round' => 2])->one();
                            $old_auctiondata->edit_lock = AuctionData::EDIT_LOCK_ON;
                            $valid = $valid && $old_auctiondata->save();
                        }
                    }
                    return $valid;
                }

            default:
                break;
        }

        return NULL;
    }

}
