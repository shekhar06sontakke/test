<?php

namespace app\controllers;

use Yii;
use app\models\Seller;
use app\models\Buyer;
use app\models\User;
use app\models\Profile;
use app\models\NewUserCreateForm;

class UserController extends \yii\web\Controller {

    public function actionIndex() {
        return $this->render('index');
    }

    public function actionCreate() {

        $model = new NewUserCreateForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->createuser()) {
                return $this->redirect(['basicprofile', 'id' => $user->id]);
            }
        }
        return $this->render('create', [
                    'model' => $model,
        ]);
    }

    public function actionBasicprofile($id) {
        $model = Profile::findOne($id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['basicprofile', 'id' => $model->id]);
        }
//          \app\components\Helper::pp($model);
        return $this->render('basicprofile', ['model' => $model]);
    }

    public function actionCompany($id) {
        $profile = Profile::findOne($id);
        $account_type = $profile->account_type;
        if ($account_type == \app\models\User::USER_TYPE_BUYER) {
            $model = Buyer::find()->where(['id' => $id])->one();

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                \Yii::$app->getSession()->setFlash('success', 'Profile updated successfully!');
            }

            return $this->render('company', ['model' => $model]);
        } elseif ($account_type == \app\models\User::USER_TYPE_SELLER) {
            $model = \app\models\Seller::find()->where(['id' => $id])->one();

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                \Yii::$app->getSession()->setFlash('success', 'Profile updated successfully!');
            }

//            \app\components\Helper::pp($model->errors);
            return $this->render('company', ['model' => $model]);
        }
    }

    public function actionChooseCategory($id) {

        $sl = Seller::find()->where(['id' => $id])->one();
        $sl_id = $sl->sl_id;
//        \app\components\Helper::pp($sl);
//        echo $sl_id = Yii::$app->params['me']->seller->sl_id;
        $model = \app\models\SellerCategoryAssignment::find()->where(['sl_id' => $sl_id])->all();
        $selected = [];
        if ($model) {
            foreach ($model as $mod) {
                $selected[] = $mod->cat_id;
            }
        }
        return $this->render('choose-category', ['model' => $model, 'selected' => $selected]);
    }

    public function actionTask() {

        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $get = Yii::$app->request->get();
//            \app\components\Helper::pp($get);
            switch ($get['task']) {
                case 'remove-logo-file': {
                        $seller = Seller::find()->where(['id' => $id])->one();
                        $sl_id = $seller->sl_id;
                        //$seller = Yii::$app->params['me']->seller;
                        $seller->ph_id = NULL;
                        if ($seller->save()) {
                            return [
                                'status' => 'success',
                                'msg' => 'done',
                            ];
                        }
                        break;
                    }

                default:
                    break;
            }
//            
        }
    }

}
