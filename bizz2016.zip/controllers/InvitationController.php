<?php

namespace app\controllers;

use app\models\Buyer;
use Yii;
use app\components\Helper;

class InvitationController extends \yii\web\Controller {

    public function actionIndex() {
        return $this->render('index');
    }
    public function actionConfirm($email) {
        // mode already registered : arm
        // mode new member registration : nmr
        
        return $this->render('index');
    }


}
