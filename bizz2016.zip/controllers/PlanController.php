<?php

namespace app\controllers;

use app\models\Plan;
use Yii;

class PlanController extends \yii\web\Controller {
     public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','update','create','update-duration'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }
    

    /**
     * Lists all Plan models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new \app\models\PlanSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new Plan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new \app\models\Plan();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['update', 'id' => $model->pln_id]);
        } else {
            return $this->render('create', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Plan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $reward = new \app\models\PlanRewardForm();
        $reward->loadOldData($model->rewards);
        $reward->pln_id = $id;

//        \app\components\Helper::pp($reward);
//        die();
        if ($reward->load(Yii::$app->request->post()) && $reward->save()) {
            
        }


        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['update', 'id' => $model->pln_id]);
        }

        return $this->render('update', [
                    'model' => $model,
                    'reward' => $reward,
        ]);
    }

    public function actionUpdateDuration($id = NULL, $tab = NULL) {
        if ($id) {
            $model = \app\models\PlanDuration::findOne($id);
        } else {
            $model = new \app\models\PlanDuration();
        }
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['update', 'id' => $model->pln_id,'tab'=> $tab]);
        }
    }

    /**
     * Finds the Plan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Plan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Plan::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
