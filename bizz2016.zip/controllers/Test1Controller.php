<?php

namespace app\controllers;

use app\models\Buyer;
use Yii;

//class a {
//
////    public static $company_info;
//
////    public $custom_advertisement;
////    public $backlink;
////    public $category_limit;
////    public $bid_limit;
//
//    function __construct() {
//
////        self::set_company_info();
////        $this->item = new b();
//    }
//
//    public static function company_info() {
//        return new attribute('comp_info', \app\components\Helper::getData());
//    }
//
//}
//
//class attribute {
//
//    public $name;
//
//    function __construct($name, $data) {
//        foreach ($data[$name] as $key => $val) {
//            if (!is_array($val)) {
//                $this->{$key} = $val;
//            }
//        }
//    }
//
//}

class TestController extends \yii\web\Controller {

    public function actionIndex() {

//        $model = new \app\models\Plan();
//        $model->pln_name = 'First';
//        $model->pln_short_description = 'first plan';
//        $model->pln_currency = 'INR';
//        $model->pln_price = 900;
//        $model->pln_duration = 90;
//        $model->save();
//        \app\components\Helper::pp($model);

//        $model = new \app\models\PlanReward();
//        $model->pln_id = 1;
//        $model->rwt_id = 1;
//        $model->plr_value = 0;
//        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 2;
        $model->plr_value = 0;
        $model->save();
        
        
//        \app\components\Helper::pp($model);
//        die();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 3;
        $model->plr_value = 0;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 4;
        $model->plr_value = \app\models\PlanReward::STATUS_ON;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 5;
        $model->plr_value = \app\models\PlanReward::STATUS_ON;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 6;
        $model->plr_value = \app\models\PlanReward::STATUS_OFF;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 7;
        $model->plr_value = \app\models\PlanReward::STATUS_OFF;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 8;
        $model->plr_value = \app\models\PlanReward::STATUS_OFF;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 9;
        $model->plr_value = \app\models\PlanReward::STATUS_OFF;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 10;
        $model->plr_value = \app\models\PlanReward::STATUS_OFF;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 11;
        $model->plr_value = 1;
        $model->save();

        $model = new \app\models\PlanReward();
        $model->pln_id = 1;
        $model->rwt_id = 12;
        $model->plr_value = 0;
        $model->save();

//        $obj = new a();
//        \app\components\Helper::pp(a::company_info());
//        \app\components\Helper::pp( new foo()->sda()) );
        // $obj->company_info()->name->font_weight
//this is currency code
//         $data = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
//       \app\components\Helper::pp($data);
//        \Yii::$app->mailer->compose('contact/welcome',['params' => ['name' => 'shekhar'], ])                
//                ->setFrom(['admin@meravivah.com' => 'Test Mail ny shekhar'])
//                ->setTo('shekhar06sontakke@gmail.com')
//                ->setSubject('This is a test mail by shekhar ')
//                ->send();
    }

    public function actionInvitation() {
        $this->layout = '';
        return $this->render('invitation');
    }

//    public function actionGrid() {
//
//        return $this->render('grid');
//    }
//
//    public function actionUpload() {
//
//        return $this->render('upload');
//    }
}
