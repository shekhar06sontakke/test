<?php

namespace app\controllers;

use app\models\Buyer;
use Yii;
use yii\web\UploadedFile;

class ProfileController extends \yii\web\Controller {
    public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','company','create','basic','buyer','seller','validation','change-profile-photo',
                            'company-logo','choose-category','task'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }

    public function actionIndex() {
        $model = Yii::$app->params['me'];

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $post = Yii::$app->request->post();
            $model->setScenario($model->scenario);

            if ($model->save()) {
                return [
                    'status' => 'success',
                    'msg' => 'Saved.'
                ];
            } else {

                return ActiveForm::validate($model);
            }
        }

        return $this->render('index', ['model' => $model]);
    }

    public function actionCreate() {

        $model = new \app\models\NewUserCreateForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->createuser()) {
                return $this->redirect(['basic', 'id' => $user->id]);
            }
        }
        return $this->render('create', [
                    'model' => $model,
        ]);
    }

    function actionCompany($id) {

        $user = \app\models\User::findOne($id);
//        $model = 
//            \app\components\Helper::pp($model);
        if ($user->account_type == \app\models\User::USER_TYPE_BUYER) {
            $model = Buyer::find()->where(['id' => $user->id])->one();

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                \Yii::$app->getSession()->setFlash('success', 'Profile updated successfully!');
            }

            return $this->render('company', ['model' => $model]);
        } elseif ($user->account_type == \app\models\User::USER_TYPE_SELLER) {
            $model = \app\models\Seller::find()->where(['id' => $user->id])->one();

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                \Yii::$app->getSession()->setFlash('success', 'Profile updated successfully!');
            }

//            \app\components\Helper::pp($model->errors);
            return $this->render('company', ['model' => $model]);
        }
    }

    public function actionBasic($id) {
        $model = \app\models\Profile::findOne($id);
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return ['status' => 'success', 'msg' => 'Saved'];
        }


        return $this->render('basic', ['model' => $model]);
    }

    public function actionBuyer() {
        $model = new Buyer();

        if ($model->load(Yii::$app->request->post())) {
            if ($model->validate()) {
                // form inputs are valid, do something here
                return;
            }
        }

        return $this->render('buyer', [
                    'model' => $model,
        ]);
    }

    public function actionSeller() {
        $model = new Seller();

        if ($model->load(Yii::$app->request->post())) {
            if ($model->validate()) {
                // form inputs are valid, do something here
                return;
            }
        }

        return $this->render('seller', [
                    'model' => $model,
        ]);
    }

    public function actionValidation($id) {
        $model = \app\models\Profile::findOne($id);
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
//            \app\components\Helper::pp($model);
//            die();
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $model->setScenario($model->scenario);
            return \yii\widgets\ActiveForm::validate($model);
        }
    }

    public function actionChangeProfilePhoto() {
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $post = Yii::$app->request->post();
            $upload = new \app\models\UploadForm();
            $params = json_decode($post['params']);
            $me = \app\models\Profile::findOne($params->userid);
            $upload->imageFile = \yii\web\UploadedFile::getInstanceByName('file');
            if ($file = $upload->upload()) {
//                \app\components\Helper::pp($file);
                $model = new \app\models\Photo();
                $model->id = $params->userid;
                $model->ph_name = $file['name'];
                $model->ph_path = $file['path'];
                if ($model->save() && $me->setPhoto($model->ph_id)) {
                    $filename = '/' . $model->ph_path . '/' . $model->ph_name;

                    return [
                        'status' => 'success',
                        'file' => $filename,
                    ];
                }
            }
        }
    }

    public function actionCompanyLogo() {
        if (Yii::$app->request->isAjax) {

            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $upload = new \app\models\UploadForm();
            $post = Yii::$app->request->post();

             $params = json_decode($post['params']);
            $upload->imageFile = \yii\web\UploadedFile::getInstanceByName('file');
            if ($file = $upload->upload()) {

//                \app\components\Helper::pp($params);
//                die();

                $ph = new \app\models\Photo();
                $ph->id = (int) $params->userid;
                $ph->ph_name = $file['name'];
                $ph->ph_path = $file['path'];
                $ph->ph_type = 'COMLOG';
                if ($ph->save()) {
                    $model = \app\models\Seller::find()->where(['id' => $params->userid])->one();
                    $model->ph_id = $ph->ph_id;
                    if ($model->save()) {
                        $file['fileID'] = $ph->ph_id;
                        return [
                            'status' => 'success',
                            'file' => $file,
                        ];
                    }
                }
            }

//            \app\components\Helper::pv($file);
        }
    }

    public function actionChooseCategory() {
        $sl_id = Yii::$app->params['me']->seller->sl_id;
//        \app\components\Helper::pp($sl_id);
        $model = \app\models\SellerCategoryAssignment::find()->where(['sl_id' => $sl_id])->all();
        $selected = [];
        if ($model) {
            foreach ($model as $mod) {
                $selected[] = $mod->cat_id;
            }
        }
        return $this->render('choose-category', ['model' => $model, 'selected' => $selected]);
    }

    public function actionTask() {

        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $get = Yii::$app->request->get();
//            \app\components\Helper::pp($get);
            switch ($get['task']) {
                case 'remove-logo-file': {
                        $seller = Yii::$app->params['me']->seller;
                        $seller->ph_id = NULL;
                        if ($seller->save()) {
                            return [
                                'status' => 'success',
                                'msg' => 'done',
                            ];
                        }
                        break;
                    }

                default:
                    break;
            }
//            
        }
    }

}
