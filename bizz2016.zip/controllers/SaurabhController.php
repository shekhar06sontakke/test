<?php

namespace app\controllers;

use app\models\Buyer;
use app\models\User;
use Yii;
use app\components\Helper;

class SaurabhController extends \yii\web\Controller {

    public function actionIndex() {

        //Model - user
        //Values - email, token key
        //Action - sendemail, checktoken 

        $id = Yii::$app->user->id;
        $model = User::find()->where(['id' => $id])->one();
        $email = $model->email;
        $token =  Yii::$app->security->generateRandomString(32);
        //Helper::pp($token);
        
        $model->email_token = $token;
        $model->save();
        
        //Helper::pp($model);
        echo "<br><br><br><br>";
        //pp($model->errors);
        echo '<pre>';
        print_r($model->errors);
        echo '</pre>';
        
        $url = \yii\helpers\Url::toRoute(['/'], true);
        $url .= 'saurabh/verifyemail?email=' . $email . "&token=" . $token;
        \Yii::$app->mailer->compose('contact/welcome',['params' => ['name' => 'shekhar'], ])                
                ->setFrom(['admin@meravivah.com' => 'Test Mail ny shekhar'])
               ->setTo('saurabh.zilpe123@gmail.com')
                ->setSubject('This is a test mail by shekhar ')
                ->send();


        return $this->render('index', ['email' => $url]);
    }

    public function actionVerifyemail() {
        $emailParams = Yii::$app->getRequest()->getQueryParams();
        //echo "Email ==".$email;
        //\Yii::$app->getSession()->setFlash('success', $email);
        echo '<pre>';
        print_r($emailParams);
        echo '</pre>';
        
        $email = $emailParams['email'];
        $token = $emailParams['token'];
        
        $id = Yii::$app->user->id;
        $model = User::find()->where(['id' => $id])->one();
        $userEmail = $model->email;
        $userToken = $model->email_token;
        
        if((strcmp($email,$userEmail)==0) && (strcmp($token,$userToken)==0))
        {
            Yii::$app->session->setFlash('success','Your email verification successful.');
            $model->email_status = User::EMAIL_VERIFICATION_SUCCESS;
            $model->save();
        }
        else
        {
            Yii::$app->session->setFlash('error','Sorry Your email verification unsuccessful.');
        }
        return $this->render('emailConfirm');
    }
    
    
    
    public function actionVerifyemail2() {
        $emailParams = Yii::$app->getRequest()->getQueryParams();
        //echo "Email ==".$email;
        //\Yii::$app->getSession()->setFlash('success', $email);
        echo '<pre>';
        print_r($emailParams);
        echo '</pre>';
    }

    public function sendEmail($email, $mode) {

        $params = [
            'siteUrl' => \yii\helpers\Url::toRoute(['/'], true),
        ];

        //$email_token = Yii::$app->user->email_token;
        $body = "Verification email test";

        switch ($mode) {
            case 'verify':
                $subject = 'Email address verification';
                break;
            default:
                return false;
        }

        \Yii::$app->mailer->compose('contact/welcome', ['params' => ['name' => 'saurabh'],])
                ->setFrom(['admin@meravivah.com' => 'Test Mail ny shekhar'])
                ->setTo($email)
                ->setSubject($subject)
                ->send();
    }

}
