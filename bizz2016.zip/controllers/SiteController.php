<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\SignupForm;
use app\models\User;
use app\components\Helper;

class SiteController extends Controller {

    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex() {
        return $this->redirect(['site/login']);
//        $buyer = new \app\models\Buyer();
//        $buyer->id = Yii::$app->user->id;
//        $buyer->save();
//        
//        Helper::pp($buyer->attributes);
//        Helper::pp($buyer->errors);
//        
//        \app\components\Helper::pp(Yii::$app->getRequest()->getUserIP());
//        \app\components\Helper::pv(\app\components\Helper::storeIP());
        return $this->render('index');
    }

    /**
     * Signs user up.
     *
     * @return mixed
     */
//    public function actionSignup() {
//        if (!Yii::$app->user->isGuest) {
//            return $this->goHome();
//        }
//
////        Helper::pp($_POST);
//
//        $model = new SignupForm();
//        if ($model->load(Yii::$app->request->post())) {
//
//            if ($user = $model->signup()) {
//                if (Yii::$app->getUser()->login($user)) {
//
//                    //send email verification
////                    $this->sendVerificationEmail($user);
//                    $model->trigger(\app\models\User::EVENT_NEW_USER);
//                    $returnurl = Yii::$app->session->get('returnurl');
//                    return $this->goBack($returnurl ? $returnurl : ['myacc/dashboard'] );                    
//                }
//            }
//        }
//
//        return $this->render('signup', [
//                    'model' => $model,
//        ]);
//    }

    public function actionVerifyemail() {
        $emailParams = Yii::$app->getRequest()->getQueryParams();
        //echo "Email ==".$email;
        //\Yii::$app->getSession()->setFlash('success', $email);
        //echo '<pre>';
        // print_r($emailParams);
        // echo '</pre>';

        $email = $emailParams['email'];
        $token = $emailParams['token'];

        $id = Yii::$app->user->id;
        $model = User::find()->where(['id' => $id])->one();
        $userEmail = $model->email;
        $userToken = $model->email_token;

        $email_status = $model->email_status;

        if (isset($email_status) && ($email_status == 10)) {
            Yii::$app->session->setFlash('success', 'Your email verification has already been completed.');
            return $this->render('emailConfirm');
        }

        if ((strcmp($email, $userEmail) == 0) && (strcmp($token, $userToken) == 0)) {
            Yii::$app->session->setFlash('success', 'Your email verification successful.');
            $model->email_status = User::EMAIL_VERIFICATION_SUCCESS;
            $model->save();
        } else {
            Yii::$app->session->setFlash('error', 'Sorry Your email verification unsuccessful.');
        }
        return $this->render('emailConfirm');
    }

    public function actionLogin() {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

//        $this->setInvitationToken($token);

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            $model->trigger(\app\models\User::EVENT_USER_LOGGED_IN);
            $returnurl = Yii::$app->session->get('returnurl');
            Yii::$app->session->set('returnurl',NULL);
            return $this->goBack($returnurl ? $returnurl : ['myacc/dashboard'] );
        }
        return $this->render('login', [
                    'model' => $model,
        ]);
    }

    public function actionLogout() {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact() {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
                    'model' => $model,
        ]);
    }

    public function actionAbout() {
        return $this->render('about');
    }

    public function actionSay($message = "Hello") {
        return $this->render('say', ['message' => $message]);
    }

    public function actionForgetPassword() {
        $session = Yii::$app->session;
        if (!$session->isActive) {
            $session->open();
        }

        $data = [ 'step' => 'find_acc', 'msg' => ''];

        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            echo "<br><br><br>";
            Helper::pp($post);


            if (isset($post['step']) && $post['step'] == 'find_acc' && $post['term']) {

                if (isset($_SESSION['rpreq']['id'])) {

                    $profile = \app\models\Profile::findOne((int) $_SESSION['rpreq']['id']);
                    $data['step'] = 'reset_method';
                    $data['profile'] = $profile;
                } else {

                    $profile = $this->find_profile_by_keyword($_POST['term']);

                    if ($profile) {
                        //$_SESSION['rpreq'] = ['id' => $profile->id];
                        $data['step'] = 'reset_method';
                        $data['profile'] = $profile;
                    } else {

                        $data['step'] = 'find_acc';
                        $data['msg'] = 'Sorry! no profile found matching your criteria.';
                    }
                }
            }
        }


        return $this->render('forget-password', ['data' => $data]);
    }

    function find_profile_by_keyword($term) {
        $find = \app\models\Profile::find()->where(['email' => $term])
                ->orWhere(['mobile' => $term])
                ->orWhere(['username' => $term])
                ->one();
//                ->orWhere(['wm_code'=> $term])
//        $find = Users::find('first', ['conditions' => ['email=? OR mobile=? OR wm_code=? OR id=?', $term, $term, $term, $term], 'select' => 'id,email,mobile,wm_code,simage,path,country_code,mobile_verification_code']);
        return $find ? $find : false;
    }

    /*
     * send verification email after successful registration
     * @return 
     */

    public function sendVerificationEmail($user) {
        $id = Yii::$app->user->id;
        $email = $user->email;
        $user->sendEmail($id, $email);
    }

    public function setInvitationToken($token) {
        if (!$token)
            return FALSE;

        $auctiondata = \app\models\AuctionData::find()->where(['aucd_token' => $token])->one();
        if (isset($auctiondata->aucd_id)) {
            
        }
    }

}
