<?php

namespace app\controllers;

use Yii;
use app\models\Seller;
use app\models\Buyer;
use app\models\User;

class MyaccController extends \yii\web\Controller {
     public function behaviors() {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::className(),                
                'rules' => [
                    [
                        'actions' => ['index','notification','dashboard'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],            
        ];
    }

    public function actionIndex() {
        
    }

    public function actionNotification() {
        return $this->render('notification');
    }

    public function actionDashboard() {
        return $this->render('dashboard');
    }

   

}
