<?php

namespace app\components;

use Yii;

class OptionList {

    public static function getGender($param = NULL) {
        $arr = [
            'male' => '10',
            'female' => '20'
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_nature_of_company($param = NULL) {
        $arr = [
            '1' => 'Proprietory',
            '2' => 'Pvt.Limited',
            '3' => 'P.S.U.',
            '4' => 'Partnership',
            '5' => 'Public Limited Company'
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_category_of_industry($param = NULL) {
        $arr = [
            '1' => 'Large Scale',
            '2' => 'Medium Scale',
            '3' => 'Small Scale',
            '4' => 'Others',
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_nature_of_business($param = NULL) {
        $arr = [
            '1' => 'Large Scale',
            '2' => 'Medium Scale',
            '3' => 'Small Scale',
            '4' => 'Others',
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_bank_account_type($param = NULL) {
        $arr = [
            'CURR' => 'current deposits / accounts',
            'SVNG' => 'saving bank / saving fund  deposits / accounts',
            'RECU' => 'recurring deposits / accounts',
            'FIXD' => 'fixed deposits / accounts or term deposits',
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_auction_type($param = NULL) {
        $arr = [
            'OPEN' => 'Open',
            'PRIV' => 'Private',
        ];

        if ($param && isset($arr[$param])) {
            return $arr[$param];
        }

        if (!$param) {
            return $arr;
        }
    }

    public static function get_plan_durations($param = NULL) {
        $arr = [
            '30' => '1 Month',
            '91' => '3 Month',
            '182' => '6 Month',
            '365' => '12 Month',
        ];

        if (isset($arr[$param]))
            return $arr[$param];
        else
            return $arr;
    }

}
