<?php

namespace app\components;

use Yii;
use DateTime;

class Helper {

    public static function pp($param) {
        echo '<pre>';
        print_r($param);
        echo '</pre>';
    }

    public static function pv($param) {
        echo '<pre>';
        var_dump($param);
        echo '</pre>';
    }

    public static function storeIP($id = NULL) {
        if (!\Yii::$app->user->isGuest) {
            $id = ( $id ? $id : Yii::$app->user->id);
            $model = \app\models\User::findOne($id);
            $model->last_login_ip = Yii::$app->getRequest()->getUserIP();
            $model->save();
        }
    }

    public static function get_hashed_str($str, $type) {

        switch ($type) {
            case 'email': {
                    $ex_email = explode('@', $str);
                    $str_len = strlen((string) $ex_email[0]);
                    return substr((string) $ex_email[0], 0, 1) . str_pad('', ($str_len - 4), '*') . substr((string) $ex_email[0], -3) . '@' . $ex_email[1];
                }
            case 'mobile': {
                    $str_len = strlen((string) $str);
                    return substr((string) $str, 0, 1) . str_pad('', ($str_len - 4), '*') . substr((string) $str, -3);
                }

            default:
                return false;
        }
    }

    public static function clean_string($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    }

    public static function getDifferenceBetweenDates($date1, $date2) {
        $datetime1 = new DateTime(date('Y-m-d H:i:s', $date1));
        //86340 = ( 24 hr - 1 minute)


        $datetime2 = new DateTime(date('Y-m-d H:i:s', $date2 + 86340));

        $difference = $datetime1->diff($datetime2);

//        Helper::pp($datetime1);
//        Helper::pp($datetime2);        
//        Helper::pp($difference);
        return ['day' => $difference->d, 'hour' => $difference->h];
//        Helper::pp($datetime1);
//        Helper::pp($datetime2);
//        Helper::pp($difference);
    }

    public static function setReturnUrl($url) {
        Yii::$app->session->set('returnurl', $url);
    }

    public static function isJson($string) {
        json_decode($string);
        return (json_last_error() == JSON_ERROR_NONE);
    }

    public static function getData() {
        return [
            'comp_info' => [
                'name' => [
                    'font_weight' => 'bold',
                    'color' => 'red'
                ],
                'contact_person' => 'true',
                'email' => true,
                'phone' => true,
                'logo' => false,
                'short_desc' => ['char_limit' => 100],
            ],
            'advt' => [
                'size' => '12x12',
                'scope' => 'full-site'
            ],
            'backlink' => 'yoursite.com',
            'category_limit' => '3',
            'bid_limit' => '12'
        ];
    }
    
     static public function prepare_timestamp_from_date($date) {
        $date = str_replace('/', '-', $date);
        if ($str = strtotime($date))
            return $str;

        return NULL;
    }
    
    
    public static function _date($datetime, $format = null, $options = []) {
        $def = [
            'timezone' => Yii::$app->params['timezone'],
        ];
        $options = array_merge($def, $options);
        
//        Helper::pp($datetime);
//        Helper::pp(date_default_timezone_get());
        $formatter = new \yii\i18n\Formatter;
        $formatter->timeZone = $options['timezone'];
        $format = 'php:' . ( $format ? $format : Yii::$app->params['dateFormat']);
        $d=  $formatter->asDatetime($datetime, $format);
        return $d;
    }

    public static function toUTC($datetime, $format = 'U') {
        if (!$datetime)
            return NULL;
        $date = new \DateTime($datetime, new \DateTimeZone(Yii::$app->params['timezone']));
        $date->setTimezone(new \DateTimeZone('UTC'));
        return $date->format($format);
    }

}
