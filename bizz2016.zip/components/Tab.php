<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace app\components;

/**
 * Description of ActiveTab
 *
 * @author ABC
 */
class Tab {

    public $tab;

    public function __construct($tab) {
        $this->tab = $tab;
    }

    public function is_active($tab) {
        if (isset($_GET['tab']) && $_GET['tab'] == $tab) {
            return 'active';
        } elseif (!isset($_GET['tab']) && $tab == $this->tab) {
            return 'active';
        } else {
            return '';
        }
    }

}
