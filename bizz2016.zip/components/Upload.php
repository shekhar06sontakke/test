<?php

namespace app\components;

class Upload {

    function __construct() {
        
    }
    
    

}
