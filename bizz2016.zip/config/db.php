<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=bizjunction',
    'username' => 'bizjunction',
    'password' => 'bizjunction',
    'charset' => 'utf8',
];
