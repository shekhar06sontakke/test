<?php

return [
    'adminEmail' => 'admin@example.com',
    'uploadDir' => 'c:/wamp/www/bizjunction/web/upload',
    'siteUrl' => 'http://bizjunction.local',
    'timezone' => 'Asia/Kolkata',
    'dateFormat' => 'd/m/Y',
    'timeFormat' => 'H:i:s',
    'datetimeFormat' => 'd/m/Y H:i:s',
];
