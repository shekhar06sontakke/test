<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "seller_category_assignment".
 *
 * @property integer $sca_id
 * @property integer $sl_id
 * @property integer $cat_id
 * @property integer $created_at
 * @property integer $updated_at
 */
class SellerCategoryAssignment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'seller_category_assignment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sl_id', 'cat_id'], 'integer'],
            [['sl_id', 'cat_id'], 'required']
        ];
    }
    
       public function behaviors() {
        return [
//            [
//                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
//            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sca_id' => 'Sca ID',
            'sl_id' => 'Sl ID',
            'cat_id' => 'Cat ID',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
      public function getSeller() {
        return $this->hasOne(Seller::className(), ['sl_id' => 'sl_id']);
    }
      public function getCategory() {
        return $this->hasOne(Category::className(), ['cat_id' => 'cat_id']);
    }
}
