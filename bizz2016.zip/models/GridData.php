<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "grid_data".
 *
 * @property integer $gdd_id
 * @property integer $auc_id
 * @property integer $gdd_row
 * @property string $gdd_value
 */
class GridData extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'grid_data';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['gdd_meta','gdd_rate','auc_round'], 'required'],
            [['auc_id','auc_round'], 'integer'],
            [['gdd_meta','gdd_rate'], 'string']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'gdd_id' => 'ID',
            'auc_id' => 'Auction ID',
            'gdd_row' => 'Row',            
            'gdd_meta' => 'Meta',
            'gdd_rate' => 'Rate',
        ];
    }
}
