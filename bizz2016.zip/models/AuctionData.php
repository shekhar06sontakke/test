<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auction_data".
 *
 * @property integer $aucd_id
 * @property integer $auc_id
 * @property integer $auc_round
 * @property integer $aucd_start_date
 * @property integer $aucd_end_date
 * @property string $aucd_file
 * @property string $aucd_path
 * @property integer $edit_lock
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class AuctionData extends \yii\db\ActiveRecord {

    const SCENARIO_BASIC_INFO = 'auc_bi';
    const SCENARIO_UPDATE_DURATION = 'auc_dur';
    const EDIT_LOCK_ON = 20;
    const EDIT_LOCK_OFF = 5;

    public $t_aucd_start_date;
    public $t_aucd_end_date;
    public $scenario;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'auction_data';
    }

    public function init($scenario = NULL) {
        if ($scenario) {
            $this->scenario = self::SCENARIO_UPDATE_DURATION;
            $this->setScenario(self::SCENARIO_UPDATE_DURATION);
        }

        return parent::init();
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['auc_id', 'auc_round'], 'required'],
            [['t_aucd_start_date', 't_aucd_end_date'], 'required', 'on' => self::SCENARIO_UPDATE_DURATION],
            [['t_aucd_start_date', 't_aucd_end_date'], 'date', 'format' => 'dd/MM/yyyy'],
            [['t_aucd_start_date', 't_aucd_end_date'], 'safe'],
            [['auc_id', 'auc_round', 'auc_status', 'aucd_start_date', 'aucd_end_date', 'edit_lock'], 'integer'],
            [['aucd_file', 'aucd_path','aucd_token'], 'string']
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'aucd_id' => 'Aucd ID',
            'auc_id' => 'Auc ID',
            'auc_round' => 'Auc Round',
            'aucd_start_date' => 'Start Date',
            'aucd_end_date' => 'End Date',
            't_aucd_start_date' => 'Start Date',
            't_aucd_end_date' => 'End Date',
            'aucd_file' => 'Aucd File',
            'aucd_path' => 'Aucd Path',
            'edit_lock' => 'Edit Lock',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function beforeSave($insert) {
        if ($insert) {
            $this->edit_lock = self::EDIT_LOCK_OFF;
        }

        if ($str = $this->prepare_timestamp_from_date($this->t_aucd_start_date)) {
            $this->aucd_start_date = $str;
        }
        if ($str = $this->prepare_timestamp_from_date($this->t_aucd_end_date)) {
            $this->aucd_end_date = $str;
        }

        return parent::beforeSave($insert);
    }

    public function afterFind() {
        if ($this->aucd_start_date)
            $this->t_aucd_start_date = date('d/m/Y', $this->aucd_start_date);

        if ($this->aucd_end_date)
            $this->t_aucd_end_date = date('d/m/Y', $this->aucd_end_date);


//        $this->updateStatus();

        return parent::afterFind();
    }

    public function prepare_timestamp_from_date($date) {
        $date = str_replace('/', '-', $date);
        if ($str = strtotime($date))
            return $str;

        return NULL;
    }
    

}
