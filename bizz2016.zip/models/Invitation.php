<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "invitation".
 *
 * @property integer $invt_id
 * @property integer $sl_id
 * @property integer $auc_id
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Invitation extends \yii\db\ActiveRecord {
    const STATUS_EMAIL_SUCCESS = '20';
    const STATUS_EMAIL_PENDING = '10';
    const STATUS_READ = '10';
    const STATUS_UNREAD = '0';

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'invitation';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['sl_id', 'auc_id','invt_round'], 'required'],
            [['sl_id', 'auc_id','invt_round'], 'integer']
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'invt_id' => 'Invt ID',
            'sl_id' => 'Sl ID',
            'auc_id' => 'Auc ID',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getSeller() {
        return $this->hasOne(Seller::className(), ['sl_id' => 'sl_id']);
    }
    public function getAuction() {
        return $this->hasOne(Auction::className(), ['auc_id' => 'auc_id']);
    }

}
