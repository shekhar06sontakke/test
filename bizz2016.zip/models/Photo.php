<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "photo".
 *
 * @property integer $ph_id
 * @property integer $id
 * @property string $ph_name
 * @property string $ph_path
 * @property integer $created_at
 * @property integer $updated_at
 */
class Photo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'photo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ph_name', 'ph_path','id'], 'required'],
            [['id'], 'integer'],
            [['ph_name', 'ph_path'], 'string']
        ];
    }
    
     public function behaviors() {
        return [
//            [
//                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
//            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ph_id' => 'Ph ID',
            'id' => 'ID',
            'ph_name' => 'Ph Name',
            'ph_path' => 'Ph Path',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
