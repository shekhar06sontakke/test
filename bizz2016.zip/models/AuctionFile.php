<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auction_file".
 *
 * @property integer $aucf_id
 * @property integer $auc_id
 * @property integer $aucf_name
 * @property integer $aucf_path
 * @property integer $created_at
 * @property integer $updated_at
 */
class AuctionFile extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'auction_file';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
        [['auc_id', 'aucf_name','auc_id','auc_round', 'aucf_path'], 'required'],
        [['auc_id','auc_round'], 'integer'],
        [['aucf_name', 'aucf_path'], 'string']
        ];
    }
    
    public function behaviors() {
        return [
//            [
//                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
//            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'aucf_id' => 'Aucf ID',
            'auc_id' => 'Auction ID',
            'auc_round' => 'Round',
            'aucf_name' => 'Name',
            'aucf_path' => 'Path',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

}
