<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "category".
 *
 * @property integer $cat_id
 * @property integer $caty_id
 * @property string $cat_slug
 * @property string $cat_name
 *
 * @property CategoryType $caty
 */
class Category extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'category';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['caty_id'], 'string'],
            [['cat_slug', 'cat_name'], 'required'],
            [['cat_slug', 'cat_name'], 'string', 'max' => 100],
            ['cat_slug', 'unique', 'targetClass' => '\app\models\Category', 'message' => 'This slug has already been taken.'],
//            [['cat_slug'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'cat_id' => 'ID',
            'caty_id' => 'Category Name :',
            'cat_name' => 'Name :',
            'cat_slug' => 'Slug :',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategorytype() {
        return $this->hasOne(CategoryType::className(), ['caty_id' => 'caty_id']);
    }

    public static function getHierarchy() {
        $options = [];

        $parents = CategoryType::find()->all();
        foreach ($parents as $id => $p) {
            $children = self::find()->where("caty_id=:parent_id", [":parent_id" => $p->caty_id])->all();
            $child_options = [];
            foreach ($children as $child) {
                $child_options[$child->cat_id] = $child->cat_name;
            }
            $options[$p->caty_name] = $child_options;
        }
        return $options;
    }

}
