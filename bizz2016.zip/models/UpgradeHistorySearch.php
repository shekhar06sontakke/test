<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\UpgradeHistory;

/**
 * UpgradeHistorySearch represents the model behind the search form about `app\models\UpgradeHistory`.
 */
class UpgradeHistorySearch extends UpgradeHistory
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['upgh_id', 'id', 'pln_id', 'pld_duration', 'upgh_txnid', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['upgh_currency', 'upgh_pay_method'], 'safe'],
            [['upgh_amount'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = UpgradeHistory::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'upgh_id' => $this->upgh_id,
            'id' => $this->id,
            'pln_id' => $this->pln_id,
            'pld_duration' => $this->pld_duration,
            'upgh_amount' => $this->upgh_amount,
            'upgh_txnid' => $this->upgh_txnid,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'upgh_currency', $this->upgh_currency])
            ->andFilterWhere(['like', 'upgh_pay_method', $this->upgh_pay_method]);

        return $dataProvider;
    }
}
