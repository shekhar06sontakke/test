<?php

namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class UploadForm extends Model {

    /**
     * @var UploadedFile
     */
    public $imageFile;
    public $allowedExtensions = "png,jpg,docx,pdf,doc,xls,xlsx";
    public $currentUploadDir = "";
    public $new_filename;

    public function init() {
        $this->prepareUploadDir();

        return parent::init();
    }

    public function rules() {
        return [
            [['imageFile'], 'file', 'skipOnEmpty' => false, 'extensions' => $this->allowedExtensions],
        ];
    }

    public function upload() {
        if ($this->validate()) {
            $this->new_filename = $this->getNewName($this->imageFile->baseName) . '.' . $this->imageFile->extension;
            if ($this->imageFile->saveAs($this->currentUploadDir . '/' . $this->new_filename))
                return ['name' => $this->new_filename, 'path' => 'upload/' . date('Y') . '/' . date('m')];
        } else {
            return false;
        }
    }

    public function prepareUploadDir() {
        $uploadDIR = \Yii::$app->params['uploadDir'] . '/' . date('Y') . '/' . date('m');
        $this->prepare_dir($uploadDIR);
        $this->currentUploadDir = $uploadDIR;
    }

    public function prepare_dir($dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0777, TRUE);
            $myfile = fopen($dir . "/index.php", "w") or die("Unable to open file!");
            fclose($myfile);
            return true;
        } else {
            return true;
        }
    }

    public function setValidExtensions($exts = "") {
        $this->allowedExtensions = $exts;
    }

    public function getNewName($temp_image_name) {
        return strtolower(\app\components\Helper::clean_string($temp_image_name . mt_rand(10, 100) . time()));
    }

}
