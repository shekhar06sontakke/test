<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "plan_duration".
 *
 * @property integer $pld_id
 * @property integer $pln_id
 * @property integer $pld_duration
 * @property string $pld_currency
 * @property double $pld_price
 * @property integer $created_at
 * @property integer $updated_at
 */
class PlanDuration extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'plan_duration';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['pln_id', 'pld_duration', 'pld_currency', 'pld_price'], 'required'],
            [['pln_id', 'pld_duration'], 'integer'],
            [['pld_price'], 'number'],
            [['pld_currency'], 'string', 'max' => 3]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'pld_id' => 'ID',
            'pln_id' => 'Plan ID',
            'pld_duration' => 'Duration',
            'pld_currency' => 'Currency',
            'pld_price' => 'Price',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
