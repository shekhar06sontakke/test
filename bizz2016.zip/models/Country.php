<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "country".
 *
 * @property integer $id
 * @property integer $mobile_code
 * @property string $country_name
 * @property string $create_datetime
 * @property string $update_datetime
 */
class Country extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'country';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['mobile_code', 'country_name', 'create_datetime', 'update_datetime'], 'required'],
            [['mobile_code'], 'integer'],
            [['create_datetime', 'update_datetime'], 'safe'],
            [['country_name'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'mobile_code' => 'Mobile Code',
            'country_name' => 'Country Name',
            'create_datetime' => 'Create Datetime',
            'update_datetime' => 'Update Datetime',
        ];
    }
}
