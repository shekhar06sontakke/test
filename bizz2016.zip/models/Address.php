<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "address".
 *
 * @property integer $adr_id
 * @property integer $id
 * @property string $adr_address_text
 * @property integer $adr_pin
 * @property integer $adr_std_code_primary
 * @property integer $adr_phone_no_primary
 * @property integer $adr_std_code_secondary
 * @property integer $adr_phone_no_secondary
 * @property string $adr_email
 * @property string $adr_fax_no
 * @property integer $adr_country_code_primary
 * @property integer $adr_mobile_primary
 * @property string $adr_skype_id
 * @property string $adr_linkedin_id
 * @property string $adr_building_name
 * @property string $adr_block_no
 * @property string $adr_street
 * @property string $adr_city
 * @property string $adr_country
 * @property integer $adr_created_at
 * @property integer $adr_updated_at
 * @property integer $adr_created_by
 * @property integer $adr_updated_by
 */
class Address extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'address';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'adr_address_text', 'adr_pin', 'adr_std_code_primary', 'adr_phone_no_primary', 'adr_std_code_secondary', 'adr_phone_no_secondary', 'adr_email', 'adr_fax_no', 'adr_country_code_primary', 'adr_mobile_primary', 'adr_skype_id', 'adr_linkedin_id', 'adr_building_name', 'adr_block_no', 'adr_street', 'adr_city', 'adr_country', 'adr_created_at', 'adr_updated_at', 'adr_created_by', 'adr_updated_by'], 'required'],
            [['id', 'adr_pin', 'adr_std_code_primary', 'adr_phone_no_primary', 'adr_std_code_secondary', 'adr_phone_no_secondary', 'adr_country_code_primary', 'adr_mobile_primary', 'adr_created_at', 'adr_updated_at', 'adr_created_by', 'adr_updated_by'], 'integer'],
            [['adr_address_text'], 'string'],
            [['adr_email', 'adr_skype_id', 'adr_linkedin_id'], 'string', 'max' => 50],
            [['adr_fax_no', 'adr_block_no'], 'string', 'max' => 32],
            [['adr_building_name', 'adr_street', 'adr_city', 'adr_country'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'adr_id' => 'Adr ID',
            'id' => 'ID',
            'adr_address_text' => 'Adr Address Text',
            'adr_pin' => 'Adr Pin',
            'adr_std_code_primary' => 'Adr Std Code Primary',
            'adr_phone_no_primary' => 'Adr Phone No Primary',
            'adr_std_code_secondary' => 'Adr Std Code Secondary',
            'adr_phone_no_secondary' => 'Adr Phone No Secondary',
            'adr_email' => 'Adr Email',
            'adr_fax_no' => 'Adr Fax No',
            'adr_country_code_primary' => 'Adr Country Code Primary',
            'adr_mobile_primary' => 'Adr Mobile Primary',
            'adr_skype_id' => 'Adr Skype ID',
            'adr_linkedin_id' => 'Adr Linkedin ID',
            'adr_building_name' => 'Adr Building Name',
            'adr_block_no' => 'Adr Block No',
            'adr_street' => 'Adr Street',
            'adr_city' => 'Adr City',
            'adr_country' => 'Adr Country',
            'adr_created_at' => 'Adr Created At',
            'adr_updated_at' => 'Adr Updated At',
            'adr_created_by' => 'Adr Created By',
            'adr_updated_by' => 'Adr Updated By',
        ];
    }
}
