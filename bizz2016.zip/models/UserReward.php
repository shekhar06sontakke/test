<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user_reward".
 *
 * @property integer $urwd_id
 * @property integer $id
 * @property integer $rwt_id
 * @property integer $urwd_value
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class UserReward extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_reward';
    }
    
    /**
     * @behaviors
     */
    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'rwt_id', 'urwd_value'], 'required'],
            [['id'], 'integer'],
            [['rwt_id', 'urwd_value'], 'string']
        ];
    }
    
    

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'urwd_id' => 'Urwd ID',
            'id' => 'ID',
            'rwt_id' => 'Rwt ID',
            'urwd_value' => 'Urwd Value',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
