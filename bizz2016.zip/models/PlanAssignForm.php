<?php

namespace app\models;

use app\models\User;
use yii\base\Model;
use Yii;
use DateTime;
use app\components\Helper;

/**
 * Signup form
 */
class PlanAssignForm extends Model {

    public $userid;
    public $plan;
    public $duration;
    public $method;

    public function init() {
        // trigger event on user logged in.
//        $this->on(User::EVENT_LOGGED_IN, [$this, 'storeIP']);
//        $this->on(User::EVENT_NEW_USER, [$this, 'sendEmail']);
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [ ['userid', 'plan', 'duration'], 'required'],
            [['userid', 'plan', 'duration'], 'integer'],
            [['method'], 'string']
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function assign() {
        if ($this->validate()) {

            $valid = TRUE;
            $plan = Plan::findOne($this->plan);
            $user = User::findOne($this->userid);
            $valid = $valid && $this->assignRewardsToUser($user, $plan);

            if ($valid) {
                $ugh = new UpgradeHistory();
                $ugh->id = $this->userid;
                $ugh->pln_id = $this->plan;
                $ugh->pld_duration = $this->duration;
                $pp = $plan->getPlanPricingByDuration($this->duration);
                $ugh->upgh_currency = $pp->pld_currency;
                $ugh->upgh_amount = $pp->pld_price;
                $ugh->upgh_pay_method = $this->method;
                $valid = $valid && $ugh->save();
            }
            if ($valid) {
                $user->plan_id = $plan->pln_id;
                $user->plan_start_datetime = time();
                $user->plan_duration = $this->duration;
                $valid = $valid && $user->save();
            }

            return $valid;
        }

        return null;
    }

    public function assignRewardsToUser($user, $plan) {
        $rewards = $plan->rewards;
//        $reward_cnt = count($rewards);
        $valid = TRUE;
        foreach ($rewards as $reward) {

            $ur = $this->getUserRewardModel($user->id, $reward->rwt_id);
            $ur->urwd_value = $reward->plr_value;

//            Helper::pp($ur);
//            die();
            if ($valid)
                $valid = $valid && $ur->save();
        }

        return $valid;
    }

    public function getUserRewardModel($userid, $reward_type) {
        $ur = UserReward::find()->where(['id' => $userid, 'rwt_id' => $reward_type])->one();
        if (!isset($ur->id)) {
            $ur = new UserReward();
            $ur->id = $userid;
            $ur->rwt_id = $reward_type;
        }
        return $ur;
    }

    public function attributeLabels() {
        return [
            'userid' => 'Userid',
            'plan' => 'Plan',
            'duration' => 'Duration',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function is10NumbersOnly($attribute) {
        if (!preg_match('/^[0-9]{10}$/', $this->$attribute)) {
            return $this->addError($attribute, 'must contain exactly 10 digits.');
        }
    }

    public function age_greater_than_14($attribute, $params) {
        $from = new DateTime($this->birthday);
        $now = new dateTime('today');
        $age = $from->diff($now)->y;
        if ($age < SignupForm::MIN_AGE_REQUIRED) {
            $message = strtr('You must be more than 14 years.', ['{attribute}' => $this->getAttributeLabel($attribute)]);
            $this->addError($attribute, $message);
        }
    }

}
