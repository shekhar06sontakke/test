<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $username
 * @property string $auth_key
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property integer $user_type
 * @property integer $account_type
 * @property integer $gender
 * @property string $name
 * @property string $father_name
 * @property string $surname
 * @property string $dob
 * @property integer $phone_code
 * @property string $phone
 * @property integer $mobile_code
 * @property string $mobile
 * @property string $fax_no
 * @property string $block_no
 * @property string $street_locality
 * @property integer $zip
 * @property integer $city_id
 * @property integer $country_id
 * @property string $ph_id
 * @property string $path
 * @property integer $status
 * @property integer $last_login
 * @property integer $last_activity
 * @property integer $created_at
 * @property integer $updated_at
 * @property integer $created_by
 * @property integer $updated_by
 */
class Profile extends \yii\db\ActiveRecord {

    const SCENARTIO_BASIC_PROFILE_UPDATE = 'SCENARTIO_BASIC_PROFILE_UPDATE';
    const SCENARTIO_CONTACT_UPDATE = 'SCENARTIO_CONTACT_UPDATE';
    const SCENARTIO_ADDRESS_UPDATE = 'SCENARTIO_ADDRESS_UPDATE';

    public $scenario;
    public $birthday;
    public $password;
    public $agreement;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['username', 'auth_key', 'password_hash', 'email', 'gender'], 'required'],
            [['name', 'surname', 'birthday'], 'required', 'on' => Profile::SCENARTIO_BASIC_PROFILE_UPDATE],
            [['mobile_code', 'mobile', 'email'], 'required', 'on' => Profile::SCENARTIO_CONTACT_UPDATE],
            [['city_id', 'country_id', 'zip'], 'required', 'on' => Profile::SCENARTIO_ADDRESS_UPDATE],
            [['user_type', 'account_type', 'gender', 'phone_code', 'phone', 'mobile_code', 'mobile', 'fax_no', 'zip', 'city_id', 'country_id', 'status', 'last_login', 'last_activity'], 'integer'],
            [['dob'], 'safe'],
            ['birthday', 'date', 'format' => 'dd/MM/yyyy'],
//            [['ph_id', 'path'], 'string'],
            [['username', 'password_hash', 'password_reset_token', 'email'], 'string', 'max' => 255],
            [['auth_key', 'name', 'father_name', 'scenario', 'surname', 'block_no', 'street_locality'], 'string', 'max' => 32],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['mobile'], 'unique'],
            [['password_reset_token'], 'unique']
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'auth_key' => 'Auth Key',
            'password_hash' => 'Password Hash',
            'password_reset_token' => 'Password Reset Token',
            'email' => 'Email',
            'user_type' => 'User Type',
            'account_type' => 'Account Type',
            'gender' => 'Gender',
            'name' => 'Name',
            'father_name' => 'Father Name',
            'surname' => 'Surname',
            'dob' => 'Birthday',
            'birthday' => 'Birthday',
            'phone_code' => 'STD Code',
            'phone' => 'Landline',
            'mobile_code' => 'Code',
            'mobile' => 'Mobile',
            'fax_no' => 'Fax No',
            'block_no' => 'Block No',
            'street_locality' => 'Street Locality',
            'zip' => 'Zip Code',
            'city_id' => 'City',
            'country_id' => 'Country',
            'ph_id' => 'Avatar',
            'path' => 'Path',
            'status' => 'Status',
            'last_login' => 'Last Login',
            'last_activity' => 'Last Activity',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
        ];
    }

    public function beforeValidate() {

        return parent::beforeValidate();
    }

    public function afterFind() {
        if ($str = strtotime($this->dob))
            $this->birthday = date('d/m/Y', $str);

        return parent::afterFind();
    }

    public function beforeSave($insert) {
        if ($str = $this->prepareTimestampFromDate($this->birthday))
            $this->dob = date('Y-m-d', $str);

        return parent::beforeSave($insert);
    }

    public function prepareTimestampFromDate($date) {
        $date = str_replace('/', '-', $date);
        if ($str = strtotime($date))
            return $str;

        return NULL;
    }

    public function getPhoto() {
        return $this->hasOne(Photo::className(), ['ph_id' => 'ph_id']);
    }

    public function setPhoto($id) {
        $this->ph_id = $id;
        return $this->save();
    }

    public function getSeller() {
        return $this->hasOne(Seller::className(), ['id' => 'id']);
    }
    public function getBuyer() {
        return $this->hasOne(Buyer::className(), ['id' => 'id']);
    }
    
}
