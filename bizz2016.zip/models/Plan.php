<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "plan".
 *
 * @property integer $pln_id
 * @property string $pln_name
 * @property string $pln_short_description
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Plan extends \yii\db\ActiveRecord {

    const PLAN_TYPE_SELLER = '48';
    const PLAN_TYPE_BUYER = '46';

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'plan';
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['pln_name', 'pln_short_description', 'pln_type'], 'required'],
            [['pln_short_description'], 'string'],
            [['pln_type'], 'integer'],
//            [['pln_price'], 'number'],
            [['pln_name'], 'string', 'max' => 128],
//            [['pln_currency'], 'string', 'max' => 3]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'pln_id' => 'ID',
            'pln_name' => 'Name',
            'pln_type' => 'Plan For',
            'pln_short_description' => 'Short Description',
            'pln_duration' => 'Duration (days)',
            'pln_currency' => 'Currency',
            'pln_price' => 'Price',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getRewards() {
        return $this->hasMany(PlanReward::className(), ['pln_id' => 'pln_id']);
    }

    public function getPlandurations() {
        return $this->hasMany(PlanDuration::className(), ['pln_id' => 'pln_id']);
    }

    public function getPlanPricingByDuration($duration) {
        return PlanDuration::find()->where(['pln_id' => $this->pln_id, 'pld_duration' => $duration])->one();
    }

}
