<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "reward_type".
 *
 * @property integer $rwt_id
 * @property string $rwt_name
 * @property string $rwt_description
 */
class RewardType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'reward_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['rwt_name', 'rwt_description'], 'required'],
            [['rwt_name'], 'string', 'max' => 64],
            [['rwt_description'], 'string', 'max' => 180]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'rwt_id' => 'Rwt ID',
            'rwt_name' => 'Rwt Name',
            'rwt_description' => 'Rwt Description',
        ];
    }
}
