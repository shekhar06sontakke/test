<?php

namespace app\models;

use Yii;



/**
 * This is the model class for table "upgrade_history".
 *
 * @property integer $upgh_id
 * @property integer $id
 * @property integer $pln_id
 * @property integer $pld_duration
 * @property string $upgh_currency
 * @property double $upgh_amount
 * @property string $upgh_pay_method
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class UpgradeHistory extends \yii\db\ActiveRecord
{
    const PAYMENT_METHOD_BY_ADMIN = 'BYADMIN';
    const PAYMENT_METHOD_CCAVENUE = 'CCAVENUE';


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'upgrade_history';
    }
    
    /**
     * @behaviors
     */
    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'pln_id', 'pld_duration', 'upgh_currency', 'upgh_amount', 'upgh_pay_method'], 'required'],
            [['id', 'pln_id', 'pld_duration'], 'integer'],
            [['upgh_amount'], 'number'],
            [['upgh_currency'], 'string', 'max' => 3],
            [['upgh_pay_method'], 'string', 'max' => 20]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'upgh_id' => 'ID',
            'id' => 'User ID',
            'pln_id' => 'Plan ID',
            'pld_duration' => 'Duration',
            'upgh_currency' => 'Currency',
            'upgh_amount' => 'Amount',
            'upgh_pay_method' => 'Pay Method',
            'upgh_txnid' => 'Transaction Id',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created at',
            'updated_at' => 'Updated at',
        ];
    }
    
    public function getUser() {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }
    public function getPlan() {
        return $this->hasOne(Plan::className(), ['pln_id' => 'pln_id']);
    }
}
