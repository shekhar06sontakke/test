<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "seller".
 *
 * @property integer $sl_id
 * @property integer $sl_userid
 * @property integer $sl_company_start_year
 * @property string $sl_company_nature
 * @property string $sl_industry_category
 * @property string $sl_business_nature
 * @property string $sl_current_product_service_details
 * @property string $sl_banker_name
 * @property string $sl_ifsc_code
 * @property string $sl_micr_code
 * @property string $sl_banker_city
 * @property string $sl_account_no
 * @property string $sl_tan_no
 * @property string $sl_vern
 * @property string $sl_vtrn
 * @property integer $sl_atly
 * @property string $sl_sister_concern_subsidiary
 * @property string $sl_change_in_firm_name
 * @property string $sl_company_description
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Seller extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'seller';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id'], 'required'],
            [['sl_id', 'id', 'sl_company_start_year', 'sl_atly'], 'integer'],
            [['sl_current_product_service_details', 'sl_business_nature_text', 'sl_banker_name', 'sl_banker_account_type', 'sl_company_description'], 'string'],
            [['sl_company_nature', 'sl_company_name','sl_industry_category', 'sl_business_nature', 'sl_change_in_firm_name'], 'string'],
//            [['sl_company_start_year'], 'string', 'max' => 4],
            ['sl_company_start_year', 'match', 'pattern' => '/\b\d{4}\b/', 'message' => 'Year must be 4 digit'],
            [['sl_ifsc_code'], 'string', 'max' => 15],
            [['sl_micr_code', 'sl_banker_account_type'], 'string', 'max' => 12],
            [['sl_banker_city', 'sl_account_no', 'sl_tan_no', 'sl_vern', 'sl_vtrn'], 'string', 'max' => 32],
            [['sl_sister_concern_subsidiary'], 'string']
        ];
    }

    /**
     * @behaviors
     */
    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'sl_id' => 'ID',
            'id' => 'id',
            'sl_company_name' => 'Company name',
            'sl_company_start_year' => 'Year of Incorporation of the Company / Commencement',
            'sl_company_nature' => 'Company Nature',
            'sl_industry_category' => 'Category of Industry',
            'sl_industry_category_text' => 'Industry Category (Specify here)',
            'sl_business_nature' => 'Business Nature',
            'sl_business_nature_text' => 'Business Nature (Specify here)',
            'sl_current_product_service_details' => 'Current Product Service Details',
            'sl_banker_name' => 'Bank Name',
            'sl_banker_account_type' => 'Bank Account Type',
            'sl_ifsc_code' => 'IFSC Code',
            'sl_micr_code' => 'MICR Code',
            'sl_banker_city' => 'Bank City',
            'sl_account_no' => 'Account No',
            'sl_tan_no' => 'Tan No',
            'sl_vern' => 'Valid Excise Reg No.',
            'sl_vtrn' => 'Valid State/Vat/ Central Sales Tax Reg. No',
            'sl_atly' => 'Annual Turnover last year',
            'sl_sister_concern_subsidiary' => 'Complete Details About Sister Concerns & Subsidiaries, If any',
            'sl_change_in_firm_name' => 'Whether Changed Firm’s Name in Last 5 Years (If yes Details of previous names), if Any',
            'sl_atly' => 'Annual Turnover last year',
            'sl_sister_concern_subsidiary' => 'Complete Details About Sister Concerns & Subsidiaries, If any',
            'sl_change_in_firm_name' => 'Whether Changed Firm’s Name in Last 5 Years(if yes) give Details',
            'sl_company_description' => 'Company Description',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getLogo() {
        return $this->hasOne(Photo::className(), ['ph_id' => 'ph_id']);
    }

    public function getProfile() {
        return $this->hasOne(Profile::className(), ['id' => 'id']);
    }
    public function getCategories() {
        return $this->hasMany(SellerCategoryAssignment::className(), ['sl_id' => 'sl_id']);
    }

    public function getRating() {
        $rate = 0;
        $count = 0;
        if ($this->id) {
            $rating = Rating::find()->where(['sl_id' => $this->sl_id])->all();
            foreach ($rating as $r) {
                $rate +=$r->rat_value;
                ++$count;
            }
            return ($rate / $count);
//            \app\components\Helper::pp($rating);
        }
    }

    public function getBuyerOldRating() {
        $buyer = Yii::$app->params['me']->buyer;

//        \app\components\Helper::pp($buyer);

        if ($this->id && isset($buyer->by_id)) {
            $rating = Rating::find()->where(['sl_id' => $this->sl_id, 'by_id' => $buyer->by_id])->one();

            return isset($rating->rat_value) ? $rating->rat_value : NULL;
//            \app\components\Helper::pp($rating);
        }
    }

}
