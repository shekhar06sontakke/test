<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "invitation_email".
 *
 * @property integer $invte_id
 * @property integer $auc_id
 * @property integer $invte_email_list
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class InvitationEmail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'invitation_email';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['auc_id'], 'required'],
            [['auc_id'], 'integer'],
            [['invte_email_list'], 'string']
        ];
    }
      public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'invte_id' => 'Invte ID',
            'auc_id' => 'Auc ID',
            'invte_email_list' => 'Invte Email List',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
