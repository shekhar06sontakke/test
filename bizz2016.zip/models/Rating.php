<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rating".
 *
 * @property integer $rat_id
 * @property integer $by_id
 * @property integer $rat_value
 * @property integer $created_at
 * @property integer $updated_at
 */
class Rating extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'rating';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['by_id', 'rat_value','sl_id'], 'required'],
            [['by_id','sl_id'], 'integer'],
            [['rat_value'], 'number']
        ];
    }
    
    /**
     * @behaviors
     */
    public function behaviors() {
        return [
//            [
//                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
//            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'rat_id' => 'Rat ID',
            'by_id' => 'By ID',
            'rat_value' => 'Rat Value',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getBuyer() {
        return $this->hasOne(Buyer::className(), ['by_id' => 'by_id']);
    }
    public function getSeller() {
        return $this->hasOne(Seller::className(), ['sl_id' => 'sl_id']);
    }

}
