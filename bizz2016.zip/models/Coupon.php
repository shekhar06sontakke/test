<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "coupon".
 *
 * @property integer $cpn_id
 * @property string $cpn_code
 * @property double $cpn_discount
 * @property integer $cpn_start_date
 * @property integer $cpn_end_date
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Coupon extends \yii\db\ActiveRecord {

    public $t_cpn_start_date;
    public $t_cpn_end_date;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'coupon';
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['cpn_code', 'cpn_discount', 't_cpn_start_date', 't_cpn_end_date'], 'required'],
            [['cpn_discount'], 'number'],
            ['t_cpn_start_date', 'date', 'format' => 'dd-MM-yyyy'],
            ['t_cpn_end_date', 'date', 'format' => 'dd-MM-yyyy'],
            [['cpn_start_date', 'cpn_end_date'], 'integer'],
            [['cpn_code'], 'string', 'max' => 10],
            [['cpn_desc'], 'string', 'max' => 120]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'cpn_id' => 'ID',
            'cpn_code' => 'Code',
            'cpn_discount' => 'Discount (%)',
            't_cpn_start_date' => 'Start Date',
            't_cpn_end_date' => 'End Date',
            'cpn_start_date' => 'Start Date',
            'cpn_end_date' => 'End Date',
            'cpn_desc' => 'Description',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function afterFind() {
        if ($this->cpn_start_date && $this->cpn_end_date) {
            $this->t_cpn_start_date = \app\components\Helper::_date($this->cpn_start_date, 'd-m-Y');
            $this->t_cpn_end_date = \app\components\Helper::_date($this->cpn_end_date, 'd-m-Y');            
        }
        return parent::afterFind();
    }

    public function beforeSave($insert) {
        if ($insert) {
            if (strtotime($this->t_cpn_start_date)) {
                $this->cpn_start_date = $t;
            }
            if ($t = strtotime($this->t_cpn_end_date)) {
                $this->cpn_end_date = $t;
            }
        }

        return parent::beforeSave($insert);
    }

}
