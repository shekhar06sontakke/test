<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "term".
 *
 * @property integer $term_id
 * @property integer $auc_id
 * @property string $term_value
 * @property integer $created_at
 * @property integer $updated_at
 */
class Term extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'term';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['auc_id'], 'required'],
            [['auc_id'], 'integer'],
            [['term_value'], 'string']
        ];
    }
    
    public function behaviors() {
        return [            
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'term_id' => 'Term ID',
            'auc_id' => 'Auction ID',
            'term_value' => 'Point',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
