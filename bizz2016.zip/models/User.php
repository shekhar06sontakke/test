<?php

namespace app\models;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;

class User extends ActiveRecord implements IdentityInterface {

    const STATUS_DELETED = 0;
    const STATUS_DISABLE = 5;
    const STATUS_ACTIVE = 10;
    const USER_TYPE_BUYER = 20;
    const USER_TYPE_SELLER = 30;
    const USER_TYPE_ADMIN = 40;
    const MOBILE_VERIFICATION_PENDING = 5;  
    const MOBILE_VERIFICATION_SUCCESS = 10;
    const EMAIL_VERIFICATION_PENDING = 5;
    const EMAIL_VERIFICATION_SUCCESS = 10;
    const GENDER_MALE = 10;
    const GENDER_FEMALE = 20;
    const AVATAR_DEFAULT = 1;
    const EVENT_USER_LOGGED_IN = 'EVENT_USER_LOGGED_IN';
    const EVENT_NEW_USER = 'EVENT_NEW_USER';

    public static function tableName() {
        return '{{%user}}';
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
//                'createdByAttribute' => 'created_by',
//                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id) {
        return static::findOne(['id' => $id, 'status' => self::STATUS_ACTIVE]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null) {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }

    /**
     * Finds user by username
     *
     * @param  string      $username
     * @return static|null
     */
    public static function findByUsername($username) {
        return static::findOne(['username' => $username, 'status' => self::STATUS_ACTIVE]);
    }

    /**
     * Finds user by keyword
     *
     * @param  string      $keyword
     * @return static|null
     */
    public static function findByKeyword($keyword) {
        $status = self::STATUS_ACTIVE;
        return static::find()->where("status='{$status}' AND (email= '{$keyword}' OR mobile= '{$keyword}' )")
                        ->one();
    }

    /**
     * @inheritdoc
     */
    public function getId() {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey() {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey) {
        return $this->getAuthKey() === $authKey;
    }

    /**
     * Validates password
     *
     * @param  string  $password password to validate
     * @return boolean if password provided is valid for current user
     */
    public function validatePassword($password) {
        return Yii::$app->security->validatePassword($password, $this->password_hash);
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password) {
        $this->password_hash = Yii::$app->security->generatePasswordHash($password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey() {
        $this->auth_key = Yii::$app->security->generateRandomString();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken() {
        $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken() {
        $this->password_reset_token = null;
    }

    public function getActivationKey(){
        $this->email_token =  Yii::$app->security->generateRandomKey();
    }
    
    public function sendEmail($id, $email) {
        $token =  Yii::$app->security->generateRandomString(32);
        
        $this->email_token = $token;
        $this->save();
        
        $url = \yii\helpers\Url::toRoute(['/'], true);
        $url .= 'site/verifyemail?email=' . $email . "&token=" . $token;
               
        //Sending email for signup confirmation
        \Yii::$app->mailer->compose('contact/verifyemail',['params' => ['name' => 'shekhar','url'=>$url], ])                
        ->setFrom(['admin@bizjunction.com' => 'Signup Confirmation'])
        ->setTo($email)
        ->setSubject('Please verifiy your email.')
        ->send();
        
        
    }
    
}
