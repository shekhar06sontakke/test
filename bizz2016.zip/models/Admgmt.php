<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "admgmt".
 *
 * @property integer $admg_id
 * @property string $admg_title
 * @property integer $admg_start_datetime
 * @property integer $admg_end_datetime
 * @property integer $admg_image
 * @property string $admg_path
 * @property string $admg_link
 * @property integer $admg_priority
 * @property integer $admg_position
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Admgmt extends \yii\db\ActiveRecord {
    
    const STATUS_ON = "20";
    const STATUS_OFF = "0";

    public $imageFile;
    public $t_admg_start_datetime;
    public $t_admg_end_datetime;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'admgmt';
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['admg_title', 'admg_link'], 'required'],
            [['admg_priority','admg_status'], 'integer'],
//            [['t_admg_start_datetime', 't_admg_end_datetime'], 'date', 'format' => 'dd/MM/yyyy HH:mm'],
            [['admg_link'], 'string'],
            [['admg_title','admg_position'], 'string', 'max' => 32],
            [['admg_path', 'admg_image'], 'string', 'max' => 100],
            [['imageFile'], 'safe'],
            ['admg_status','default','value'=> 0],
            [['imageFile'], 'file', 'extensions' => 'png, jpg'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'admg_id' => 'ID',
            'admg_title' => 'Title',
            'admg_start_datetime' => 'Start Datetime',
            'admg_end_datetime' => 'End Datetime',
            't_admg_start_datetime' => 'Start Datetime',
            't_admg_end_datetime' => 'End Datetime',
            'admg_image' => 'Image',
            'admg_file' => 'Image',
            'admg_path' => 'Path',
            'admg_link' => 'Link',
            'admg_status' => 'Status',
            'admg_priority' => 'Priority',
            'admg_position' => 'Position',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

//    public function upload() {
//        if ($this->validate()) {
//            $this->imageFile->saveAs('uploads/' . $this->imageFile->baseName . '.' . $this->imageFile->extension);            
//            return true;
//        } else {
//            return false;
//        }
//    }

//    public function beforeSave($insert) {
//        if ($str = \app\components\Helper::prepare_timestamp_from_date($this->t_admg_start_datetime)) {
//            $this->admg_start_datetime = $str;
//        }
//        if ($str = \app\components\Helper::prepare_timestamp_from_date($this->t_admg_end_datetime)) {
//            $this->admg_end_datetime = $str;
//        }
//
//        return parent::beforeSave($insert);
//    }

//    public function afterFind() {
//        if ($this->admg_start_datetime)
//            $this->t_admg_start_datetime = \app\components\Helper::_date($this->admg_start_datetime, 'd/m/Y H:i');
//
//        if ($this->admg_end_datetime)
//            $this->t_admg_end_datetime = \app\components\Helper::_date($this->admg_end_datetime, 'd/m/Y H:i');
//
//        return parent::afterFind();
//    }

}
