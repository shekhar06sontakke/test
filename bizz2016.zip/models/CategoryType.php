<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "category_type".
 *
 * @property integer $caty_id
 * @property string $caty_name
 *
 * @property Category[] $categories
 */
class CategoryType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'category_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['caty_name'], 'required'],
            ['caty_name', 'unique', 'targetClass' => '\app\models\CategoryType', 'message' => 'This slug has already been taken.'],
            [['caty_name'], 'string', 'max' => 32]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'caty_id' => 'Caty ID',
            'caty_name' => 'Category type :',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategories()
    {
        return $this->hasMany(Category::className(), ['caty_id' => 'caty_id']);
    }
}
