<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Plan;

/**
 * PlanSearch represents the model behind the search form about `app\models\Plan`.
 */
class PlanSearch extends Plan {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['pln_id', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['pln_name', 'pln_short_description'], 'safe'],
//            [['pln_price'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Plan::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'pln_id' => $this->pln_id,
//            'pln_duration' => $this->pln_duration,
//            'pln_price' => $this->pln_price,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'pln_name', $this->pln_name])
                ->andFilterWhere(['like', 'pln_short_description', $this->pln_short_description]);
//                ->andFilterWhere(['like', 'pln_currency', $this->pln_currency]);

        return $dataProvider;
    }

}
