<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Seller;

/**
 * SellerSearch represents the model behind the search form about `app\models\Seller`.
 */
class SellerSearch extends Seller {

    public $username = '';
    public $fullname = '';
    public $mobile = '';
    public $email = '';

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['sl_id', 'mobile', 'id', 'ph_id', 'sl_company_start_year', 'sl_atly', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['fullname', 'email','username'], 'string'],
            [['fullname', 'email','username'], 'filter', 'filter' => 'trim'],
            [['sl_company_name', 'sl_company_nature', 'sl_industry_category', 'sl_industry_category_text', 'sl_business_nature', 'sl_business_nature_text', 'sl_current_product_service_details', 'sl_banker_name', 'sl_banker_account_type', 'sl_ifsc_code', 'sl_micr_code', 'sl_banker_city', 'sl_account_no', 'sl_tan_no', 'sl_vern', 'sl_vtrn', 'sl_sister_concern_subsidiary', 'sl_change_in_firm_name', 'sl_company_description'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Seller::find();
        $query->joinWith('profile');
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'sl_id' => $this->sl_id,
            'id' => $this->id,
            'ph_id' => $this->ph_id,
            'user.username' => $this->username,
            'user.mobile' => $this->mobile,
            'user.email' => $this->email,
            'sl_company_start_year' => $this->sl_company_start_year,
            'sl_atly' => $this->sl_atly,
//            'created_by' => $this->created_by,
//            'updated_by' => $this->updated_by,
//            'created_at' => $this->created_at,
//            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'sl_company_name', $this->sl_company_name])
                ->andFilterWhere(['like', 'user.name', $this->fullname]);
//                ->andFilterWhere(['like', 'sl_company_nature', $this->sl_company_nature])
//                ->andFilterWhere(['like', 'sl_industry_category', $this->sl_industry_category])
//                ->andFilterWhere(['like', 'sl_industry_category_text', $this->sl_industry_category_text])
//                ->andFilterWhere(['like', 'sl_business_nature', $this->sl_business_nature])
//                ->andFilterWhere(['like', 'sl_business_nature_text', $this->sl_business_nature_text])
//                ->andFilterWhere(['like', 'sl_current_product_service_details', $this->sl_current_product_service_details])
//                ->andFilterWhere(['like', 'sl_banker_name', $this->sl_banker_name])
//                ->andFilterWhere(['like', 'sl_banker_account_type', $this->sl_banker_account_type])
//                ->andFilterWhere(['like', 'sl_ifsc_code', $this->sl_ifsc_code])
//                ->andFilterWhere(['like', 'sl_micr_code', $this->sl_micr_code])
//                ->andFilterWhere(['like', 'sl_banker_city', $this->sl_banker_city])
//                ->andFilterWhere(['like', 'sl_account_no', $this->sl_account_no])
//                ->andFilterWhere(['like', 'sl_tan_no', $this->sl_tan_no])
//                ->andFilterWhere(['like', 'sl_vern', $this->sl_vern])
//                ->andFilterWhere(['like', 'sl_vtrn', $this->sl_vtrn])
//                ->andFilterWhere(['like', 'sl_sister_concern_subsidiary', $this->sl_sister_concern_subsidiary])
//                ->andFilterWhere(['like', 'sl_change_in_firm_name', $this->sl_change_in_firm_name])
//                ->andFilterWhere(['like', 'sl_company_description', $this->sl_company_description]);
        if ($this->fullname)
            $query->orWhere(['like', 'user.surname', $this->fullname]);
        return $dataProvider;
    }

}
