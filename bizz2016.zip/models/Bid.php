<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "bid".
 *
 * @property integer $bid_id
 * @property integer $sl_id
 * @property integer $auc_id
 * @property integer $auc_round
 * @property string $bid_data
 * @property string $bid_comment
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class Bid extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'bid';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['sl_id', 'auc_id', 'auc_round', 'bid_data'], 'required'],
            [['sl_id', 'auc_id', 'auc_round'], 'integer'],
            [['bid_data'], 'string'],
            [['bid_comment'], 'string', 'max' => 180]
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'bid_id' => 'Bid ID',
            'sl_id' => 'Sl ID',
            'auc_id' => 'Auc ID',
            'auc_round' => 'Auc Round',
            'bid_data' => 'Bid Data',
            'bid_comment' => 'Bid Comment',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function getSeller() {
        return $this->hasOne(Seller::className(), ['sl_id' => 'sl_id']);
    }

}
