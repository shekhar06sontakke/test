<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auction".
 *
 * @property integer $auc_id
 * @property integer $auc_uniqueid
 * @property integer $by_id
 * @property string $auc_title
 * @property string $auc_short_description
 * @property string $auc_long_description
 * @property string $auc_start_date
 * @property string $auc_end_date
 * @property integer $auc_rounds
 * @property integer $auc_type
 * @property integer $auc_edit_attempt
 * @property integer $auc_status
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property Buyer $by
 * @property AuctionCategoryAssociation[] $auctionCategoryAssociations
 */
class Auction extends \yii\db\ActiveRecord {

    const STATUS_ACTIVE = '10';
    const STATUS_CLOSE = '20';
    const STATUS_DRAFT = '5';
    const UNIQUE_ID_START = 325;
    const SCENARIO_UPDATE_TERMS = 'auctionTermsUpdation';
    const AUCTION_TYPE_OPEN = 'OPEN';
    const AUCTION_TYPE_PRIVATE = 'PRIV';
    const SCENARIO_BASIC_INFO = 'auc_bi';

    public $t_auc_start_date;
    public $t_auc_end_date;
    public $scenario;

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'auction';
    }

    public function init() {
        if ($this->scenario)
            $this->setScenario($this->scenario);

        return parent::init();
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['by_id', 'auc_title', 'auc_slug', 'auc_short_description', 'cat_id', 'auc_currency', 'auc_rounds', 'auc_type'], 'required'],
//            [[ 't_auc_end_date'], 'required', 'on' => Auction::SCENARIO_BASIC_INFO],
            [['auc_uniqueid', 'by_id', 'auc_rounds', 'auc_round', 'cat_id', 'auc_edit_attempt', 'auc_status'], 'integer'],
            [['auc_long_description'], 'string'],
//            [[ 't_auc_end_date'], 'date', 'format' => 'dd/MM/yyyy'],
//            [[ 't_auc_end_date'], 'safe'],
            [['auc_title', 'scenario'], 'string', 'max' => 100],
            [['auc_currency', 'auc_type'], 'string', 'max' => 4],
            [['auc_short_description'], 'string', 'max' => 520],
            [['auc_terms'], 'string'],
            [['auc_terms'], 'required', 'on' => Auction::SCENARIO_UPDATE_TERMS],
            ['auc_edit_attempt', 'default', 'value' => '0'],
            [['auc_uniqueid', 'auc_slug'], 'unique']
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'auc_id' => 'ID',
            'auc_uniqueid' => 'Ref.Id',
            'by_id' => 'Buyer',
            'auc_title' => 'Title',
            'auc_slug' => 'Slug (URL)',
            'auc_short_description' => 'Short Description',
            'auc_long_description' => 'Long Description',
            'auc_terms' => 'Terms & conditions',
            't_auc_start_date' => 'Start Date',
            't_auc_end_date' => 'End Date',
            'auc_rounds' => 'Round',
            'auc_round' => 'Round (Current)',
            'auc_type' => 'Type',
            'cat_id' => 'Category',
            'auc_currency' => 'Currency',
            'auc_edit_attempt' => 'Edit Attempt',
            'auc_status' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function beforeSave($insert) {
        if ($insert) {
            $this->auc_status = Auction::STATUS_DRAFT;

            if ($this->auc_type == Auction::AUCTION_TYPE_OPEN)
                $this->auc_rounds = 1;

            $this->auc_round = 1;
        }


        return parent::beforeSave($insert);
    }

    public function afterFind() {
//        if ($this->auc_start_date)
//            $this->t_auc_start_date = date('d/m/Y', $this->auc_start_date);
//
//        if ($this->auc_end_date)
//            $this->t_auc_end_date = date('d/m/Y', $this->auc_end_date);
//            
        $this->updateStatus();

        return parent::afterFind();
    }

    public function prepare_timestamp_from_date($date) {
        $date = str_replace('/', '-', $date);
        if ($str = strtotime($date))
            return $str;

        return NULL;
    }

    public function setUniqueID() {
        if ($this->auc_id) {
            $this->auc_uniqueid = Auction::UNIQUE_ID_START + $this->auc_id;
        }
        return NULL;
    }

    public function afterSave($insert, $changedAttributes) {
        if ($insert) {
            $this->setUniqueID();
            $this->save();
        }

        return parent::afterSave($insert, $changedAttributes);
    }

//    public function attributeHints() {
//        return [
//            'auc_title' => 'my custom title hint',
//        ];
//
//        return parent::attributeHints();
//    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBuyer() {
        return $this->hasOne(Buyer::className(), ['by_id' => 'by_id']);
    }

    public function getCategory() {
        return $this->hasOne(Category::className(), ['cat_id' => 'cat_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAuctionCategoryAssociations() {
        return $this->hasMany(AuctionCategoryAssociation::className(), ['auc_id' => 'auc_id']);
    }

    public function getFiles($round = NULL) {

        if (!$round)
            $round = $this->auc_round;

        $files = AuctionFile::find()->where(['auc_id' => $this->auc_id, 'auc_round' => $round])->all();
        return $files;
    }

    public function getTerms() {
        return $this->hasMany(Term::className(), ['auc_id' => 'auc_id']);
    }

//    public function getInvitationEmail() {
//        return $this->hasOne(InvitationEmail::className(), ['auc_id' => 'auc_id']);
//    }

    public function getInvitationEmail($round = NULL) {
        if (!$round)
            $round = $this->auc_round;

        $invte = InvitationEmail::find()->where(['auc_id' => $this->auc_id, 'invte_round' => $round])->one();

        return $invte;
    }

//    public function getInvitations() {
//        return $this->hasMany(Invitation::className(), ['auc_id' => 'auc_id']);
//    }

    public function getInvitations($round = NULL) {
        if (!$round)
            $round = $this->auc_round;
        $invt = Invitation::find()->where(['auc_id' => $this->auc_id, 'invt_round' => $round])->all();

        return $invt;
    }

    public function getAuctiondata($round = NULL) {
        if (!$round)
            $round = $this->auc_round;

        return AuctionData::find()->where(['auc_id' => $this->auc_id, 'auc_round' => $round])->one();
    }

    public function getGriddata($round = NULL) {
        if (!$round)
            $round = $this->auc_round;

        return GridData::find()->where(['auc_id' => $this->auc_id, 'auc_round' => $round])->one();
    }

    function getBidbyuser() {
        $seller = Yii::$app->params['me']->seller;

        if (isset($seller->sl_id)) {
            return Bid::find()->where(['sl_id' => $seller->sl_id, 'auc_id' => $this->auc_id, 'auc_round' => $this->auc_round])->one();
        }
    }

    function isSellerInvitationExist($sl_id) {
        return Invitation::find()->where(['auc_id' => $this->auc_id, 'invt_round' => $this->auc_round, 'sl_id' => $sl_id])->one();
    }

    function updateStatus() {
        $auctiondata = $this->getAuctiondata();

        if (isset($auctiondata->aucd_end_date) && (time() > $auctiondata->aucd_end_date)){
            $this->auc_status = Auction::STATUS_CLOSE;
//            \app\components\Helper::pp('$param');
        }
//            \app\components\Helper::pp('$param');

    }

}
