<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Admgmt;

/**
 * AdmgmtSearch represents the model behind the search form about `app\models\Admgmt`.
 */
class AdmgmtSearch extends Admgmt
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['admg_id', 'admg_start_datetime', 'admg_end_datetime', 'admg_image', 'admg_priority', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['admg_title', 'admg_path', 'admg_link'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Admgmt::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'admg_id' => $this->admg_id,
            'admg_start_datetime' => $this->admg_start_datetime,
            'admg_end_datetime' => $this->admg_end_datetime,
            'admg_image' => $this->admg_image,
            'admg_priority' => $this->admg_priority,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'admg_title', $this->admg_title])
            ->andFilterWhere(['like', 'admg_path', $this->admg_path])
            ->andFilterWhere(['like', 'admg_link', $this->admg_link]);

        return $dataProvider;
    }
}
