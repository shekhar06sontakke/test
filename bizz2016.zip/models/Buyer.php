<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "buyer".
 *
 * @property integer $by_id
 * @property integer $id
 * @property string $by_industry_type
 * @property string $by_concerned_person_name
 * @property string $by_designation
 * @property integer $by_vendor_approved_by
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $by_account_type
 * @property string $by_company_description
 * @property integer $created_at
 * @property integer $updated_at
 */
class Buyer extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'buyer';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id'], 'required'],
            [['by_company_description'], 'string'],
            [['by_company_name'], 'string','max'=>32],
            [['id'], 'integer'],
            [['by_industry_type'], 'string', 'max' => 100],
            [['by_concerned_person_name'], 'string', 'max' => 40],
            [['by_designation'], 'string', 'max' => 50],
            [['by_company_description'], 'string'],
        ];
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'by_id' => 'By ID',
            'id' => 'Userid',
            'by_industry_type' => 'Industry Type',
            'by_company_name' => 'Company Name',
            'by_concerned_person_name' => 'Concerned Person Name',
            'by_designation' => 'Designation',
            'by_vendor_approved_by' => 'Vendor Approved By',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'by_bank_account_type' => 'Bank Account Type',
            'by_company_description' => 'Company Description',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
    
    public function getProfile() {
        return $this->hasOne(Profile::className(), ['id' => 'id']);
    }
   

}
