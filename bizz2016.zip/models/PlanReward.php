<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "plan_reward".
 *
 * @property integer $plr_id
 * @property integer $pln_id
 * @property string $rwt_id
 * @property string $plr_name
 * @property string $plr_value
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $created_at
 * @property integer $updated_at
 */
class PlanReward extends \yii\db\ActiveRecord {

    const STATUS_ON = '10';
    const STATUS_OFF = '0';

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'plan_reward';
    }

    public function behaviors() {
        return [
            [
                'class' => \yii\behaviors\BlameableBehavior::className(),
                'createdByAttribute' => 'created_by',
                'updatedByAttribute' => 'updated_by',
            ],
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    \yii\db\ActiveRecord::EVENT_BEFORE_INSERT => ['created_at', 'updated_at'],
                    \yii\db\ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['pln_id', 'rwt_id'], 'required'],
            [['pln_id'], 'integer'],
            [['rwt_id'], 'string', 'max' => 6],
            ['rwt_id', 'unique_reward'],
            ['plr_value', 'match', 'pattern' => '/^[a-zA-Z0-9_]*$/'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'plr_id' => 'Plr ID',
            'pln_id' => 'Pln ID',
            'plr_type' => 'Plr Type',
            'plr_name' => 'Plr Name',
            'plr_value' => 'Value',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    function unique_reward($attribute, $params) {
        if (!$this->plr_id) {
            $find = self::find()->where(['pln_id' => $this->pln_id, 'rwt_id' => $this->rwt_id])->count();
            if ($find > 0)
                $this->addError($attribute, 'Sorry reward already created.');
        }

        return TRUE;
    }

    public function getType() {
        return $this->hasOne(RewardType::className(), ['rwt_id' => 'rwt_id']);
    }

}
