<?php

namespace app\models;

use app\models\User;
use yii\base\Model;
use Yii;
use DateTime;
use app\components\Helper;

/**
 * Signup form
 */
class PlanRewardForm extends Model {

    public $pln_id;
    public $CINFWT;
    public $CINFCL;
    public $CICPER;
    public $CIEMIL;
    public $CIPHNE;
    public $CILOGO;
    public $CISDCL;
    public $CADSZE;
    public $CADSCP;
    public $BCKLNK;
    public $CATLIM;
    public $BIDLIM;

//    public $birthday;
//    const MIN_AGE_REQUIRED = 18;

    public function init() {
        // trigger event on user logged in.
//        $this->on(User::EVENT_LOGGED_IN, [$this, 'storeIP']);
//        $this->on(User::EVENT_NEW_USER, [$this, 'sendEmail']);
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['CINFWT', 'pln_id', 'CINFCL', 'CICPER', 'CIEMIL', 'CIPHNE', 'CILOGO', 'CISDCL', 'CADSZE', 'CADSCP', 'BCKLNK', 'CATLIM', 'BIDLIM'], 'required'],
//            [['comp_info_contact_person', 'comp_info_email', 'comp_info_phone', 'comp_info_logo', 'custom_advt_size', 'custom_advt_scope', 'backlink'], 'boolean'],
//            ['username', 'filter', 'filter' => 'trim'],
//            ['username', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This username has already been taken.'],
//            ['email', 'filter', 'filter' => 'trim'],
            [['pln_id', 'CISDCL', 'CATLIM', 'BIDLIM'], 'integer'],
            ['CADSZE', 'string', 'max' => 12],
////            [['fname', 'last_name'], 'match', 'pattern' => '/^[a-zA-Z]+$/', 'message' => 'only alphabetic characters allowed'],
////            ['username', 'match', 'pattern' => '/^[a-z0-9_.-]{3,15}$/'],
//            ['username', 'match', 'pattern' => '/^[a-zA-Z0-9]+([_.-]?[a-zA-Z0-9]){3,25}$/'],
////            ['username', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This username has already been taken.'],
////            ['email', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This email address has already been taken.'],
////            ['mobile', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This mobile already registered with us.'],
////            ['mobile', 'is10NumbersOnly'],
//            ['mobile', 'number'],
//            ['mobile', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This mobile is already registered with us.'],
//            ['password', 'string', 'min' => 6],
//            ['agreement', 'required', 'requiredValue' => 1, 'message' => 'Please accept terms and conditions.']
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function save() {
        if ($this->validate()) {
            $model = Plan::findOne($this->pln_id);
            $valid = TRUE;

            foreach ($this->getAttr() as $attribute => $val) {
                $plan_reward = PlanReward::find()->where(['pln_id' => $this->pln_id, 'rwt_id' => $attribute])->one();

                if (isset($plan_reward->plr_id)) {
                    $plan_reward->plr_value = $this->{$attribute};
                } else {
                    $plan_reward = new PlanReward();
                    $plan_reward->pln_id = $this->pln_id;
                    $plan_reward->rwt_id = $attribute;
                    $plan_reward->plr_value = $this->{$attribute};
                }

                if ($valid)
                    $valid = $valid && $plan_reward->save();
            }


            return $valid;
        }

        return null;
    }

    public function attributeLabels() {
        return [
            'CINFWT' => 'Company Font-weight',
            'CINFCL' => 'Company Color',
            'CICPER' => 'Contact person',
            'CIEMIL' => 'Email',
            'CIPHNE' => 'Phone',
            'CILOGO' => 'Logo',
            'CISDCL' => 'Char Limit',
            'CADSZE' => 'Advt. Size',
            'CADSCP' => 'Advt. Scope',
            'BCKLNK' => 'Backlink',
            'CATLIM' => 'Category Limit',
            'BIDLIM' => 'Bid Limit',
        ];
    }

    public function loadOldData($models) {
        foreach ($models as $model) {
            $this->{$model->rwt_id} = $model->plr_value;
        }
    }

    public function getAttr() {
        return [
            'CINFWT' => 'Company Font-weight',
            'CINFCL' => 'Company Color',
            'CICPER' => 'Contact person',
            'CIEMIL' => 'Email',
            'CIPHNE' => 'Phone',
            'CILOGO' => 'Logo',
            'CISDCL' => 'Char Limit',
            'CADSZE' => 'Advt. Size',
            'CADSCP' => 'Advt. Scope',
            'BCKLNK' => 'Backlink',
            'CATLIM' => 'Category Limit',
            'BIDLIM' => 'Bid Limit',
        ];
    }

    public function is10NumbersOnly($attribute) {
        if (!preg_match('/^[0-9]{10}$/', $this->$attribute)) {
            return $this->addError($attribute, 'must contain exactly 10 digits.');
        }
    }

    public function age_greater_than_14($attribute, $params) {
        $from = new DateTime($this->birthday);
        $now = new dateTime('today');
        $age = $from->diff($now)->y;
        if ($age < SignupForm::MIN_AGE_REQUIRED) {
            $message = strtr('You must be more than 14 years.', ['{attribute}' => $this->getAttributeLabel($attribute)]);
            $this->addError($attribute, $message);
        }
    }

}
