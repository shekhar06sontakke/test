<?php

namespace app\models;

use app\models\User;
use yii\base\Model;
use Yii;
use DateTime;
use app\components\Helper;

/**
 * Signup form
 */
class SignupForm extends Model {

    public $username;
    public $email;
    public $password;
    public $mobile_code;
    public $mobile;
    public $agreement;
    public $account_type;
    public $_user;

//    public $birthday;
//    const MIN_AGE_REQUIRED = 18;

    public function init() {
        // trigger event on user logged in.
//        $this->on(User::EVENT_LOGGED_IN, [$this, 'storeIP']);
//        $this->on(User::EVENT_NEW_USER, [$this, 'sendEmail']);
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            ['username', 'filter', 'filter' => 'trim'],
            ['username', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This username has already been taken.'],
            [['email', 'username', 'password', 'mobile_code', 'mobile', 'account_type'], 'required'],
            ['email', 'filter', 'filter' => 'trim'],
            ['email', 'email'],
            ['email', 'string', 'max' => 64],
//            [['fname', 'last_name'], 'match', 'pattern' => '/^[a-zA-Z]+$/', 'message' => 'only alphabetic characters allowed'],
//            ['username', 'match', 'pattern' => '/^[a-z0-9_.-]{3,15}$/'],
            ['username', 'match', 'pattern' => '/^[a-zA-Z0-9]+([_.-]?[a-zA-Z0-9]){3,25}$/'],
//            ['username', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This username has already been taken.'],
//            ['email', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This email address has already been taken.'],
//            ['mobile', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This mobile already registered with us.'],
//            ['mobile', 'is10NumbersOnly'],
            ['mobile', 'number'],
            ['mobile', 'unique', 'targetClass' => '\app\models\User', 'message' => 'This mobile is already registered with us.'],
            ['password', 'string', 'min' => 6],
            ['agreement', 'required', 'requiredValue' => 1, 'message' => 'Please accept terms and conditions.']
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup() {
        if ($this->validate()) {

            $user = new User();

            $user->username = $this->username;
            $user->email = $this->email;
            $user->mobile_code = $this->mobile_code;
            $user->mobile = $this->mobile;
            $user->account_type = $this->account_type;
            $user->status = User::STATUS_ACTIVE;
            $user->ph_id = User::AVATAR_DEFAULT;
            $user->mobile_status = User::MOBILE_VERIFICATION_PENDING;
            $user->email_status = User::EMAIL_VERIFICATION_PENDING;
            $user->setPassword($this->password);
            $user->generateAuthKey();

//            $user->getActivationKey();

            if ($user->save()) {
                $this->generateProfileByAccountType($user);
                $this->_user = $user;
                return $this->_user;
            }
        }

        return null;
    }

    public function attributeLabels() {
        return [
            'email' => 'Email',
            'password' => 'Password',
            'mobile_code' => 'Country Code',
            'mobile' => 'Mobile',
            'user_type' => 'User Type',
            'agreement' => 'I agree to the Terms of Service and Privacy Policy.',
            'gender' => 'Gender',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    public function is10NumbersOnly($attribute) {
        if (!preg_match('/^[0-9]{10}$/', $this->$attribute)) {
            return $this->addError($attribute, 'must contain exactly 10 digits.');
        }
    }

    public function age_greater_than_14($attribute, $params) {
        $from = new DateTime($this->birthday);
        $now = new dateTime('today');
        $age = $from->diff($now)->y;
        if ($age < SignupForm::MIN_AGE_REQUIRED) {
            $message = strtr('You must be more than 14 years.', ['{attribute}' => $this->getAttributeLabel($attribute)]);
            $this->addError($attribute, $message);
        }
    }

    /*
     * generates profile for user by account type
     * @return
     */

    public function generateProfileByAccountType($user) {
        switch ($user->account_type) {
            case User::USER_TYPE_BUYER: {
                    $buyer = new Buyer();
                    $buyer->id = $user->id;
                    return $buyer->save();
                }
            case User::USER_TYPE_SELLER: {
                    $seller = new Seller();
                    $seller->id = $user->id;
                    return $seller->save();
                }
            default:
                return NULL;
        }
    }
    
    public function sendEmail(){
        
    }

}
