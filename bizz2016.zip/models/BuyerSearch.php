<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Buyer;

/**
 * BuyerSearch represents the model behind the search form about `app\models\Buyer`.
 */
class BuyerSearch extends Buyer {

    public $fullname = '';
    public $email = '';
    public $mobile = '';
    public $username = '';

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['by_id', 'id', 'mobile', 'created_by', 'updated_by', 'created_at', 'updated_at'], 'integer'],
            [['fullname', 'email', 'username'], 'string'],
            [['fullname', 'email', 'username'], 'filter', 'filter' => 'trim'],
            [['by_company_name', 'by_industry_type', 'by_concerned_person_name', 'by_designation', 'by_company_description'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Buyer::find();
        $query->joinWith('profile');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'by_id' => $this->by_id,
            'id' => $this->id,
            'user.mobile' => $this->mobile,
            'user.email' => $this->email,
            'user.username' => $this->username,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'by_company_name', $this->by_company_name])
                ->andFilterWhere(['like', 'user.name', $this->fullname])
//                ->andFilterWhere(['like', 'user.mobile', $this->mobile])
//                ->andFilterWhere(['like', 'user.email', $this->email])
//                ->andFilterWhere(['like', 'surname', $this->fullname])
                ->andFilterWhere(['like', 'by_industry_type', $this->by_industry_type])
//                ->andFilterWhere(['like', 'by_concerned_person_name', $this->by_concerned_person_name])
//                ->andFilterWhere(['like', 'by_designation', $this->by_designation])
                ->andFilterWhere(['like', 'by_company_description', $this->by_company_description]);
        if ($this->fullname)
            $query->orWhere(['like', 'user.surname', $this->fullname]);

        return $dataProvider;
    }

}
