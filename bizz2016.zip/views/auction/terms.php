<?php
$this->title = "Add Non-negotiable points";

use yii\helpers\Html;
use yii\widgets\ActiveForm;

//app\components\Helper::pp($model);
?>

<div class="row"> 
    <div class="col-sm-8">
        <div class="page-header">
            <h2>Terms and conditions.</h2>
        </div>        
    </div>
</div>


<div class="profile-partials-seller">
    <div class="row">
        <?php
        $form = ActiveForm::begin([
                    'action' => ['auction/terms', 'id' => $model->auc_id],
//            'layout' => 'horizontal',
                    'id' => 'auctionterms-form',
//            'enableAjaxValidation' => true,
//            'validationUrl' => ['profile/validation', 'scenario' => 'update_basic_profile'],
                    'fieldConfig' => [
                        'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                        'horizontalCssClasses' => [
                            'label' => 'col-sm-12',
                            'offset' => 'col-sm-offset-4',
                            'wrapper' => 'col-sm-9',
                            'error' => '',
                            'hint' => '',
                        ],
                    ],
        ]);
        ?>

        <div class="col-sm-8"> 
            <?= $form->field($model, 'auc_terms')->textarea(['rows' => 6])->label(false) ?>
        </div>

        <div class="col-sm-8 response-container">
            <hr>
            <div class="form-group">
                <?= Html::submitButton('Save and continue.', ['class' => 'btn btn-success']) ?>
            </div>
        </div>       

        <?php ActiveForm::end(); ?>
    </div>

</div>
<!-- profile-partials-buyer -->
