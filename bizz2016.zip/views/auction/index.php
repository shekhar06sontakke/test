<?php

use yii\helpers\Html;
use app\models\Auction;

$this->title = $model->auc_title;
//print_r($model);
?>

<div class="col-sm-10 col-sm-offset-1">
    <div class="panel panel-default auction-view">
        <div class="panel-heading">
            <div class="col-sm-8">
                <h2 style="font-size: 26px; font-family: lato-bold;"><?= $this->title ?></h2>
            </div>
            <?= yii\helpers\Html::input('hidden', '', $model->auc_id, ['id' => 'aucID']) ?>
            <?php
            if ($model->auc_status == \app\models\Auction::STATUS_ACTIVE):
                ?>
                <div class="auction-status pull-right">
                    <?php
                    $diff = \app\components\Helper::getDifferenceBetweenDates(time(), $model->auctiondata->aucd_end_date);
                    ?>
                    <span> <?= $diff['day'] . ' days, ' . $diff['hour'] . ' hours left' ?> </span><br>
                    <a href="#" class="">ACTIVE</a>
                </div>
                <?php
            else:
                ?>
                <div class="auction-status pull-right">
                    <a href="#" class="" style="color: #FF7272;">CLOSED</a>
                </div>
            <?php
            endif;
            ?>

        </div>
        <div class="panel-body">
            <?php if (!Yii::$app->user->isGuest) { ?>

                <div class="row">
                    <div class="auction-brief">                
                        <h3 class="auction-description-subheading">Description</h3>
                        <?= $model->auc_short_description ?><br>
                        <h3 class="auction-description-subheading">About the Buyer</h3>
                        <div class="buyer_images pull-left">
                            <a id="single_image" class="fancybox" href="<?php echo \yii\helpers\Url::to('@web/' . $model->buyer->profile->photo->ph_path . '/' . $model->buyer->profile->photo->ph_name); ?>">
                                <?= yii\helpers\Html::img('@web/' . $model->buyer->profile->photo->ph_path . '/' . $model->buyer->profile->photo->ph_name, ['width' => '30']) ?>
                            </a>
                        </div>
                        <div class="pull-left">
                            Name  : <?= yii\helpers\Html::a($model->buyer->profile->username, '#', ['class' => '']) ?><br>
                            <?= $model->buyer->by_company_name ?>

                        </div>
                    </div>
                    <div class="auction-sidebar">
                        <?php // yii\helpers\Html::a('Bid on this Auction', '#', ['class' => 'btn btn-block btn-primary', 'id' => 'bidnow'])     ?>
                        <div class="auction-round">
                            <span class="round-no" ><?= $model->auc_round ?></span> 
                            <span class="round-text">Round</span>
                        </div>

                    </div>
                    <?php
                    if (!Yii::$app->user->isGuest && Yii::$app->user->identity->account_type == app\models\User::USER_TYPE_BUYER && (Yii::$app->params['me']->buyer->by_id == $model->by_id)) {
                        ?>
                        <div class="buyer_update_btn">
                            <a class="btn  btn-success" href=" <?php echo \yii\helpers\Url::to(['auction/update', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $model->auc_round]); ?>">Update</a>
                        </div>
                    <?php } ?>
                </div>
                <div class="row">
                    <hr>    
                    <div class="auction-info-container">
                        <h3 class="auction-description-subheading">Quotation</h3>
                        <p style="font-size: 12px;">
                            * Default Currency: <?= $model->auc_currency ?><br>
                            * Provide your bid in Rate column.
                        </p>
                        <div class="grd-data-container grd-left">
                            <div id="gridGDD" class=""></div>
                        </div>
                        <div class="grd-data-container grd-right">
                            <div id="gridGDB" class=""></div>
                        </div>
                    </div>   

                </div>
                <div class="row">
                    <hr>
                    <div class="auction-info-container">
                        <h3 class="auction-description-subheading">Files</h3>

                        <?php
                        $files = $model->files;
                        if (count($files)) {
                            echo Html::tag('ul');
                            foreach ($files as $file) :
                                echo Html::tag('li', Html::a($file->aucf_name, '@web/' . $file->aucf_path . '/' . $file->aucf_name, ['target' => '_blank']));
                            endforeach;
                            echo Html::endTag('ul');
                        }else {
                            echo 'Sorry! no files here.';
                        }
//                        app\components\Helper::pp($files);
                        ?>

                    </div>
                </div>
                <div class="row">  
                    <hr>
                    <div class="auction-info-container">
                        <?php
                        if (Yii::$app->user->identity->account_type == app\models\User::USER_TYPE_SELLER) {

                            $bid = $model->getbidbyuser();
                            switch ($model->auc_status) {
                                case Auction::STATUS_ACTIVE: {
                                        switch ($model->auc_type) {
                                            case Auction::AUCTION_TYPE_OPEN: {
                                                    if (isset($bid->sl_id)) {
                                                        ?>
                                                        <div class="alert alert-success">
                                                            <i class="mdi mdi-checkbox-marked-circle md-30"></i> You have successfully placed your bid.
                                                        </div>
                                                        <?php
                                                    } else {
                                                        ?>                                    
                                                        <h3 class="auction-description-subheading">Terms and conditions</h3>
                                                        <p><?= $model->auc_terms ?></p>
                                                        <p>
                                                            <input type="checkbox" id="agreement" > <span style="color: #FF6E40;"> I accept all terms and conditions! </span> 
                                                            <button class="btn btn-success pull-right" disabled="" id="btn-place-bid"><i class="mdi mdi-checkbox-marked-circle md-24"></i> Place my bid.</button>
                                                        </p>

                                                        <?php
                                                    }
                                                    break;
                                                }

                                            case Auction::AUCTION_TYPE_PRIVATE: {
                                                    $invitation = $model->isSellerInvitationExist(Yii::$app->params['me']->seller->sl_id);

                                                    if (isset($invitation->sl_id)) {
                                                        if (isset($bid->sl_id)) {
                                                            ?>
                                                            <div class="alert alert-success">
                                                                <i class="mdi mdi-checkbox-marked-circle md-30"></i> You have successfully placed your bid.
                                                            </div>
                                                            <?php
                                                        } else {
                                                            ?>                                    
                                                            <h3 class="auction-description-subheading">Terms and conditions</h3>
                                                            <p><?= $model->auc_terms ?></p>
                                                            <p>
                                                                <input type="checkbox" id="agreement" > <span style="color: #FF6E40;"> I accept all terms and conditions! </span> 
                                                                <button class="btn btn-success pull-right" disabled="" id="btn-place-bid"><i class="mdi mdi-checkbox-marked-circle md-24"></i> Place my bid.</button>
                                                            </p>

                                                            <?php
                                                        }
                                                        break;
                                                    } else {
                                                        echo 'Sorry this is private auction.';
                                                    }

                                                    break;
                                                }

                                            default:
                                        }

                                        break;
                                    }

                                case Auction::STATUS_CLOSE: {
                                        ?>
                                        <div class="alert alert-warning">
                                            <i class="mdi mdi-information md-30"></i> Sorry! This auction is closed. You can't bid here.
                                        </div>

                                        <?php
                                        break;
                                    }

                                default:
                                    break;
                            }
                        }
                        ?>

                    </div>
                </div>

            <?php } else { ?>
                <div class="row">                      
                    <div class="auction-info-container">
                        <h3 class="auction-description-subheading">Login/Signup</h3>
                        <p>You need to logged in to see details.</p>
                        <?= Html::a('Signup', ['site/signup', 'token'=> Yii::$app->request->get('token')], ['class' => 'btn btn-success']) ?>
                        <?= Html::a('login', ['site/login', 'token'=> Yii::$app->request->get('token')], ['class' => 'btn btn-warning']) ?>
                    </div>
                </div>

            <?php } ?>


        </div>
    </div>

    <?php
    if (!Yii::$app->user->isGuest && Yii::$app->user->identity->account_type == app\models\User::USER_TYPE_BUYER && (Yii::$app->params['me']->buyer->by_id == $model->by_id)) {
        ?>
        <div class="panel panel-default auction-view">
            <div class="panel-heading">
                <h3> Report </h3>
            </div>
            <div class="panel-body">
                <div class="grd-data-container grd-left">
                    <div id="gridGDR" class=""></div>
                </div>
            </div>

        </div>

        <?php
    }
    ?>

</div>

<?= $this->registerJsFile('@web/js/bid.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\HandsontableAsset', '\app\assets\JqueryConfirmAsset']]) ?>