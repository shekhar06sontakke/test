
<div class="page-header">
    <h2>Upload documents</h2>
</div>

<input type="hidden" id="aucID" value="<?= $model->auc_id ?>" >

<div class="col-sm-6">
    <div class="xar">
        <div class="file-uploader-area xar-element" id="testID">
            <span class="btn btn-plain btn-file-uploader" id="">
                <span class="mdi mdi-plus md-24 fl-icon-plus"></span>
                <span> Upload Files</span>
            </span>
            <p class="file-upload-text">Drag &amp; drop any images or documents that might be helpful in explaining your auction brief here</p>
        </div>
        <table class="file-uploader-table default-table table-alt-row fileupload-item-list" role="presentation">
            <tbody class="files">
                <?php
//                \app\components\Helper::pp($model->files);

                if ($model->files):
                    foreach ($model->files as $file) :
                        ?>
                        <tr class="template-download  in" style="" id="<?= 'dbx' . mt_rand(1, 99) ?>">
                            <?php
                            $ext = pathinfo($file->aucf_name, PATHINFO_EXTENSION);
                            ?>
                            <td class="preview">
                                <?php
                                if ($ext == 'pdf'):
                                    echo \yii\bootstrap\Html::a('view', '@web/' . $file->aucf_path . '/' . $file->aucf_name, ['target' => '_blank', 'style' => 'width: 50px;']);
                                else:
                                    echo \yii\bootstrap\Html::img('@web/' . $file->aucf_path . '/' . $file->aucf_name, ['style' => 'width: 50px;']);
                                endif;
                                ?>
                            </td>
                            <td class="name"><span><?= substr($file->aucf_name, 0, 20) . '..' ?></span></td>
                            <td class="size" colspan="2"> 188 KB. </td>                    
                            <td class="delete" style="" ><button class="btn btn-danger btn-small remove-file" data-fileID="<?= $file->aucf_id ?>"><span>Delete</span></button>
                            </td>
                        </tr>
                        <?php
                    endforeach;
                    ?>

                    <?php
                endif;
                ?>
            </tbody>
        </table>

    </div>
</div>

<!--$('#aucID').val()-->
<?php
$this->registerJs(" var u1 = new Upload({selector: '#testID', url: '/auction/doc-upload',params: {aucID: $('#aucID').val() } });  ", yii\web\View::POS_END, 'my-options');
?>

