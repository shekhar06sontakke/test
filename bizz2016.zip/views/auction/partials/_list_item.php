<?php

// _list_item.php
use yii\helpers\Html;
use yii\helpers\Url;
?>
<?php ?>
<article class="info-list" data-key="<?php // $model->sl_id;                       ?>" >
    <figure class="info-list-img">
        <?php
        $photo = $model->buyer->profile->photo;
//        \app\components\Helper::pp($photo); 
//        die();
        ?>
        <?= Html::img('@web/' . $photo->ph_path . '/' . $photo->ph_name) ?>
    </figure>
    <div class="info-list-inner">
        <div class="info-left">
            <div class="info-list-title"><?= Html::a($model->auc_title, ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug], []) ?></div>
            <div class="info-list-description"><p class="short-description"><?= $model->auc_short_description ?></p></div>
            <div class="info-list-details">
                <span>

                </span>
            </div>
            <div class="info-list-categories">
                <ul class="list">
                    <?php
                    echo Html::tag('li', Html::a($model->category->cat_name, ['auction/listing', 'cat' => $model->category->cat_slug]), []);
                    ?>
                </ul>
            </div>
        </div>
        <div class="info-right">
            <div class="auction-status">
                <?php
//                if (time() > $model->auc_end_date):
//                    echo Html::a('Closed', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug], ['class' => 'btn btn-block btn-warning']);
//
//                else:
                $diff = isset($model->auctiondata->aucd_end_date)  ? \app\components\Helper::getDifferenceBetweenDates(time(), $model->auctiondata->aucd_end_date) : NULL;
//                                    \app\components\Helper::pp($diff);
////                                    die();
                if ($model->auc_status == \app\models\Auction::STATUS_ACTIVE):
                    ?>
                    <span><?= isset($model->auctiondata->aucd_start_date) ? Yii::$app->formatter->asDate($model->auctiondata->aucd_start_date, 'php: M d, Y') : '' ?><br><i class="mdi mdi-clock-fast md-18"></i> <?= isset($diff['day']) ? ($diff['day'] . 'd ' . $diff['hour'] . 'h') : '' ?> </span><br>
                    <a href="#" class="btn btn-block btn-warning"><?= $model->auc_status == \app\models\Auction::STATUS_ACTIVE ? 'ACTIVE' : 'CLOSED' ?></a>

                    <?php
                    if ($model->auc_status == \app\models\Auction::STATUS_ACTIVE):
                        echo Html::a('Bid Now', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug], ['class' => 'btn btn-block btn-success']);
                    endif;
                else:
                    ?>
                    <a href="#" class="btn btn-block btn-warning"><?= $model->auc_status == \app\models\Auction::STATUS_ACTIVE ? 'ACTIVE' : 'CLOSED' ?></a>

                <?php
                endif;
                ?>

                <?php
//                endif;
                ?>
            </div>
        </div>
    </div>
</article>