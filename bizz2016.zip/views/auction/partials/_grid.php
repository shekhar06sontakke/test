<div class="row">
    <!--<div class="col-sm-12" style="margin-bottom: 10px;">-->  
    <!--        <div class="col-sm-4">
    
                <div class="control-btn-group">
                    <input type="text" class="form-control" placeholder="Row" id="inputGridRow">        
                    <input type="text" class="form-control" placeholder="Col" id="inputGridCol">
                    <button class="btn btn-primary " id="btnGridInit" >Insert</button>            
                </div>
            </div>-->
    <div class="col-sm-4">
        <div class="control-btn-group">
            <input type="text"  class="form-control" id="gridItemsQty" placeholder="QTY." id="">                    
            <select class="form-control" id="gridItemType">
                <option >Select</option>
                <option value="row" >Row</option>
                <option value="col" >Column</option>
            </select>
            <button class="btn btn-primary" id="btnAddGridItem" >Insert</button>
        </div>
    </div>
    <div class="col-sm-2" id="r_gd">
        <div class="control-btn-group">
            <button class="btn btn-success" id="btnGridSave" >Save</button>
        </div>
    </div>
    <div class="col-sm-2" id="">
        <div class="control-btn-group">
            <button class="btn btn-success" id="btnGridExport" ><i class="mdi mdi-file-excel md-16"></i>Export</button>
        </div>
    </div>
    
    <!--</div>-->
</div>

<div class="row">    
    <hr>    
    <div class="col-sm-12">

        <div class="grd-data-container grd-left">
            <div id="gridGDD" class=""></div>
        </div>
        <div class="grd-data-container grd-right">
            <div id="gridGD" class=""></div>
        </div>

    </div>
</div>
