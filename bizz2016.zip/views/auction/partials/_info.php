<?php

use yii\helpers\Html;
?>

<div class="row">
    <div class="col-sm-6">
        <div class="form-group">
            <div class="control-label">Title</div>
            <div>
                <?= Html::textarea('', $model->auc_title, ['rows' => 3,'class' => 'form-control', 'disabled' => true]) ?>
            </div>
        </div>        
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="form-group">
            <div class="control-label">Round</div>
            <div>
                <?= Html::textarea('', $model->auc_short_description, [ 'rows' => 3, 'class' => 'form-control', 'disabled' => true]) ?>
            </div>
        </div>        
    </div>
</div>
<div class="row">
    <div class="col-sm-3">
        <div class="form-group">
            <div class="control-label">Round (Active)</div>
            <div>
                <?= Html::input('text', '', $model->auc_round, ['class' => 'form-control', 'disabled' => true]) ?>
            </div>
        </div>        
    </div>
    <div class="col-sm-3">
        <div class="form-group">
            <div class="control-label">Rounds (Total)</div>
            <div>
                <?= Html::input('text', '', $model->auc_rounds, ['class' => 'form-control', 'disabled' => true]) ?>
            </div>
        </div>        
    </div>
</div>

