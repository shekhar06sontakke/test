<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

//\app\components\Helper::pp($model);

$form = ActiveForm::begin([
//            'layout' => 'horizontal',
            'id' => 'mv_auction_dur_form',
//            'enableAjaxValidation' => true,
//            'validationUrl' => ['profile/validation', 'scenario' => 'update_basic_profile'],
            'fieldConfig' => [
                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                'horizontalCssClasses' => [
                    'label' => 'col-sm-12',
                    'offset' => 'col-sm-offset-4',
                    'wrapper' => 'col-sm-9',
                    'error' => '',
                    'hint' => '',
                ],
            ],
        ]);

//$model->scenario = app\models\AuctionData::SCENARIO_UPDATE_DURATION;
echo Html::activeHiddenInput($model, 'scenario');
?>


<div class="row">
    <?php
    $date_state = $model->aucd_start_date ? true : FALSE;
    ?>
    <div class="col-sm-3"><?= $form->field($model, 't_aucd_start_date')->textInput(['class' => 'form-control datepicker', 'disabled' => $date_state]) ?></div>
    <div class="col-sm-3"><?= $form->field($model, 't_aucd_end_date')->textInput(['class' => 'form-control datepicker', 'disabled' => $date_state]) ?></div>
</div>
<div class="row">
    <hr>
    <div class="col-sm-12" id="raucb">
        <?= Html::submitButton('Save &AMP; continue.', ['class' => 'btn btn-primary', 'disabled' => $date_state]) ?>        
    </div>
</div>

<?php ActiveForm::end(); ?>
