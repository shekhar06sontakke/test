<div class="row">   
    <div class="col-sm-12">
        <h4>Search for sellers.</h4>
        <select class="" id="searchSeller" multiple style="width: 100%;" data-placeholder="Search Seller to invite">                
            <?php
            
            if ($invitations = $model->getInvitations($round)) {                
                
                foreach ($invitations as $invitation) {

                    echo '<option value="' . $invitation->sl_id . '" selected="selected">' . $invitation->seller->sl_company_name . '<option>';
                }
            }
            ?>
        </select>
    </div>
</div>

<div class="row" style="margin-top: 20px;">
    <div class="col-sm-12">
        <h4>Invite Sellers by Email</h4>
        <input type="text" class="form-control" value="<?= isset($model->invitationEmail) ? $model->invitationEmail->invte_email_list : '' ?>" id="inviteByEmail">        
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="response-container" id="inv_response-container">
            <hr>
            <button class="btn btn-success" id="btnSendInvitaion" data-aucid="<?= $model->auc_id ?>"><i class="mdi mdi-email md-24"></i> Send Invitation!</button>
        </div>

    </div>

</div>

<?= $this->registerJsFile('@web/js/invite.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset']]) ?>