<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

$form = ActiveForm::begin([
//            'layout' => 'horizontal',
//            'id' => 'mv_update_basic_form',
//            'enableAjaxValidation' => true,
//            'validationUrl' => ['profile/validation', 'scenario' => 'update_basic_profile'],
            'fieldConfig' => [
                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                'horizontalCssClasses' => [
                    'label' => 'col-sm-12',
                    'offset' => 'col-sm-offset-4',
                    'wrapper' => 'col-sm-9',
                    'error' => '',
                    'hint' => '',
                ],
            ],
        ]);
?>
<div class="row">
    <div class="col-sm-12"><?= $form->field($model, 'auc_title')->textInput(['placeholder' => 'Provide title for your auction']) ?></div>
</div>
<div class="row">
    <div class="col-sm-12"><?= $form->field($model, 'auc_slug')->textInput(['placeholder' => 'Slug for title']) ?></div>
</div>

<div class="row">
    <div class="col-sm-12"><?= $form->field($model, 'cat_id')->dropDownList(app\models\Category::getHierarchy(), ['prompt' => 'Select Category','class'=>'select2Input']) ?></div>
</div>
<?php //echo $model->getAttributeHint('auc_title') ?>

<div class="row">
    <div class="col-sm-3"><?= $form->field($model, 'auc_type')->dropDownList(app\components\OptionList::get_auction_type(), ['prompt' => 'Select Type']) ?></div>
    <div class="col-sm-3"><?= $form->field($model, 'auc_rounds')->dropDownList(array_combine(range(1, 3), range(1, 3)), ['prompt' => 'Select Round']) ?></div>
</div>

<div class="row">
    <div class="col-sm-3"><?= $form->field($model, 'auc_currency')->dropDownList(ArrayHelper::map(\app\models\Country::find()->all(), 'currency', function($model) {
            return $model->country_name . ' (' . $model->currency . ')';
        }), ['prompt' => 'Select Currency']) ?></div>
</div>
<div class="row">
    <div class="col-sm-12"><?= $form->field($model, 'auc_short_description')->textarea(['cols' => 5, 'rows' => 3]) ?></div>
</div>
<div class="row">
    <hr>
<?= Html::submitButton('Save &AMP; continue.', ['class' => 'btn btn-primary pull-right']) ?>
</div>

<?php ActiveForm::end(); ?>
