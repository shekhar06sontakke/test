<?php

use app\models\AuctionData;

$this->title = "Update Auction";
?>

<div class="row" style="margin-top: 20px;margin-bottom: 30px;">
    <div class="col-sm-10 col-sm-offset-1">

        <?php
        $next_round = $model->auc_round + 1;
        
        
        for ($index = 1; $index <= $model->auc_rounds; $index++) :

            if ($index == $round):
                ?>
                <div class="col-md-3 col-xs-3 step-bar offset-margin text-center">
                    <span class="step-checked" style="background-color: #599C1C;"><i id="u2" class="d1_start mdi  md-24"><?= $index ?></i></span>
                    <div class="profile-step-unchecked text-center"></div>
                </div>
            <?php else : ?>
                <div class="col-md-3 col-xs-3 step-bar offset-margin text-center">
                    <?php
                    if (( $index == $next_round)) {
//                        app\components\Helper::pp($next_round);
                        $auctiondata_next = $model->getAuctiondata($index);

                        if ( time() > $auctiondata->aucd_end_date) {
                            $switch_id = isset($auctiondata_next->auc_id) ? '' : 'switch-round';
                            ?>
                            <span class="step-checked" style="background-color: #a94442;">
                                <?= \yii\helpers\Html::a('<i class="d1_start mdi  md-24">' . $index . '</i>', ['auction/update', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $index], ['class' => 'd1_start mdi  md-24', 'id' => $switch_id]) ?>
                            </span>
                            <div class="profile-step text-center" style="background-color: #a94442;"></div>
                            <?php
                        } else {
                            ?>
                            <span class="step-checked">
                                <?= \yii\helpers\Html::a('<i class="d1_start mdi  md-24">' . $index . '</i>', '#', ['class' => 'd1_start mdi  md-24', 'onclick' => 'return false;']) ?>

                            </span>
                            <div class="profile-step text-center"></div>
                            <?php
                        }
                    } elseif ($index > $next_round) {
                        ?>
                        <span class="step-checked">
                            <?= \yii\helpers\Html::a('<i class="d1_start mdi  md-24">' . $index . '</i>', '#', ['class' => 'd1_start mdi  md-24', 'onclick' => 'return false;']) ?>

                        </span>
                        <div class="profile-step text-center"></div>
                        <?php
                    } else {
                        ?>
                        <span class="step-checked">
                            <?= \yii\helpers\Html::a('<i class="d1_start mdi  md-24">' . $index . '</i>', ['auction/update', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $index], ['class' => 'd1_start mdi  md-24']) ?>

                        </span>
                        <div class="profile-step text-center"></div>
                        <?php
                    }
                    ?>
                </div>
            <?php endif; ?>

        <?php endfor; ?>

    </div>
</div>

<input type="hidden" id="aucID" value="<?= $model->auc_id ?>" >
<input type="hidden" id="aucRound" value="<?= $round ?>" >
<div class="row">
    <div class="col-sm-10 col-sm-offset-1">
        <div class="panel panel-default">
            <div class="panel-body">
                <!-- Nav tabs -->
                <!--<div class="col-sm-12">-->
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#basic" aria-controls="basic" role="tab" data-toggle="tab">Provide Info</a></li>
                    <li role="presentation" class=""><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Generate RFQ</a></li>
                    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Upload Documents</a></li>
                    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Update Terms</a></li>
                    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Send Invitation</a></li>
                </ul>

                <!--</div>-->
                <?php
//                        \app\components\Helper::pp($model);
//                $model->auc
                if ($model->auc_round == $round) {
                    switch ($model->auc_status) {
                        case \app\models\Auction::STATUS_DRAFT: {
                                echo \yii\helpers\Html::a('<i class="mdi mdi-calendar-clock md-24"></i> Publish', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug], ['class' => 'display-auction-btn btn btn-danger', 'id' => 'btn-publish']);
                                break;
                            }
                        case \app\models\Auction::STATUS_ACTIVE: {
                                echo \yii\helpers\Html::a('<i class="mdi mdi-eye md-24"></i> show Auction', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $round], ['class' => 'display-auction-btn btn btn-warning']);
                                break;
                            }
                        case \app\models\Auction::STATUS_CLOSE: {
                                echo \yii\helpers\Html::a('<i class="mdi mdi-eye md-24"></i> show Auction', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug, 'round' => $round], ['class' => 'display-auction-btn btn btn-warning']);
                                break;
                            }


                        default:
                            break;
                    }
//                    if ($model->auc_status == \app\models\Auction::STATUS_DRAFT) {
//                        
//                    }
//                    \app\components\Helper::pp('$param');
                } else {
                    if ($round > $model->auc_round)
                        echo \yii\helpers\Html::a('<i class="mdi mdi-calendar-clock md-24"></i> Publish', ['auction/index', 'cat' => $model->category->cat_slug, 'slug' => $model->auc_slug], ['class' => 'display-auction-btn btn btn-danger', 'id' => 'btn-publish']);
                }
                ?>




                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="basic">   

                        <?= $this->render('partials/_info', ['model' => $model]) ?>

                        <?php
                        $auctiondata->scenario = AuctionData::SCENARIO_UPDATE_DURATION;
                        $auctiondata->setScenario(AuctionData::SCENARIO_UPDATE_DURATION);
                        ?>
                        <?= $this->render('partials/_form_duration', ['model' => $auctiondata]) ?>
                    </div>
                    <?php
//                    if (isset($auctiondata->aucd_start_date) && $auctiondata->aucd_start_date):
                    ?>

                    <div role="tabpanel" class="tab-pane" id="home">       
                        <?= $this->render('partials/_grid', ['model' => $model]) ?>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="profile">                
                        <?= $this->render('partials/_docs', ['model' => $model, 'round' => $round]) ?>   
                    </div>
                    <div role="tabpanel" class="tab-pane" id="messages">      
                        <?= $this->render('partials/_terms', ['model' => $model]) ?>   
                    </div>
                    <div role="tabpanel" class="tab-pane" id="settings">        
                        <?= $this->render('partials/_invite', ['model' => $model, 'round' => $round]) ?>   
                    </div>


                    <?php
//                    endif;
                    ?>

                </div>
            </div>
        </div>
    </div>

</div>


<?= $this->registerJsFile('@web/js/grid.js?v=1.0', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\HandsontableAsset', '\app\assets\JqueryConfirmAsset']]) ?>