<?php
//\app\components\Helper::pp($model);
?>

<div class="page-header">
    <h2>Create (RFQ) for your auction</h2>    
</div>
<div class="row">
    <div class="col-sm-12" style="margin-bottom: 10px;">
        <input type="hidden" id="aucID" value="<?= $model->auc_id ?>" >
        <div class="col-sm-1">
            <input type="text" class="form-control" placeholder="Row" id="inputGridRow">        
        </div>
        <div class="col-sm-1">
            <input type="text" class="form-control" placeholder="Col" id="inputGridCol">
        </div>
        <div class="col-sm-1 right">
            <button class="btn btn-primary " id="btnGridInit" >OK</button>
        </div>
        <div class="col-sm-1 right">
            <button class="btn btn-success" id="btnGridSave" >Save</button>
        </div>        
        <div class="col-sm-1 right">
            <button class="btn btn-primary" id="btnGridLoad" >Load</button>
        </div>        
        <!--        <div class="col-sm-1">
                    <i class="mdi mdi-plus md-24"></i> Add New   </div>
        -->     
        <div class="col-sm-1">                     
            <input type="text"  class="form-control" id="gridItemsQty" placeholder="QTY." id="">                    
        </div>        
        <div class="col-sm-2">                  
            <select class="form-control" id="gridItemType">
                <option >Select</option>
                <option value="row" >Row</option>
                <option value="col" >Column</option>
            </select>
        </div>
        <div class="col-sm-1 right">
            <button class="btn btn-primary" id="btnAddGridItem" >Add</button>
        </div>
    </div>
</div>

<div class="row">    
    <hr>    
    <div class="grd-data-container grd-left">
        <div id="gridGDD" class=""></div>
    </div>
    <div class="grd-data-container grd-right">
        <div id="gridGD" class=""></div>
    </div>

</div>
