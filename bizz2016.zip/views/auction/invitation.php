<?php
$this->title = "Invite Sellers";
?>

<div class="page-header">
    <h2 ><?= $this->title ?></h2>
</div>
<div class="col-sm-8">
    <div class="row">   
        <div class="col-sm-12">
            <?php
//            \app\components\Helper::pv($model);
//            die();
//            $invitations = $model->invitations;
//            app\components\Helper::pp($invitations);
            ?>
            <input type="hidden" id="aucID" value="<?= $model->auc_id ?>">
            
            <?php
//            echo yii\helpers\Html::dropDownList('', null, $items);
            ?>
            <select class="" id="searchSeller" multiple style="width: 100%;" data-placeholder="Search Seller to invite">                
                <?php
                if ($invitations = $model->invitations) {
                    foreach ($invitations as $invitation) {
                        echo '<option value="' . $invitation->sl_id . '" selected="selected">' . $invitation->seller->sl_company_name . '<option>';
                    }
                }
                ?>
            </select>
        </div>
    </div>

    <div class="row" style="margin-top: 20px;">
        <div class="col-sm-12">
            <h4>Invite Sellers by Email</h4>
            <input type="text" class="form-control" value="<?= isset($model->invitationEmail) ? $model->invitationEmail->invte_email_list : '' ?>" id="inviteByEmail">        
        </div>
    </div>
    <div class="response-container" id="">
        <hr>
        <button class="btn btn-success" id="btnSendInvitaion" data-aucid="<?= $model->auc_id ?>"><i class="mdi mdi-email md-24"></i> Send Invitation!</button>
    </div>

</div>

<?= $this->registerJsFile('@web/js/invite.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset']]) ?>