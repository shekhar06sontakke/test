<?php
$this->title = "Create new Auction."
?>

<div class="page-header">
    <h3><?= $this->title ?></h3>
</div>
<div class="col-sm-8">
    <?= $this->render('partials/_form', ['model' => $model]) ?>
</div>



<?= $this->registerJsFile('@web/js/auction-create.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset']]) ?>