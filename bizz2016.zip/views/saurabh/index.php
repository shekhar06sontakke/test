

<?php

echo "Index file==". $email;
?>
