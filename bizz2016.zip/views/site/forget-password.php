<?php 

use app\components\Helper;

//Helper::pp($data);

//echo "Msg -".$data['step'];
?>

<h1>Forget Password?</h1>

<div class="col-md-6 col-md-offset-3">
    
    <?php if ($data['step'] == 'find_acc') { ?>

        <div class="panel panel-default">
            <!-- Default panel contents -->        
            <form class="form-horizontal" action="<?= yii\helpers\Url::to(['site/forget-password']) ?>" method="post">
                <div class="panel-body">
                    <h4>Reset your password</h4>            
                    <p style="text-align: center;  margin: 10px;  font-size: 14px;  color: rgb(111, 105, 105);">
                        Provide Email, Phone, USER-ID
                    </p>
                    <div class="form-group">
                        <label class="control-label col-sm-3"><i class="fa fa-envelope-o" style="font-size: 30px; margin-top: -8px;"></i></label>
                        <div class="col-sm-6">
                            <input type="hidden" class="form-control" name="step" value="find_acc">
                            <input type="text" class="form-control" name="term">
                            <input type="hidden" class="form-control" name="_csrf" value="<?= Yii::$app->request->getCsrfToken() ?>">
                        </div>

                    </div>
                </div>
                <div class="panel-footer">
                    <?= yii\helpers\Html::a('Home', ['site/index'], ['class' => 'btn btn-primary btn-xs pull-right']) ?> 
                    <button class="btn btn-primary btn-xs pull-right">Search</button>
                    <div class="clearfix">
                    </div>
                </div>
            </form>

        </div>
        <?php
    }
    ?>
    
    <?php if ($data['step'] == 'reset_method') { ?>

        <div class="panel panel-default">
            <!-- Default panel contents -->        
            <form class="form-horizontal" action="<?= yii\helpers\Url::to(['site/forget-password']) ?>" method="post">
                <div class="panel-body">
                    <h4>Reset your password</h4>            
                    <div class="col-md-9 rprm">
                        <p style="margin: 10px 0;  font-size: 14px;  color: rgb(111, 105, 105);">
                            How would you like to reset your password?
                        </p>

                        <div class="radio">
                            <label>
                                <input type="hidden" name="wm_code" id="" value="<?= $data['profile']->username ?>" >
                                <input type="hidden" name="step" id="" value="reset_method" >
                                <input type="radio" name="reset_method" id="" value="email" >
                                <input type="hidden" class="form-control" name="_csrf" value="<?= Yii::$app->request->getCsrfToken() ?>">
                                <i class="fa fa-envelope-o"></i> Email me a link to reset my password. <br/> <?= app\components\Helper::get_hashed_str($data['profile']->email, 'email') ?>
                            </label>
                        </div>
                        

                    </div>
                   

                </div>
                <div class="panel-footer clearfix">
                    <a href="<?= yii\helpers\Html::a('Home', ['site/index']) ?>" class="btn btn-primary btn-xs pull-right">Cancel</a>    
                    <button class="btn btn-primary btn-xs pull-right">Continue</button>

                </div>
            </form>

        </div>
        <?php
    }
    ?>
    
    
</div>