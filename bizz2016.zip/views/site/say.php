<?php

use yii\helpers\Html;

echo Html::encode($message);

?>