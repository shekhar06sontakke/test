<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Admgmt */

$this->title = 'Update Advertisement: ' . ' ' . $model->admg_id;
$this->params['breadcrumbs'][] = ['label' => 'Advertisement', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->admg_id, 'url' => ['view', 'id' => $model->admg_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="admgmt-update">
    <div class="panel panel-pro">
        <div class="panel-heading">
            <?= Html::encode($this->title) ?>    
        </div>
        <div class="panel-body">
            <div class="col-sm-6">
                <?=
                $this->render('_form', [
                    'model' => $model,
                ])
                ?>
            </div>
            <div class="col-sm-6">
                <?= Html::img(Yii::$app->params['siteUrl'] . '/upload/' . $model->admg_path . '/' . $model->admg_image, ['width' => 263, 'height' => 163,'class'=>'admg_img']) ?>
            </div>
        </div>
    </div>

</div>
