<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Admgmt */

$this->title = $model->admg_id;
$this->params['breadcrumbs'][] = ['label' => 'Admgmts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="admgmt-view">
    <div class="panel panel-pro">
        <div class="panel-heading">
            <?= Html::encode($this->title) ?>

        </div>
        <div class="panel-body">
            <p>
                <?= Html::a('Update', ['update', 'id' => $model->admg_id], ['class' => 'btn btn-primary']) ?>
                <?=
                Html::a('Delete', ['delete', 'id' => $model->admg_id], [
                    'class' => 'btn btn-danger',
                    'data' => [
                        'confirm' => 'Are you sure you want to delete this item?',
                        'method' => 'post',
                    ],
                ])
                ?>
            </p>
            <div class="row">
                <div class="col-sm-6">
                    <?=
                    DetailView::widget([
                        'model' => $model,
                        'attributes' => [
                            'admg_id',
                            'admg_title',
//            'admg_start_datetime:datetime',
//            'admg_end_datetime:datetime',
                            'admg_image',
                            'admg_path',
                            'admg_link:ntext',
                            'admg_position',
//            'admg_priority',
//            'created_by',
//            'updated_by',
//            'created_at',
//            'updated_at',
                        ],
                    ])
                    ?>
                </div>
                <div class="col-sm-6">
                    <?= Html::img(Yii::$app->params['siteUrl'] . '/upload/' . $model->admg_path . '/' . $model->admg_image, ['width' => 263, 'height' => 163, 'class' => 'admg_img']) ?>
                </div>
            </div>

        </div>
    </div>


</div>
