<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Admgmt */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="admgmt-form">
    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>
    <div class="col-sm-8">
        <div class="row">
            <div class="col-sm-12">
                <?= $form->field($model, 'admg_title')->textInput(['maxlength' => true]) ?>                
            </div>
        </div>
    </div>


    <div class="col-sm-8">
        <div class="row">
            <div class="col-sm-12">
                <?= $form->field($model, 'imageFile')->fileInput() ?>
            </div>
        </div>
    </div>

    <div class="col-sm-8">
        <div class="row">
            <div class="col-sm-12">
                <?= $form->field($model, 'admg_link')->textInput() ?>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="row">
            <div class="col-sm-12">
                <?= $form->field($model, 'admg_position')->dropDownList(['top' => 'Top', 'right' => 'Right'],['prompt'=>'Select Position']) ?>
            </div>
        </div>
    </div>

    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-3">
                <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>


<?= $this->registerJsFile('@web/js/admgmt.js', ['depends' => ['\app\assets\Select2Asset', 'app\assets\InputmaskAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>