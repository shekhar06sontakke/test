<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\AdmgmtSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="admgmt-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'admg_id') ?>

    <?= $form->field($model, 'admg_title') ?>
    

    <?= $form->field($model, 'admg_start_datetime') ?>

    <?= $form->field($model, 'admg_end_datetime') ?>

    <?= $form->field($model, 'admg_image') ?>

    <?php // echo $form->field($model, 'admg_path') ?>

    <?php // echo $form->field($model, 'admg_link') ?>

    <?php // echo $form->field($model, 'admg_priority') ?>

    <?php // echo $form->field($model, 'created_by') ?>

    <?php // echo $form->field($model, 'updated_by') ?>

    <?php // echo $form->field($model, 'created_at') ?>

    <?php // echo $form->field($model, 'updated_at') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
