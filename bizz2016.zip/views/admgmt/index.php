<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\AdmgmtSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Advertisements';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="admgmt-index">
    <div class="panel panel-pro">
        <div class="panel-heading">
            <?= Html::encode($this->title) ?>    
        </div>
        <div class="panel-body">
            <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
            <div class="row">
                <div class="col-sm-12">                    
                    <p class="pull-left" style="">
                        <?= Html::a('Create Advertisement', ['create'], ['class' => 'btn btn-success']) ?>                
                    </p>

                    <p class="pull-right">
                        <?= Html::a('Activate', '#', ['class' => 'btn btn-success', 'id' => 'btn-admgmt_activate']) ?>
                        <?= Html::a('Deactivate', '#', ['class' => 'btn btn-success', 'id' => 'btn-admgmt_deactivate', 'style' => 'margin:0 5px;']) ?>
                    </p>
                </div>

            </div>

            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    [ 'class' => 'yii\grid\CheckboxColumn'],
                    ['class' => 'yii\grid\SerialColumn'],
                    [
                        'attribute' => 'admg_status',
                        'format' => 'raw',
                        'value' => function($model) {
                            if ($model->admg_status == \app\models\Admgmt::STATUS_ON) {
                                return '<i class="mdi mdi-checkbox-marked-circle md-green md-24"></i>';
                            }
                            return "";
                        },
                    ],
//                    'admg_id',
                    'admg_image',
                    'admg_title',
                    'admg_position',
//                    'admg_start_datetime:datetime',
//                    'admg_end_datetime:datetime',
                    // 'admg_path',
                    // 'admg_link:ntext',
                    // 'admg_priority',
                    // 'created_by',
                    // 'updated_by',
                    // 'created_at',
                    // 'updated_at',
                    ['class' => 'yii\grid\ActionColumn',
                        'template' => '{view}{update}{delete}',
//                                'buttons' => [
//                                    'mark' => function($url, $model) {
//                                        return Html::checkbox('advt-selection[]', null, ['class' => 'advt-selection', 'value' => $model->admg_id]);
//                                    }
//                                        ]
                    ],
                ],
            ]);
            ?>
        </div>

    </div>


</div>

<!--//-->
<?= $this->registerJsFile('@web/js/admgmt.js', ['depends' => ['\app\assets\Select2Asset', 'app\assets\InputmaskAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>