<h1>Buyer Profile Update</h1>
<?php
    echo $this->render("_form",['model'=>$model]);
?>


