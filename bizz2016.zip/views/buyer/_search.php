<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\BuyerSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<?php
$form = ActiveForm::begin([
            'action' => ['index'],
            'method' => 'get',
        ]);
?>

<div class="panel panel-pro panel-default" >
    <div class="panel-heading">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>


    </div>
    <div class="panel-body padding-to-fields" style="height: 300px;overflow: auto;">
        <div class="row">            
            <?= $form->field($model, 'fullname')->textInput(['placeholder' => $model->getAttributeLabel('fullname')])->label(false) ?>
            <?= $form->field($model, 'username')->textInput(['placeholder' => $model->getAttributeLabel('username')])->label(false) ?>
            <?= $form->field($model, 'mobile')->textInput(['placeholder' => $model->getAttributeLabel('mobile')])->label(false) ?>
            <?= $form->field($model, 'email')->textInput(['placeholder' => $model->getAttributeLabel('email')])->label(false) ?>
            <?php // $form->field($model, 'by_industry_type')->textInput(['placeholder' => $model->getAttributeLabel('by_industry_type')])->label(false) ?>
            

        </div>
    </div>
    <div class="panel-footer panel-heading">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>
</div>


<?php ActiveForm::end(); ?>