<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\User;
use yii\helpers\ArrayHelper;
use app\components\OptionList;
/* @var $this yii\web\View */
/* @var $model app\models\Buyer */
/* @var $form ActiveForm */
?>
<div class="profile-partials-buyer">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-sm-8"><?= $form->field($model, 'by_bank_account_type')->dropDownList(OptionList::get_bank_account_type(),['prompt'=>'Select']) ?></div>
    </div>
    
    <div class="row">
        <div class="col-sm-4"><?= $form->field($model, 'by_industry_type')->dropDownList(['1'=>'one','2'=>'two'],['prompt'=>'Select']) ?></div>
    </div>  
    
    <div class="row">
        <div class="col-sm-4"><?= $form->field($model, 'by_concerned_person_name') ?></div>
        <div class="col-sm-4"><?= $form->field($model, 'by_designation')->dropDownList(['1'=>'one','2'=>'two'],['prompt'=>'Select']) ?></div>
    </div>
       
    <div class="row">
        <div class="col-sm-8"><?= $form->field($model, 'by_company_description')->textArea(['rows' => '6']) ?></div>
    </div>
    
    <div class="row">
        <div class="col-sm-6">
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    </div>
    </div>
    
    <?php ActiveForm::end(); ?>

</div><!-- profile-partials-buyer -->
