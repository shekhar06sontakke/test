<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\BuyerSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Buyers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="buyer-index">
    <div class="page-header set-buyer-title">
        <h2><?= Html::encode($this->title) ?>
            <?= \yii\helpers\Html::a('Add Buyers', ['profile/create'], ['class' => 'btn btn-success pull-right']) ?>
        </h2>

    </div>
    <div class="row">
        <div class="col-sm-3">
            <?php echo $this->render('_search', ['model' => $searchModel]); ?>

        </div>
        <div class="col-sm-9">
            <div class="panel panel-default">
                <div class="panel-body">
                    <?=
                    GridView::widget([
                        'dataProvider' => $dataProvider,
//                'filterModel' => $searchModel,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],
                            [
                                'attribute' => 'fullname',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->name . ' ' . $model->profile->father_name . ' ' . $model->profile->surname;
                                }
                            ],
                            [
                                'attribute' => 'username',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->username;
                                }
                            ],
                            [
                                'attribute' => 'mobile',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->mobile;
                                }
                            ],
                            [
                                'attribute' => 'email',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->email;
                                }
                            ],
//                            'by_id',
//                            'user.name',
                            'by_company_name',
//                            'by_industry_type',
//                            'by_concerned_person_name',
                            // 'by_designation',
                            // 'by_company_description:ntext',
                            // 'created_by',
                            // 'updated_by',
                            // 'created_at',
                            // 'updated_at',
                            ['class' => 'yii\grid\ActionColumn',
                                'template' => '{view} {upgrade}',
                                'buttons' => [
                                    'view' => function($url, $model) {
                                        return Html::a('<i class="mdi mdi-pencil-box md-18"></i>', ['profile/basic', 'id' => $model->profile->id], ['class' => '', 'target' => '_blank']);
                                    },
                                        ]
                                    ],
                                ],
                            ]);
                            ?>

                </div>
            </div>
        </div>
    </div>



</div>