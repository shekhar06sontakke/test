<?php
$this->title = "Choose Category.";

//app\components\Helper::pp($model);
//app\components\Helper::pp($model);
?>
<?= $this->render('partials/_menu') ?>
<div class="panel panel-pro">
    <!--        <div class="panel-heading">
    
            </div>-->
    <div class="panel-body">
        <div class="row">
            <div class="col-sm-8">

                <?= yii\helpers\Html::dropDownList('asd', $selected, app\models\Category::getHierarchy(), ['prompt' => 'Select Category', 'multiple' => true, 'class' => 'select2Input', 'id' => 'sl_chooseCategory']) ?></div>

        </div>
        <div class="row">
            <div class="col-sm-12 response-container">

            </div>
        </div>
    </div>
</div>


<?= $this->registerJsFile('@web/js/choose.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset']]) ?>