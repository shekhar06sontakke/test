<?php
$this->title = "Update Your company profile.";
//app\components\Helper::pp($model);
$id = $model->id;
$account_type = app\models\Profile::findOne($id);
$account_type->account_type;
//print_r($account_type);
?>
<?= $this->render('partials/_menu') ?>

<div class="col-sm-8">
    <div class="panel panel-pro">
        <!--        <div class="panel-heading">
        
                </div>-->
        <div class="panel-body">


            <?php
            if ($account_type->account_type == \app\models\User::USER_TYPE_BUYER) {
                echo $this->render('partials/_buyer', ['model' => $model]);
            } elseif ($account_type->account_type == \app\models\User::USER_TYPE_SELLER) {

                echo $this->render('partials/_seller', ['model' => $model]);
            }
            ?>
        </div>
    </div>
</div>

<?= $this->registerJsFile('@web/js/company.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>