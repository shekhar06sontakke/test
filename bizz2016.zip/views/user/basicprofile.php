<?php

/* @var $this yii\web\View */
?>
<?= $this->render('partials/_menu') ?>
<?php //die();    ?>
<?= $this->render('partials/_basic', ['model' => $model]) ?>

