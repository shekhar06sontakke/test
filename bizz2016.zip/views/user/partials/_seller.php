<?php

use yii\bootstrap\ActiveForm;
?>



<?php
$form = ActiveForm::begin([
//            'layout' => 'horizontal',
//            'id' => 'asdas',
//            'enableAjaxValidation' => true,
//            'validationUrl' => ['profile/validation'],
            'fieldConfig' => [
                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                'horizontalCssClasses' => [
                    'label' => 'col-sm-3',
                    'offset' => 'col-sm-offset-4',
                    'wrapper' => 'col-sm-9',
                    'error' => '',
                    'hint' => '',
                ],
            ],
        ]);

//$model->scenario = \app\models\Profile::SCENARTIO_BASIC_PROFILE_UPDATE;
//echo Html::activeHiddenInput($model, 'scenario');
?>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_company_name')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6">        
        <?= $form->field($model, 'sl_company_start_year')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_company_nature')->dropDownList(\app\components\OptionList::get_nature_of_company(), ['prompt' => 'select']) ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_industry_category')->dropDownList(\app\components\OptionList::get_category_of_industry(), ['prompt' => 'select']) ?>
    </div>                   
</div>
<div class="row" id="c_sl_industry_category_text" style="display: none;">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_industry_category_text')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_business_nature')->dropDownList(\app\components\OptionList::get_nature_of_business(), ['prompt' => 'select']) ?>
    </div>                   
</div>

<div class="row" id="c_sl_business_nature_text" style="display: none;">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_business_nature_text')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_current_product_service_details')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'sl_banker_name')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_banker_account_type')->dropDownList(\app\components\OptionList::get_bank_account_type(), ['prompt' => 'select']) ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_ifsc_code')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_micr_code')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_banker_city')->textInput() ?></div>
</div>

<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_account_no')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_tan_no')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_vtrn')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_atly')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_sister_concern_subsidiary')->textarea(['rows' => 4]) ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_change_in_firm_name')->textarea(['rows' => 4]) ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_company_description')->textarea(['rows' => 4]) ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'sl_change_in_firm_name')->textarea(['rows' => 4]) ?></div>
</div>

<div class="row">
    <div class="col-sm-12">
        <button type="submit" class="btn btn-success">Save</button>                    

    </div>
</div>



<?php ActiveForm::end(); ?>

<div class="row">
    <hr>
    <div class="col-sm-8">
        <div class="xar">
            <div class="file-uploader-area xar-element" id="testID">
                <span class="btn btn-plain btn-file-uploader" id="">
                    <span class="mdi mdi-plus md-24 fl-icon-plus"></span>
                    <span> Upload Files</span>
                </span>
                <p class="file-upload-text">Drag &amp; drop your company logo here.</p>
            </div>
            <table class="file-uploader-table default-table table-alt-row fileupload-item-list" role="presentation">
                <tbody class="files">
                    <?php
//                \app\components\Helper::pp($model->files);

                    if ($model->logo):
                        $file = $model->logo;
//                    foreach ($model->files as $file) :
                        ?>
                        <tr class="template-download  in" style="" id="<?= 'dbx' . mt_rand(1, 99) ?>">
                            <?php
                            $ext = pathinfo($file->ph_name, PATHINFO_EXTENSION);
                            ?>
                            <td class="preview">
                                <?php
                                if ($ext == 'pdf'):
                                    echo \yii\bootstrap\Html::a('view', '@web/' . $file->ph_path . '/' . $file->ph_name, ['target' => '_blank', 'style' => 'width: 50px;']);
                                else:
                                    echo \yii\bootstrap\Html::img('@web/' . $file->ph_path . '/' . $file->ph_name, ['style' => 'width: 50px;']);
                                endif;
                                ?>
                            </td>
                            <td class="name"><span><?= substr($file->ph_name, 0, 20) . '..' ?></span></td>
                            <td class="size" colspan="2"> 188 KB. </td>                    
                            <td class="delete" style="" ><button class="btn btn-danger btn-small remove-logo-file" data-fileID="<?= $file->ph_id ?>"><span>Delete</span></button>
                            </td>
                        </tr>
                        <?php
//                    endforeach;
                        ?>

                        <?php
                    endif;
                    ?>


                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$this->registerJs(" var u1 = new Upload({selector: '#testID', url: '/profile/company-logo',params: {aucID: ''} });  ", yii\web\View::POS_END, 'my-options');
?>