<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers;
use app\models\User;
use yii\helpers\ArrayHelper;
?>

<div class="col-lg-12 col-lg-12" style="margin-top: 20px;">
    <div class="col-md-4 col-sm-6 col-xs-12">       
        <div class="profile-photo" id="profile-photo">
            <div class="text-center">
                <?php
//                $avatar = Yii::$app->params['me']->photo;
//            app\components\Helper::pp($avatar);
                echo Html::img('@web/' . $model->photo->ph_path .'/'. $model->photo->ph_name, ['class' => 'avatar  img-thumbnail', 'style' => 'width:280px;']) ?>
                               
            </div>
            <div class="uploader">
<!--                <div class="progress">
                    <div class="progress-bar" role="progressbar" aria-valuenow="70"
                         aria-valuemin="0" aria-valuemax="100" style="width:70%">
                        <span class="sr-only">70% Complete</span>
                    </div>
                </div>-->
            </div>
            <div class="buttons">
                <button class="btn btn-success btn-xs" id="profile-photo-btn"><i class="mdi mdi-plus md-16"></i>Upload profile photo</button>
            </div>
        </div>

    </div>
    <?php // die(); ?>
    <div class="col-lg-8">
        <div class="panel panel-pro">
            <div class="panel-heading">Basic</div>
            <div class="panel-body">
                <?php
                $form = ActiveForm::begin([
//            'layout' => 'horizontal',
                            'id' => 'form_profile_basic',
                            'enableAjaxValidation' => true,
                            'validationUrl' => ['profile/validation'],
                            'fieldConfig' => [
                                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                                'horizontalCssClasses' => [
                                    'label' => 'col-sm-3',
                                    'offset' => 'col-sm-offset-4',
                                    'wrapper' => 'col-sm-9',
                                    'error' => '',
                                    'hint' => '',
                                ],
                            ],
                ]);

                $model->scenario = \app\models\Profile::SCENARTIO_BASIC_PROFILE_UPDATE;
                echo Html::activeHiddenInput($model, 'scenario');
                ?>
                <div class="row">
                    <div class="col-sm-4">
                        <?= $form->field($model, 'name')->textInput() ?>
                    </div>                    
                    <div class="col-sm-4"><?= $form->field($model, 'father_name')->textInput() ?></div>
                    <div class="col-sm-4"><?= $form->field($model, 'surname')->textInput() ?></div>
                </div>
                <div class="row">
                </div>
                <div class="row">
                </div>
                <!--<div class="col-sm-12">-->

                <div class="row">
                    <div class="col-sm-4">
                        <label class="control-label" for="profile-father_name">Gender</label> 
                        <?=
                        $form->field($model, 'gender', [
                            'inputOptions' => [
                                'class' => 'col-sm-12',
                            ],
                            'horizontalCssClasses' => [
                                'wrapper' => 'col-sm-12',
                            ]
                        ])->inline()->radioList([User::GENDER_MALE => 'Male', User::GENDER_FEMALE => 'Female'])->label(false)
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <?php  echo  $form->field($model, 'birthday')->textInput(['class' => 'datepicker form-control'])->label('Birthday ( dd/mm/yyyy)') ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12" id="pub123">
                        <button type="submit" class="btn btn-success">Save</button>                    

                    </div>
                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>
        <div class="panel panel-pro">
            <div class="panel-heading">Contact details</div>
            <div class="panel-body">
                <?php
                $form = ActiveForm::begin([
//            'layout' => 'horizontal',
                            'id' => 'form_contact_update',
                            'enableAjaxValidation' => true,
                            'validationUrl' => ['profile/validation'],
                            'fieldConfig' => [
                                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                                'horizontalCssClasses' => [
                                    'label' => 'col-sm-3',
                                    'offset' => 'col-sm-offset-4',
                                    'wrapper' => 'col-sm-9',
                                    'error' => '',
                                    'hint' => '',
                                ],
                            ],
                ]);
                $model->scenario = \app\models\Profile::SCENARTIO_CONTACT_UPDATE;
                echo Html::activeHiddenInput($model, 'scenario');
                ?>
                <div class="row" style="margin-bottom: 15px;">                  
                    <div class="col-sm-4"><?=
                        $form->field($model, 'mobile_code')->dropDownList(ArrayHelper::map(app\models\Country::find()->all(), 'mobile_code', function($model) {
                                    return '(+' . $model->mobile_code . ')' . $model->country_name;
                                }), ['class' => 'select2Input form-control'])
                        ?></div>
                    <div class="col-sm-6"><?= $form->field($model, 'mobile')->textInput(['class' => 'col-sm-5 form-control']) ?></div>
                </div>
                <div class="row" style="margin-bottom: 15px;">                  
                    <div class="col-sm-4"><?= $form->field($model, 'phone_code')->textInput(['class' => 'col-sm-1 form-control']) ?></div>
                    <div class="col-sm-6"><?= $form->field($model, 'phone')->textInput(['class' => 'col-sm-5 form-control']) ?></div>
                </div>
                <div class="row" style="margin-bottom: 15px;">                                      
                    <div class="col-sm-12"><?= $form->field($model, 'email')->textInput(['class' => 'col-sm-5 form-control']) ?></div>
                </div>
                <div class="row">
                    <div class="col-sm-12" id="pubc">
                        <button type="submit" class="btn btn-success">Save</button>                   
                    </div>
                </div>

                <?php ActiveForm::end(); ?>
            </div>

        </div>

        <div class="panel panel-pro">
            <div class="panel-heading">Address</div>
            <div class="panel-body">
                <?php
                $form = ActiveForm::begin([
//            'layout' => 'horizontal',
                            'id' => 'form_address_update',
//                            'enableAjaxValidation' => true,
//                            'validationUrl' => ['profile/validation'],
                            'fieldConfig' => [
                                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                                'horizontalCssClasses' => [
                                    'label' => 'col-sm-3',
                                    'offset' => 'col-sm-offset-4',
                                    'wrapper' => 'col-sm-9',
                                    'error' => '',
                                    'hint' => '',
                                ],
                            ],
                ]);
                $model->scenario = \app\models\Profile::SCENARTIO_ADDRESS_UPDATE;
                echo Html::activeHiddenInput($model, 'scenario');
                ?>
                <div class="row">
                    <div class="col-sm-4"><?= $form->field($model, 'block_no')->textInput() ?></div>
                    <div class="col-sm-4"><?= $form->field($model, 'street_locality')->textInput() ?></div>
                    <div class="col-sm-4"><?= $form->field($model, 'zip')->textInput() ?></div>
                </div>

                <div class="row">
                    <div class="col-sm-4"><?=
                        $form->field($model, 'country_id')->dropDownList(ArrayHelper::map(\app\models\Country::find()->all(), 'id', function($model) {
                                    return $model->country_name;
                                }), ['prompt' => 'Select Country', 'class' => 'select2Input'])
                        ?></div>
                    <div class="col-sm-4"><?= $form->field($model, 'city_id')->dropDownList(ArrayHelper::map(app\models\City::find()->all(), 'id', 'city_name'), ['prompt' => 'Select City']) ?></div>
                </div>
                <div class="row">
                    <div class="col-sm-12" id="puba">
                        <button type="submit" class="btn btn-success">Save</button>                    

                    </div>
                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>




    </div>
</div>



