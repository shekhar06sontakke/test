<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Coupon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="coupon-form">

    <?php
    $form = ActiveForm::begin([
                'layout' => 'horizontal',
                'fieldConfig' => [
                    'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                    'horizontalCssClasses' => [
                        'label' => 'col-sm-3',
                        'offset' => 'col-sm-offset-4',
                        'wrapper' => 'col-sm-9',
                        'error' => '',
                        'hint' => '',
                    ],
                ],
    ]);
    ?>

    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'cpn_code')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-sm-6">       
            <?= $form->field($model, 'cpn_discount')->textInput() ?>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 't_cpn_start_date')->textInput() ?>
        </div>
        <div class="col-sm-6">    
            <?= $form->field($model, 't_cpn_end_date')->textInput() ?>
        </div>
    </div>
     <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'cpn_desc')->textarea() ?>
        </div>        
    </div>


    <div class="row">
        <div class="col-sm-offset-2 col-sm-6">
            <div class="form-group">
                <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
