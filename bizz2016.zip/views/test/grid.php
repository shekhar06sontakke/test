<h2>Default Handsontable Demo</h2>

<div class="col-sm-12" style="margin-bottom: 10px;">
    <input type="text" placeholder="Row" id="inputGridRow">
    <input type="text" placeholder="Column" id="inputGridCol">
    <button class="btn btn-primary" id="btnGridInit" >OK</button>
</div>

<div class="col-sm-12">
    <div id="exampleGrid" class="dataTable"></div>
</div>