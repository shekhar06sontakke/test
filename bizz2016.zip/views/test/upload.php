

<div  class="da_upl_img">
    <div class="d1_inner">
        <div class="da_dupld_img"></div>
        <div class="d1_init">
            <i id="u2" class="d1_start mdi mdi-note-plus md-48" ></i>
        </div>
        <!--        <div class="dtpl">
                    <span class="info">Uploading...</span>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" ></div>
                    </div>
                </div>-->
        <div class="d1_viewfile">
            <a href="">
                <i id="u2" class="d1_start mdi mdi-checkbox-marked-circle md-24" ></i> View File
            </a>
        </div>
    </div>
</div>

<div  class="da_upl_img">
    <div class="d1_inner">
        <div class="da_dupld_img"></div>
        <div class="d1_init">
            <i id="u2" class="d1_start mdi mdi-note-plus md-48" ></i>
        </div>
                <div class="dtpl">
                    <span class="info">Uploading...</span>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" ></div>
                    </div>
                </div>
<!--        <div class="d1_viewfile">
            <a href="">
                <i id="u2" class="d1_start mdi mdi-checkbox-marked-circle md-24" ></i> View File
            </a>
        </div>-->
    </div>
</div>
