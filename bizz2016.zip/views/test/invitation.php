<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<tr>
    <td>
        <table width="100%" border="0" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;" >
            <tr>
                <td colspan="2" valign="top" bgcolor="#FFFFFF" style="padding:10px 20px; background:#ffffff;background-color:#ffffff;"><span style="color:#999999; font-size:8pt;">Sunday, 2 May 2010, Issue # 301</span><br>
                    <p style="padding:0; margin:0 0 11pt 0;line-height:160%; font-size:18px;"> Some letter from your company!</p>
                    <p style="padding:0; margin:11pt 0;line-height:160%; font-size:15px; font-style:italic;"> Another title goes here!</p>
                    Lorem ipsum dolor sit amet, Integer non purus enim, nec aliquam quam.
                    Fusce eget mauris id eros sollicitudin hendrerit in non justo. 
                    Mauris porta massa ut sem consectetur posuere. Aenean quam velit, 
                    laoreet quis dapibus at, vehicula ac urna. Aliquam erat volutpat.
                    Suspendisse eu mauris nulla. Praesent lobortis pulvinar ornare. 
                    Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
                    Aliquam erat volutpat.<br>
                    <br>
                    <strong>Etiam semper scelerisque odio, eu vestibulum leo tristique eget. Nunc quis eros vitae lectus laoreet pellentesque id ac lectus.</strong> <br>
                    <br>
                    <a style="text-decoration:none; color:#f26422;" href="http://gifky.com/LivePreview/FreshNewsletter/Orange-LightGrayBackground/10.html#"><img alt="»" height="7" src="https://www.meravivah.com/mv526257383/backend/web/images/logo.png" vspace="0" style="border:0;" width="12">&nbsp;More Information</a></td>
            </tr>
            <tr>
                <td colspan="2" valign="top" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><hr/></td>
            </tr>
            <tr>
                <td colspan="2" valign="top" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><h3 style="font-size: 18px;"
            </tr>
            <tr>
                <td width="21%" align="center" valign="middle" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><div style="display:inline-block; border:1px solid #CCB7B7;"><img src="../Downloads/Yash (1).jpg" width="118" height="124" alt=""/ ></div></td>
                <td width="79%" valign="top" bgcolor="#FFFFFF" style="padding:10px 20px; background:#ffffff;background-color:#ffffff;">
                    Name : <?php // $model->name  ?> <br/>
                    City :  <br/>
                    <?php ?>
                    Discription : <br/></td>
            </tr>
            <tr>
                <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><hr/></td>
            </tr>
            <tr>
                <td colspan="2" align="left" valign="middle" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><div style="font-size:18px;  margin:10px 10px; padding-left:10px; font-weight:bold; ">
                        File  : <a href="#" >Download Files </a></td>
            </tr>
            <tr>
                <td colspan="2" align="center" valign="middle" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><hr/></td>
            </tr>
            <tr>
                <td colspan="2" align="center" valign="middle" bgcolor="#FFFFFF" style=" background:#ffffff;background-color:#ffffff;"><a href="#" style="padding:10px 25px; display:inline-block; border:1px solid #DDD2D2; font-size: 22px;
                                                                                                                                          font-family: monospace !important; text-decoration:none; background:#27C30F; color:#FFF; margin:20px;" onMouseOver="this.style.background = '#18B900'" onMouseOut="this.style.background = '#27C30F'" >Place Your Bid</a></td>
            </tr>
        </table>
    </td>
</tr>
