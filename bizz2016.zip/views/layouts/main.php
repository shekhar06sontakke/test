<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use app\assets\VendorAsset;
use app\assets\HandsontableAsset;
use app\assets\DropzoneAsset;
use app\assets\Select2Asset;
use yii\helpers\Url;
use app\assets\BootstrapAsset;
use app\assets\TagsAsset;
use app\models\User;

//use app\assets\BarRatingAsset;

BootstrapAsset::register($this);
DropzoneAsset::register($this);
Select2Asset::register($this);
AppAsset::register($this);
TagsAsset::register($this);
app\assets\FancyBoxAsset::register($this);
app\assets\JqueryConfirmAsset::register($this);
app\assets\InputmaskAsset::register($this);
//BarRatingAsset::register($this);
//app\assets\RateitAsset::register($this);

HandsontableAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>
    <body>
        <?php $this->beginBody() ?>
        <?= Html::input('hidden', 'root', '', ['id' => 'root']) ?>
        <div class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <?= Html::a(\yii\bootstrap\Html::img('@web/images/logo2.png', ['class' => '']), ['site/index'], ['class' => 'navbar-brand']) ?>

                </div>
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav">
                        <li class="menu-item">
                            <?php
                            if (Yii::$app->user->isGuest) {
                                echo \yii\helpers\Html::a('Home', [ '/site/index'], ['class' => '']);
                            } else {
                                echo \yii\helpers\Html::a('Dashboard', [ '/myacc/dashboard'], ['class' => '']);
                            }
                            ?>
                        </li>
                        <?php
                        if (!Yii::$app->user->isGuest) {
                            ?>

                            <li class="menu-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Plan <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li class="menu-item"><a href="<?= Url::to(['/plan/index']) ?>" class="" >All</a></li>
                                    <li class="menu-item"><a href="<?= Url::to(['/plan/create']) ?>" class="" >New </a></li>
                                </ul>
                            </li>
                            <li class="menu-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Buyer <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li class="menu-item"><a href="<?= Url::to(['/buyer/index']) ?>" class="" >All</a></li>
                                    <li class="menu-item"><a href="<?= Url::to(['/profile/create']) ?>" class="" >New </a></li>
                                </ul>
                            </li>
                            <li class="menu-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Seller <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li class="menu-item"><a href="<?= Url::to(['/seller/index']) ?>" class="" >All</a></li>
                                    <li class="menu-item"><a href="<?= Url::to(['/profile/create']) ?>" class="" >New </a></li>
                                    <li class="menu-item"><a href="<?= Url::to(['/upgrade-history/index']) ?>" class="" >Upgrade History</a></li>
                                </ul>
                            </li>
                            <li class="menu-item">
                                <?= \yii\helpers\Html::a('Page', [ '/page/index'], ['class' => '']) ?>
                            </li>
                            <li class="menu-item">
                                <?= \yii\helpers\Html::a('Advertisement', [ '/admgmt/index'], ['class' => '']) ?>
                            </li>
                            <li class="menu-item">
                                <?= \yii\helpers\Html::a('News', [ '/news/index'], ['class' => '']) ?>
                            </li>

                            <?php
                        }
                        ?>

                        <!--<ul class="nav navbar-nav">-->
                        <li class="menu-item">
                            <?= \yii\helpers\Html::a('Contact', [ '/site/contact'], ['class' => '']) ?>
                        </li>

                        <!--</ul>-->

                    </ul>

                    <ul id="signInDropdown" class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle defoult-img" data-toggle="dropdown"> <?= \yii\bootstrap\Html::img('@web/images/unknown.png', ['class' => '']); ?>
                                <b class="caret"></b></a>
                            <ul class="dropdown-menu profile-sub-menu">
                                <?php
                                if (!yii::$app->user->isGuest):
                                    ?>                                    
                                    <li>
                                        <?php
                                        echo Html::beginForm(['/site/logout'], 'post');
                                        echo Html::submitButton(
                                                '<i id="u2" class="d1_start mdi mdi-logout md-24"></i> Logout (' . Yii::$app->user->identity->username . ')', ['class' => '']
                                        );
                                        echo Html::endForm();
                                        ?>
                                    </li>

                                    <?php
                                else:
                                    ?>                                    
                                    <li><a href="<?= Url::to(['site/login']) ?>"><i id="" class="d1_start mdi mdi-login md-24"></i> Login</a></li>

                                <?php
                                endif;
                                ?>                               
                            </ul>
                        </li>

                    </ul>

                    <?php
                    if (!yii::$app->user->isGuest):
                        ?>
                        <ul class="nav navbar-top-links navbar-nav navbar-right">

<!--                            <li >
                                <a href="#" title="LinkedIn" rel="nofollow" >
                                    <i id="u2" class="d1_start mdi mdi-comment-processing-outline md-24"></i>
                                </a>
                            </li>-->
                            <?php
                            if (Yii::$app->user->identity->account_type == app\models\User::USER_TYPE_SELLER):

//                                \app\components\Helper::pp($invitations);
                                ?>

                                <li class="dropdown">
                                    <?php
                                    $invitations = \app\models\Invitation::find()->where(['sl_id' => Yii::$app->params['me']->seller->sl_id])->orderBy('updated_at DESC')->all();
                                    $cnt = count($invitations);
                                    ?>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"  >
                                        <i id="u2" class="d1_start mdi mdi-email md-24"></i>

                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <ul class=" dropdown-messages">

                                                <?php
                                                $loop = 1;
                                                foreach ($invitations as $invitation):
                                                    ?>
                                                    <li>                                                        
                                                        <div>
                                                            <strong><?= Html::a($invitation->auction->buyer->profile->username, ['buyer/profile'], ['class' => 'seller-link']) ?></strong>
                                                            <span class="pull-right text-muted">
                                                                <em><?= Yii::$app->formatter->asDatetime($invitation->updated_at) ?></em>
                                                            </span>
                                                        </div>
                                                        <div><?= strlen($invitation->auction->auc_title) > 128 ? substr($invitation->auction->auc_title, 0, 128) . '...' : $invitation->auction->auc_title ?></div>
                                                        <div>
                                                            <?= Html::a($invitation->auction->category->cat_name, [''], ['class' => 'auction-category']) ?>
                                                            <?= Html::a('View Bid', ['auction/index', 'cat' => $invitation->auction->category->cat_slug, 'slug' => $invitation->auction->auc_slug], ['class' => 'btn btn-primary btn-xs pull-right auction-link']) ?>
                                                        </div>
                                                    </li>


                                                    <?php
//                                                        echo $cnt;
                                                    echo $cnt == $loop ? '' : '<li class="divider"></li>';
                                                    ++$loop;
                                                endforeach;
                                                ?>
                                            </ul>
                                        </li>

                                        <li class="divider"></li>
                                        <li>
                                            <?= Html::a('<strong>Read All Invitations</strong><i class="fa fa-angle-right"></i>', ['myacc/notification'], ['class' => 'text-center']) ?>                                            
                                        </li>

                                    </ul>


                                </li>
                                <?php
                            endif;
                            ?>

<!--                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"  >
                                    <i id="u2" class="d1_start mdi mdi mdi-bell-outline md-24"></i>
                                </a>

                            </li>-->

                        </ul>
                        <?php
                    endif;
                    ?>

                    <!-- DROPDOWN LOGIN STARTS HERE  -->
                    <!-- DROPDOWN LOGIN ENDS HERE  -->
                </div>
            </div>
        </div>


        <div class="container" id="main-container" style="margin-top: 70px;">
            <?php
            foreach (Yii::$app->session->getAllFlashes() as $key => $message) {
                echo '<div class="alert alert-' . $key . '">' . $message . '</div>';
            }
            ?>
            <?=
            Breadcrumbs::widget([
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ])
            ?>
            <?= $content ?>
            <!--</div>-->
        </div>

        <footer class="footer">
            <div class="container">
                <p class="pull-left">&copy; Bizzjunction.com <?= date('Y') ?></p>

                <p class="pull-right"><?= Yii::powered() ?></p>
            </div>
        </footer>

        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
