<?php

use yii\widgets\ListView;

?>
<div class="col-sm-9">
    
    
<?=

ListView::widget([
    'dataProvider' => $listDataProvider,
    'options' => [
        'tag' => 'div',
        'class' => 'list-wrapper',
        'id' => 'list-wrapper',
    ],
    'layout' => "{pager}\n{items}\n{summary}",
    'itemView' => function ($model, $key, $index, $widget) {
return $this->render('partials/_list_item', ['model' => $model]);
},
    'itemOptions' => [
        'tag' => false,
    ],
    'pager' => [
        'firstPageLabel' => 'first',
        'lastPageLabel' => 'last',
        'nextPageLabel' => 'next',
        'prevPageLabel' => 'previous',
        'maxButtonCount' => 3,
    ],
]);
?>
</div>


<?php

app\assets\FontAwesomeAsset::register($this);

echo $this->registerJsFile('@web/js/listing.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset', '\app\assets\RateitAsset']]) ;
