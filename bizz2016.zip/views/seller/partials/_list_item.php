<?php

// _list_item.php
use yii\helpers\Html;
use yii\helpers\Url;
?>
<?php ?>
<article class="info-list" data-key="<?= $model->sl_id; ?>" >
    <figure class="info-list-img">
        <?php
        $photo = $model->seller->profile->photo;
//        \app\components\Helper::pp(); 
        ?>
        <?= Html::img('@web/' . $photo->ph_path . '/' . $photo->ph_name) ?>
    </figure>
    <div class="info-list-inner">
        <div class="info-list-title"><?= $model->seller->profile->username ?></div>
        <div class="info-list-description"><?= substr($model->seller->sl_company_description, 0, 210) . '...' ?></div>
        <div class="info-list-details">
            <span>
                <label class="rating-count"><?= $model->seller->getRating() ?></label>
                <?php
                $oldRating = $model->seller->getBuyerOldRating();
//                \app\components\Helper::pv();

//                echo Html::dropDownList('', $oldRating, array_combine(range(1, 5), range(1, 5)), ['class' => 'seller-rating', 'data-slid' => $model->sl_id, 'prompt' => '']);
                
                ?>
                <span class="seller-rating" data-slid="<?= $model->sl_id ?>" data-rateit-value="<?= $oldRating ?>"></span>
            </span>
        </div>
        <div class="info-list-categories">
            <ul class="list">
                <?php
                $categories = $model->seller->categories;
                foreach ($categories as $category) :
                    echo Html::tag('li', Html::a($category->category->cat_name, ['seller/listing', 'cat' => $category->category->cat_slug]), []);
                endforeach;
                ?>
            </ul>
        </div>
    </div>

</article>