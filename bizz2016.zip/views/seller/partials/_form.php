<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\components\OptionList;

//use Yii;

/* @var $this yii\web\View */
/* @var $model app\models\Buyer */
/* @var $form ActiveForm */
?>
<div class="container text-center">
    <br/>
    <div class="row">
        <div class="col-md-3 col-xs-3 col-md-offset-1 step-bar offset-margin text-center">
            <span class="step-checked"><i id="u2" class="d1_start mdi mdi-check md-24"></i></span>
            <div class="profile-step text-center"></div>
        </div>
        <div class="col-md-3 col-xs-3 step-bar text-center">
            <span class="step-checked"><i id="u2" class="d1_start mdi mdi-check md-24"></i></span>
            <div class="profile-step text-center"></div>
        </div>
        <!--     <div class="col-md-3 col-xs-4 text-center">
                <span class="step-checked"><i id="u2" class="d1_start mdi mdi-check md-24"></i></span>
                <div class="profile-step text-center"></div>
            </div>-->
        <div class="col-md-3 col-xs-3 text-center">
            <span class="step-unchecked">3</span>
            <div class="profile-step-unchecked text-center"></div>
        </div>
    </div>
</div>
<br/><br/>

<div class="clear"></div>


<?php $form = ActiveForm::begin(); ?>
<div class="profile-partials-seller">
    <div class="col-lg-12 col-lg-12">
        <div class="col-md-4 col-sm-6 col-xs-12">
            <h5>Profile Picture</h5>

            <div class="text-center">
                <img src="http://lorempixel.com/200/200/people/9/" class="avatar  img-thumbnail" alt="avatar">
                <h6>Upload a different photo...</h6>
                <input type="file" class="text-center center-block well well-sm">
            </div>


        </div>
        <div class="col-lg-8">

            <div class="col-lg-12"> <?= $form->field($model, 'sl_company_start_year') ?></div>
            <div class="col-lg-12"> <?= $form->field($model, 'sl_company_nature')->dropDownList(OptionList::get_nature_of_company(), ['prompt' => 'Select']) ?></div>
            <div class="col-lg-12"> <?= $form->field($model, 'sl_industry_category')->dropDownList(OptionList::get_category_of_industry(), ['prompt' => 'Select']) ?></div>
            <div class="col-lg-12"> <?= $form->field($model, 'sl_industry_category_text')->textArea(['rows' => '2']) ?></div>
            <div class="col-lg-12"> <?= $form->field($model, 'sl_business_nature')->dropDownList(OptionList::get_nature_of_business(), ['prompt' => 'Select']) ?></div>
        </div>


    </div>   


    <div class="col-lg-6"> <?= $form->field($model, 'sl_business_nature_text')->textArea(['rows' => '2']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_current_product_service_details')->textArea(['rows' => '3']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_banker_name') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_banker_account_type')->dropDownList(OptionList::get_bank_account_type(), ['prompt' => 'Select']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_ifsc_code') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_micr_code') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_banker_city') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_account_no') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_tan_no') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_vern') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_vtrn') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_atly') ?></div>       
    <div class="col-lg-6"> <?= $form->field($model, 'sl_sister_concern_subsidiary')->textArea(['rows' => '3']) ?></div>       
    <div class="col-lg-6"> <?= $form->field($model, 'sl_change_in_firm_name')->textArea(['rows' => '3']) ?></div>       
    <div class="col-lg-12"> <?= $form->field($model, 'sl_company_description')->textArea(['rows' => '3']) ?></div>       
    <div class="col-lg-6"> </div>       
    <div class="col-lg-6"> 

    </div>       


    <div class="col-lg-6">
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    </div>       

    <?php ActiveForm::end(); ?>

</div><!-- profile-partials-buyer -->
