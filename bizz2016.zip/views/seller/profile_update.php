<h1>Company Details </h1>
<h4>Please Complete these 3 Steps before bibbing on the project</h4>

<?php


echo $this->render("_form",['model'=>$model]);
//echo $this->render("_form1",['model'=>$model]);

?>


