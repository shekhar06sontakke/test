<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SellerSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
?>
<div class="link-display-panel">
    <?php
    $this->title = 'Sellers';
    $this->params['breadcrumbs'][] = $this->title;
    ?>
</div>
<div class="seller-index">

    <h2><?= Html::encode($this->title) ?>
        <?= Html::a('Create Seller', ['profile/create'], ['class' => 'btn btn-success pull-right']) ?>
    </h2>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?php echo $this->render('_search', ['model' => $searchModel]); ?>
        </div>
        <div class="col-sm-9">
            <div class="panel panel-pro">
                <div class="panel-body">
                    <?=
                    GridView::widget([
                        'dataProvider' => $dataProvider,
//                        'filterModel' => $searchModel,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],
//                            'sl_id',
//                            'id',
                            [
                                'attribute' => 'username',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->username;
                                },
                            ],
                            [
                                'attribute' => 'Full name',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->name . ' '.$model->profile->father_name.' '.  $model->profile->surname;
                                },
                            ],
                            [
                                'attribute' => 'email',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->email;
                                },
                            ],
                            [
                                'attribute' => 'mobile',
                                'format' => 'raw',
                                'value' => function($model) {
                                    return $model->profile->mobile;
                                },
                            ],
//                            'ph_id',
                            'sl_company_name',
                            [
                                'class' => 'yii\grid\ActionColumn',
                                'template' => '{view} {upgrade}',
                                'buttons' => [
                                    'view' => function($url, $model) {
                                        return Html::a('<i class="mdi mdi-pencil-box md-18"></i>', ['profile/basic','id'=> $model->profile->id], ['data-sellerid' => $model->sl_id, 'class' => '','target'=>'_blank']);
                                    },
                                    'update' => function($url, $model) {
                                        return Html::a('<i class="mdi mdi-star-outline md-18"></i>', ['profile/'], ['data-sellerid' => $model->sl_id, 'class' => '','title'=>'Update']);
                                    },
                                    'upgrade' => function($url, $model) {
                                        return Html::a('<i class="mdi mdi-star-outline md-18"></i>', '#', ['data-sellerid' => $model->sl_id, 'class' => 'slupgrade-btn','title'=>'Upgrade']);
                                    }
                                        ]
                                    ],
                                ],
                            ]);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        echo $this->registerJsFile('@web/js/seller_index.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset', '\app\assets\RateitAsset']]);
        ?>