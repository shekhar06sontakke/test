<?php

use yii\helpers\Url;

//\app\components\Helper::pp($model);

?>

<h2>Browse all Cetegories </h2>

<?php foreach ($model as $mod) :?>
    <div class=" col-lg-12 col-xs-12 cat-padding">
        <hr/>
        <h3 class="">
            <?= $mod->caty_name ?> <span class=""></span>
        </h4>
        <hr/>
   

    <div class="sub-cat-list">
        <ul class="list-group">
            <?php
            foreach ($mod->categories as $category):
                ?>
                <li class="col-md-4"><i id="u2" class="d1_start mdi mdi-menu-right md-24"></i>
                    <?= \yii\helpers\Html::a($category->cat_name, [ 'seller/listing', 'cat' => $category->cat_slug], ['class' => '']) ?>
                </li>

                <?php
            endforeach;
            ?>
        </ul>
        
    </div>
    <hr/>
 </div>
    <?php
endforeach;
?>



