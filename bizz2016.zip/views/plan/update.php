<?php

use yii\bootstrap\ActiveForm;
use app\components\Tab;
?>
<div class="panel">
    <div class="panel-body">


        <!-- Nav tabs -->
        <?php
        $tab = new Tab('tab_general');
        ?>
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="<?= $tab->is_active('tab_general') ?>"><a href="#tab_general" aria-controls="tab_general" role="tab" data-toggle="tab">General Information</a></li>
            <li role="presentation" class="<?= $tab->is_active('tab_pricing') ?>"><a href="#tab_pricing" aria-controls="tab_pricing" role="tab" data-toggle="tab">Duration and Pricing</a></li>        
            <li role="presentation" class="<?= $tab->is_active('tab_reward') ?>"><a href="#tab_reward" aria-controls="tab_reward" role="tab" data-toggle="tab">Rewards</a></li>        
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane <?= $tab->is_active('tab_general') ?>" id="tab_general">
                <?= $this->render('partials/_form_plan', ['model' => $model]) ?>
            </div>
            <div role="tabpanel" class="tab-pane <?= $tab->is_active('tab_pricing') ?>" id="tab_pricing">
                <?= $this->render('partials/_form_pricing', ['model' => $model]) ?>
            </div>
            <div role="tabpanel" class="tab-pane <?= $tab->is_active('tab_reward') ?>" id="tab_reward">
                <?= $this->render('partials/_reward_form', ['model' => $reward]) ?>
            </div>        
        </div>
    </div>

</div>