<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Plan */

$this->title = 'Create Plan';
$this->params['breadcrumbs'][] = ['label' => 'Plans', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-sm-6">       
        <div class="panel panel-pro">
            <div class="panel-heading">
            <?= Html::encode($this->title) ?>
            </div>
            <div class="panel-body">
                <?=
                $this->render('partials/_form_plan', [
                    'model' => $model,
                ])
                ?>
            </div>
        </div>


    </div>
</div>