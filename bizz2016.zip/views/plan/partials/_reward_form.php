<?php

use yii\bootstrap\ActiveForm;
?>

<?php $form = ActiveForm::begin(); ?>
<table class="table table-bordered" >
    <tr>
        <td  rowspan="7"  scope="col">Company Information</td>
        <td  scope="col">Name (Font-weight)</td>
        <td  scope="col">
            <?= $form->field($model, 'CINFWT')->inline(true)->dropDownList(['normal' => 'Normal', 'bold' => 'Bold'], ['prompt' => 'Select'])->label(false) ?>            
        </td>
    </tr>
    <tr>
        <td scope="col">Name (Color)</td>
        <td scope="col">
            <?= $form->field($model, 'CINFCL')->inline(true)->dropDownList(['yellow' => 'Yellow', 'black' => 'Black'], ['prompt' => 'Select'])->label(false) ?>                                
        </td>
    </tr>
    <tr>
        <td scope="col">Contact Person</td>
        <td scope="col">
            <?= $form->field($model, 'CICPER')->inline(true)->radioList(['10' => 'Show', '0' => 'Hide'])->label(false) ?>
        </td>
    </tr>
    <tr>
        <td scope="col">Email</td>
        <td scope="col">
            <?= $form->field($model, 'CIEMIL')->inline(true)->radioList(['10' => 'Show', '0' => 'Hide'])->label(false) ?>
        </td>
    </tr>
    <tr>
        <td scope="col">Phone</td>
        <td scope="col">
            <?= $form->field($model, 'CIPHNE')->inline(true)->radioList(['10' => 'Show', '0' => 'Hide'])->label(false) ?>
        </td>
    </tr>
    <tr>
        <td scope="col">Logo</td>
        <td scope="col">
            <?= $form->field($model, 'CILOGO')->inline(true)->radioList(['10' => 'Show', '0' => 'Hide'])->label(false) ?>
        </td>
    </tr>
    <tr>
        <td scope="col">Short description (Char. limit)</td>
        <td scope="col">
            <?= $form->field($model, 'CISDCL')->textInput()->label(false) ?>
        </td>
    </tr>
    <tr>
        <td  rowspan="2"  scope="col">Custom Advertisement</td>
        <td  scope="col">Size</td>
        <td  scope="col">
            <?= $form->field($model, 'CADSZE')->textInput()->label(false) ?>
        </td>
    </tr>
    <tr>
        <td scope="col">Scope</td>
        <td scope="col">
            <?= $form->field($model, 'CADSCP')->dropDownList(['front_page' => 'Front Page', 'sidebar' => 'Sidebar','none'=>'None'], ['prompt' => 'Select'])->label(false) ?>
        </td>
    </tr>                       

    <tr>
        <td>Backlink</td>
        <td>&nbsp;</td>
        <td>
            <?= $form->field($model, 'BCKLNK')->inline(true)->radioList(['10' => 'Show', '0' => 'Hide'])->label(false) ?>
        </td>
    </tr>
    <tr>
        <td>Category limit</td>
        <td>&nbsp;</td>
        <td>
            <?= $form->field($model, 'CATLIM')->textInput()->label(false) ?>
        </td>
    </tr>
    <tr>
        <td>Bid Limit</td>
        <td>&nbsp;</td>
        <td>
            <?= $form->field($model, 'BIDLIM')->textInput()->label(false) ?>
        </td>
    </tr>                       
    <tr>
        <td></td>
        <td></td>
        <td>
            <?= \yii\helpers\Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
        </td>
    </tr>                       
</table>
<?php ActiveForm::end(); ?>