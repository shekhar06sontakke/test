<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\components\OptionList;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\Plan */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="plan-form">

    <?php
    foreach (app\components\OptionList::get_plan_durations() as $key => $val) {
        $modeldata = \app\models\PlanDuration::find()->where(['pln_id' => $model->pln_id, 'pld_duration' => $key])->one();

//        app\components\Helper::pv($key); 
//        app\components\Helper::pv($val); 
//        app\components\Helper::pv($modeldata); 
//        app\components\Helper::pv($duration); 
        if (!isset($modeldata->pld_id)) {
            $modeldata = new \app\models\PlanDuration();
            $modeldata->pln_id = $model->pln_id;
            $modeldata->pld_duration = $key;
        }
        ?>
        <div class="row">
            <div class="col-sm-4">

                <?php $form = ActiveForm::begin(['action' => ['update-duration', 'id' => $modeldata->pld_id, 'tab' => isset($_GET['tab']) ? $_GET['tab'] : '']]); ?>
                <?= Html::activeHiddenInput($modeldata, 'pln_id') ?>
                <div class="row">

                    <div class="col-sm-4">

                        <?= $form->field($modeldata, 'pld_duration')->dropDownList(OptionList::get_plan_durations(), ['prompt' => 'Select']) ?>
                    </div>
                    <div class="col-sm-4">
                        <?= $form->field($modeldata, 'pld_currency')->dropDownList(ArrayHelper::map(\app\models\Country::find()->all(), 'currency', 'currency'), ['prompt' => 'Select']) ?>
                    </div>
                    <div class="col-sm-4">
                        <?= $form->field($modeldata, 'pld_price') ?>       
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                        </div>
                        <hr>
                    </div>
                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>

        <?php
    }
    ?>

</div>

<?= $this->registerJsFile('@web/js/plan_duration.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>