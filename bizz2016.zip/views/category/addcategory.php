<?php

use yii\bootstrap\ActiveForm;
use app\models\CategoryType;
use app\models\Category;
use yii\helpers\Html;
use yii\helpers;
use yii\helpers\ArrayHelper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div class="row">
    <div class="panel panel-pro">
        <div class="panel-heading">Add Category Types</div>
        <div class="panel-body">
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <div class="control-label col-sm-3">Choose</div>
                        <div class="col-sm-9">
                            <select id="addCategory" class="form-control">
                                <option value="">Select</option> 
                                <option value="cat">Category</option> 
                                <option value="caty">Category Type</option> 
                            </select>
                        </div>
                    </div>
                </div>
            </div>


            <div class="clearfix"></div>
            <?php
            $formct = ActiveForm::begin([
                        'layout' => 'horizontal',
                        'id' => 'form_addcattype',
//                        'enableAjaxValidation' => true,
//                        'validationUrl' => ['profile/validation'],
                        'fieldConfig' => [
                            'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                            'horizontalCssClasses' => [
                                'label' => 'col-sm-4',
                                'offset' => 'col-sm-offset-4',
                                'wrapper' => 'col-sm-8',
                                'error' => '',
                                'hint' => '',
                            ],
                        ],
            ]);
            ?>

            <div class="row">
                <div class="col-sm-7">
                    <?= $formct->field($modelct, 'caty_name')->textInput() ?>
                </div>
            </div>

            <div class="row">                 
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

        <?php ActiveForm::end(); ?>

        <?php
        $form = ActiveForm::begin([
                    'layout' => 'horizontal',
                    'id' => 'form_addcat',
//                        'enableAjaxValidation' => true,
//                        'validationUrl' => ['profile/validation'],
                    'fieldConfig' => [
                        'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                        'horizontalCssClasses' => [
                            'label' => 'col-sm-3',
                            'offset' => 'col-sm-offset-4',
                            'wrapper' => 'col-sm-6',
                            'error' => '',
                            'hint' => '',
                        ],
                    ],
        ]);
        ?>
        <div class="row">
            <?=
            $form->field($model, 'caty_id')->dropDownList(ArrayHelper::map(app\models\CategoryType::find()->all(), 'caty_id', function($model) {
                        return '' . $model->caty_name;
                    }), ['class' => 'select2Input form-control'])
            ?>
        </div>

        <div class="row">
            <div class="col-sm-6"> 
                <?= $form->field($model, 'cat_name')->textInput() ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6"> 
                <?= $form->field($model, 'cat_slug')->textInput() ?>
            </div>
        </div>

        <div class="row"> 
            <div class="col-sm-offset-2 col-sm-9" style="padding-left: 4%;">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
        <?php ActiveForm::end(); ?>

    </div>
</div>

</div>


<?= $this->registerJsFile('@web/js/category.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>