<?= $this->render('partials/_menu') ?>

<?= $this->render('partials/_basic', ['model' => $model]) ?>



<?= $this->registerJsFile("@web/js/profile.js", ['depends' => ['\app\assets\Select2Asset', '\app\assets\DropzoneAsset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\HandsontableAsset', '\app\assets\JqueryConfirmAsset']]) ?>
<?php
$this->registerJs(" var cpp = new profilePhoto({userid: '" . $model->id . "'}); ", yii\web\View::POS_END, 'my-options');
?>