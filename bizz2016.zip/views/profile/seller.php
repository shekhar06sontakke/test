<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Buyer */
/* @var $form ActiveForm */
?>
<div class="profile-partials-seller">

    <?php $form = ActiveForm::begin(); ?>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_company_start_year')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6">  <?= $form->field($model, 'sl_company_nature')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_industry_category')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_industry_category_text')?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_business_nature')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_current_product_service_details') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_business_nature_text')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6"><?= $form->field($model, 'sl_banker_name') ?></div>
    <div class="col-lg-6"><?= $form->field($model, 'sl_banker_account_type')->dropDownList(['prompt'=>'']) ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_ifsc_code') ?></div>
    <div class="col-lg-6">  <?= $form->field($model, 'sl_micr_code') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_banker_city') ?></div>
    <div class="col-lg-6"><?= $form->field($model, 'sl_account_no') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_tan_no') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_vern') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_vtrn') ?></div>
    <div class="col-lg-6"> <?= $form->field($model, 'sl_atly') ?></div>       
    <div class="col-lg-6"><?= $form->field($model, 'sl_sister_concern_subsidiary')->dropDownList(['prompt'=>'Select','1'=>'Yes','0'=>'No']) ?></div>       
    <div class="col-lg-6"> <?= $form->field($model, 'sl_change_in_firm_name')->dropDownList(['prompt'=>'Select','1'=>'Yes','0'=>'No']) ?></div>       
    <div class="col-lg-12"> <?= $form->field($model, 'sl_company_description')->textArea(['rows' => '6']) ?></div>       
    <div class="col-lg-6"> </div>       
    <div class="col-lg-6"> 
       
    </div>       
    
    
    <div class="col-lg-6">
         <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    </div>       
       
    <?php ActiveForm::end(); ?>

</div><!-- profile-partials-buyer -->
