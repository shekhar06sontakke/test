<?php
$this->title = "Update Your company profile.";

//app\components\Helper::pp($model);
//die();
//app\components\Helper::pp($model);
?>
<?= $this->render('partials/_menu') ?>

<div class="col-sm-8">
    
<?php
if ($model->profile->account_type == \app\models\User::USER_TYPE_BUYER) {
    echo $this->render('partials/_buyer', ['model' => $model]);
} elseif ($model->profile->account_type == \app\models\User::USER_TYPE_SELLER) { 
    
    echo $this->render('partials/_seller', ['model' => $model]);
}
?>
</div>

<?= $this->registerJsFile('@web/js/company.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset']]) ?>