<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use app\models\User;
use yii\helpers\ArrayHelper;
use app\models\Country;

$this->title = 'Create User';
$this->params['breadcrumbs'][] = $this->title;
//app\components\Helper::pp($model);
?>
<div class="site-signup">
            <h1><?= Html::encode($this->title) ?></h1>            
    <div class="panel panel-pro">
<!--        <div class="panel-heading">
        </div>-->
        <div class="panel-body">
            <p>Please fill out the following fields to Create User:</p>
            <hr>
            <div class="row">
                <div class="col-lg-5">
                    <?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>
                    <?= $form->field($model, 'email')->textInput(['placeholder' => 'Provide your email.']) ?>
                    <?= $form->field($model, 'username')->textInput(['placeholder' => 'Provide your username.']) ?>
                    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Provide your password.']) ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <label class="control-label" for="signupform-password">Mobile</label>  
                        </div>
                        <div class="col-sm-5">
                            <?=
                            $form->field($model, 'mobile_code')->label(false)->dropDownList(ArrayHelper::map(Country::find()->orderBy(['mobile_code' => SORT_ASC])->all(), 'mobile_code', function($model) {
                                        return '( +' . $model->mobile_code . ') ' . $model->country_name;
                                    }), ['prompt' => 'Country Code', 'class' => 'form-control select2Input'])
                            ?>
                        </div>
                        <div class="col-sm-6">
                            <?= $form->field($model, 'mobile')->textInput(['placeholder' => 'Provide your mobile.'])->label(false) ?>
                        </div>

                    </div>
                    <div class="row">

                        <?=
                        $form->field($model, 'account_type', [
                            'inputOptions' => [
                                'class' => 'col-sm-12',
                            ],
                            'horizontalCssClasses' => [
                                'wrapper' => 'col-sm-12',
                            ]
                        ])->inline()->radioList([User::USER_TYPE_BUYER => 'Buyer', User::USER_TYPE_SELLER => 'Seller'])->label(false)
                        ?>
                    </div>


                    <div class="form-group">
                        <?= Html::submitButton('Create', ['class' => 'btn btn-primary', 'name' => 'signup-button']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>

    </div>


</div>