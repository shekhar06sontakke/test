<div class="row">
    <nav class="navbar navbar-default">
        <div class="container-fluid">    
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">         
                    <li  class="<?= Yii::$app->controller->action->id == 'basic' ? 'active' : '' ?>">
                        <?= yii\helpers\Html::a('Basic', ['profile/basic', 'id' => $_GET['id']]) ?>            
                    </li>
                    <li class="<?= Yii::$app->controller->action->id == 'company' ? 'active' : '' ?>">
                        <?= yii\helpers\Html::a('Company <span class="sr-only"></span>', ['profile/company', 'id' => $_GET['id']]) ?>            
                    </li>   
                    <?php
                    if (Yii::$app->user->identity->account_type == \app\models\User::USER_TYPE_SELLER):
                        ?>
                        <li class="<?= Yii::$app->controller->action->id == 'choose-category' ? 'active' : '' ?>">
                            <?= yii\helpers\Html::a('Choose Category <span class="sr-only"></span>', ['profile/choose-category','id' => $_GET['id']]) ?>            
                        </li>        

                        <?php
                    endif;
                    ?>
                </ul>

            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>

</div>