<?php

use yii\bootstrap\ActiveForm;

$form = ActiveForm::begin([
//            'layout' => 'horizontal',
            'id' => '',
//            'enableAjaxValidation' => true,
//            'validationUrl' => ['profile/validation'],
            'fieldConfig' => [
                'template' => "{label}\n{beginWrapper}\n{input}\n{hint}\n{error}\n{endWrapper}",
                'horizontalCssClasses' => [
                    'label' => 'col-sm-3',
                    'offset' => 'col-sm-offset-4',
                    'wrapper' => 'col-sm-9',
                    'error' => '',
                    'hint' => '',
                ],
            ],
        ]);

//$model->scenario = \app\models\Profile::SCENARTIO_BASIC_PROFILE_UPDATE;
//echo Html::activeHiddenInput($model, 'scenario');
?>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'by_company_name')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6">
        <?= $form->field($model, 'by_industry_type')->textInput() ?>
    </div>                   
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'by_designation')->textInput() ?></div>
</div>
<div class="row">
    <div class="col-sm-6"><?= $form->field($model, 'by_company_description')->textarea(['rows'=>4]) ?></div>
</div>
<div class="row">
</div>

<div class="row">
    <div class="col-sm-12" >
        <button type="submit" class="btn btn-success">Save</button>                    

    </div>
</div>

<?php ActiveForm::end(); ?>

