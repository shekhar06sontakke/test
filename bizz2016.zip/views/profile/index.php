<?php
/* @var $this yii\web\View */
$this->title = "";
?>
<?= $this->render('partials/_menu') ?>

<?= $this->render('partials/_basic',['model'=>$model]) ?>


<?= $this->registerJsFile('@web/js/profile.js', ['depends' => ['\app\assets\Select2Asset', '\app\assets\TagsAsset', '\app\assets\AppAsset', '\app\assets\DropzoneAsset','app\assets\InputmaskAsset']]) ?>
