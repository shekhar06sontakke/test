<?php

use kartik\export\ExportMenu;
use kartik\grid\GridView;

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
    'upgh_id',
    'upgh_currency',
    'upgh_amount',
    'upgh_pay_method',    
    ['class' => 'yii\grid\ActionColumn'],
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);

// You can choose to render your own GridView separately
echo \kartik\grid\GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns
]);
