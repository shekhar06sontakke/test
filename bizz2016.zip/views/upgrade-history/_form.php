<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\UpgradeHistory */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="upgrade-history-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id')->textInput() ?>

    <?= $form->field($model, 'pln_id')->textInput() ?>

    <?= $form->field($model, 'pld_duration')->textInput() ?>

    <?= $form->field($model, 'upgh_currency')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'upgh_amount')->textInput() ?>

    <?= $form->field($model, 'upgh_pay_method')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
