<?php

use yii\helpers\Html;
use kartik\export\ExportMenu;
use kartik\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UpgradeHistorySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Upgrade Histories';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="upgrade-history-index">
    <div class="panel panel-pro">
        <div class="panel-heading">
            <?= Html::encode($this->title) ?>
        </div>
        <div class="panel-body">

            <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>

            <p>
                <?php // Html::a('Create Upgrade History', ['create'], ['class' => 'btn btn-success'])  ?>
            </p>

            <?php
            $gridColumns = [
                ['class' => 'yii\grid\SerialColumn'],
//            'upgh_id',
                [
                    'attribute' => 'id',
                    'format' => 'raw',
                    'value' => function($model) {
                        return $model->user->name . ' ' . $model->user->surname . ' (' . $model->user->id . ')';
                    },
                ],
//            'id',
//            'pln_id',
//            'pld_duration',
//            'upgh_currency',
                [
                    'attribute' => 'upgh_amount',
                    'format' => 'raw',
                    'value' => function($model) {
                        return $model->upgh_currency . ' ' . $model->upgh_amount;
                    },
                ],
//                    'upgh_amount',
                'upgh_pay_method',
                // 'upgh_txnid',
// 'created_by',
// 'updated_by',
                [
                    'attribute' => 'created_at',
                    'format' => 'raw',
                    'value' => function($model) {
                        return app\components\Helper::_date($model->created_at, 'd-M-Y H:i');
                    },
                ],
//            'created_at',
// 'updated_at',
                ['class' => 'yii\grid\ActionColumn', 'template' => '{view}'],
            ];

// Renders a export dropdown menu
            echo ExportMenu::widget([
                'dataProvider' => $dataProvider,
                'columns' => $gridColumns
            ]);

// You can choose to render your own GridView separately
            echo \kartik\grid\GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => $gridColumns
            ]);
            ?>
        </div>
    </div>


</div>
