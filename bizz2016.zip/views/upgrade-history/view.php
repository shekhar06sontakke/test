<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\UpgradeHistory */

$this->title = '#'. $model->upgh_id;
$this->params['breadcrumbs'][] = ['label' => 'Upgrade Histories', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="upgrade-history-view">

    <h1><?= Html::encode($this->title) ?></h1>


    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'upgh_id',
            [
                'attribute' => 'id',
                'value' => $model->user->name . ' ' . $model->user->surname . ' (' . $model->user->id . ')',
            ],
//            'id',
//            'pln_id',
            [
                'attribute' => 'pln_id',
                'value' => $model->plan->pln_name,
            ],
            'pld_duration',
            'upgh_currency',
            'upgh_amount',
            'upgh_pay_method',
            'upgh_txnid',
//            'created_by',
//            'updated_by',
            [
                'attribute' => 'created_at',
                'value' => app\components\Helper::_date($model->created_at, 'd-M-Y H:i'),
            ],
            [
                'attribute' => 'updated_at',
                'value' => app\components\Helper::_date($model->updated_at, 'd-M-Y H:i'),
            ],
          
        ],
    ])
    ?>

</div>
